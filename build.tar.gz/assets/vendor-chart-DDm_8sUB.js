import{C as o}from"./vendor-chart-Cdfw4CQO.js";typeof window<"u"&&(window.Chart=window.Chart||o);export{o as Chart};
