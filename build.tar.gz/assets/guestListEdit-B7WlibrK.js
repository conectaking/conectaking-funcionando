const E=String(window.API_URL||window.API_BASE||window.API_CONFIG&&window.API_CONFIG.baseURL||window.location.origin).replace(/\/$/,"");let x=null,m=null,h=[];function g(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function $(e){const i=Object.assign({},e||{}),t=k();return t&&(i.Authorization="Bearer "+t),i}function k(){try{if(window.CkAuth&&typeof window.CkAuth.lsToken=="function")return window.CkAuth.lsToken()||""}catch{}return localStorage.getItem("conectaKingToken")||localStorage.getItem("token")||""}const T=window.fetch.bind(window);function C(e,i){i=i||{},i.credentials||(i=Object.assign({},i,{credentials:"include"}));try{const t=i.headers;if(t&&typeof t=="object"&&!t.get){const o=t.Authorization||t.authorization;if(typeof o=="string"&&/^Bearer\s*(null|undefined)?\s*$/i.test(o.trim())){const n=Object.assign({},t);delete n.Authorization,delete n.authorization,i=Object.assign({},i,{headers:n})}}}catch{}if(window.CkCsrf&&typeof window.CkCsrf.wrapFetch=="function")return window.CkCsrf.wrapFetch(T)(e,i);try{const t=(i.method||"GET").toUpperCase();if(t==="POST"||t==="PUT"||t==="PATCH"||t==="DELETE"){const o=document.cookie.match(/(?:^|; )ck_csrf=([^;]*)/),n=o?decodeURIComponent(o[1]):"";if(n){const s=Object.assign({},i.headers||{});s["X-CK-CSRF"]||(s["X-CK-CSRF"]=n),i=Object.assign({},i,{headers:s})}}}catch{}return T(e,i)}function _(){const e=new URLSearchParams(window.location.search);return e.get("itemId")||e.get("id")}function O(){return new URLSearchParams(window.location.search).get("formItemId")}function N(){_()?W().catch(i=>{}):M().catch(i=>{})}function F(){it(),N()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",F):setTimeout(F,100);async function M(){try{const e=k(),i=await C(`${E}/api/guest-lists`,{headers:$()});if(!i.ok){const o=await i.json().catch(()=>({message:`Erro ${i.status}: ${i.statusText}`}));throw new Error(o.message||`Erro ${i.status} ao carregar listas`)}const t=await i.json();R(t)}catch(e){const i=document.getElementById("main-container")||document.querySelector(".main-container");i&&(i.innerHTML=`
                <div style="text-align: center; padding: 60px 20px; color: var(--text-dark, #A1A1A1);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 16px; color: #FF9800;"></i>
                    <h4 style="color: var(--text, #ECECEC); margin-bottom: 12px;">Erro ao carregar listas</h4>
                    <p style="margin-bottom: 20px;">${e.message||"Erro desconhecido"}</p>
                    <button onclick="window.location.reload()" style="padding: 12px 24px; background: #FFC700; color: #000; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                        Tentar novamente
                    </button>
                </div>
            `)}}function R(e){const i=document.getElementById("main-container")||document.querySelector(".main-container");if(!i)return;const t=O(),o=window.location.hostname.includes("localhost")?window.location.origin:"https://tag.conectaking.com.br",n=e.reduce((a,l)=>{const p=parseInt(l.registered_count||0),r=parseInt(l.confirmed_count||0),d=parseInt(l.checked_in_count||0);return a.total+=p+r+d,a.registered+=p,a.confirmed+=r,a.checked_in+=d,a},{total:0,registered:0,confirmed:0,checked_in:0}),s=document.querySelector(".tabs-container"),c=document.querySelectorAll(".tab-content");s&&(s.style.display="none"),c.forEach(a=>a.style.display="none");let f=`
        <div style="margin-bottom: 32px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <h2 style="margin: 0; color: var(--text, #ECECEC); font-size: 28px;">
                    <i class="fas fa-users" style="color: var(--dourado-principal, #FFC700); margin-right: 12px;"></i>
                    Listas de Convidados
                </h2>
                <button id="btn-new-guest-list" class="btn btn-primary" onclick="createNewGuestList()">
                    <i class="fas fa-plus"></i> Nova Lista
                </button>
            </div>
            
            <!-- Estatísticas Gerais -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-label">Listas Criadas</div>
                    <div class="stat-value">${e.length}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Total de Convidados</div>
                    <div class="stat-value">${n.total}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Confirmados</div>
                    <div class="stat-value" style="color: #4CAF50;">${n.confirmed}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Conferidos</div>
                    <div class="stat-value" style="color: #2196F3;">${n.checked_in}</div>
                </div>
            </div>
        </div>
    `;e.length===0?f+=`
            <div style="text-align: center; padding: 60px 20px; background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px;">
                <i class="fas fa-users" style="font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: var(--dourado-principal, #FFC700);"></i>
                <h4 style="color: var(--text, #ECECEC); margin-bottom: 12px;">Nenhuma lista criada ainda</h4>
                <p style="color: var(--text-dark, #A1A1A1); margin-bottom: 24px;">Crie sua primeira lista de convidados para começar a gerenciar convidados, confirmações e presenças.</p>
                <button onclick="createNewGuestList()" class="btn btn-primary" style="display: inline-flex;">
                    <i class="fas fa-plus"></i> Criar Primeira Lista
                </button>
            </div>
        `:(f+=`
            <div style="margin-bottom: 24px;">
                <div style="position: relative;">
                    <i class="fas fa-search" style="position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-dark, #A1A1A1);"></i>
                    <input type="text" id="search-lists-input" placeholder="Buscar lista por nome, evento, localização..." 
                           style="width: 100%; padding: 12px 16px 12px 48px; background: var(--card-background-color, #1C1C21); border: 2px solid var(--border-color, #2C2C2F); border-radius: 12px; color: var(--text, #ECECEC); font-size: 14px; transition: all 0.3s;"
                           onfocus="this.style.borderColor='var(--dourado-principal, #FFC700)'; this.style.background='rgba(255,199,0,0.05)';"
                           onblur="this.style.borderColor='var(--border-color, #2C2C2F)'; this.style.background='var(--card-background-color, #1C1C21)';">
                </div>
            </div>
        `,f+='<div id="lists-grid" style="display: grid; gap: 20px;">',e.forEach(a=>{const l=parseInt(a.registered_count||0),p=parseInt(a.confirmed_count||0),r=parseInt(a.checked_in_count||0),d=l+p+r,b=Math.max(0,p-r),y=a.event_date?new Date(a.event_date).toLocaleDateString("pt-BR"):"Não definido";f+=`
                <div class="list-card" data-list-name="${g((a.event_title||a.title||"").toLowerCase())}" data-list-location="${g((a.event_location||"").toLowerCase())}" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 24px; transition: all 0.3s;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
                        <div style="flex: 1;">
                            <h3 style="margin: 0 0 8px 0; color: var(--text, #ECECEC); font-size: 20px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-users" style="color: var(--dourado-principal, #FFC700);"></i>
                                ${g(a.event_title||a.title||"Lista de Convidados")}
                            </h3>
                            <p style="color: var(--text-dark, #A1A1A1); margin: 4px 0; font-size: 14px;">
                                <i class="fas fa-calendar" style="margin-right: 6px;"></i> ${y}
                            </p>
                            ${a.event_location?`
                                <p style="color: var(--text-dark, #A1A1A1); margin: 4px 0; font-size: 14px;">
                                    <i class="fas fa-map-marker-alt" style="margin-right: 6px;"></i> ${g(a.event_location)}
                                </p>
                            `:""}
                        </div>
                        <button onclick="window.location.href='/guestListEdit?itemId=${a.profile_item_id||a.id}${t?"&formItemId="+t:""}'" class="btn btn-primary" style="padding: 10px 20px;">
                            <i class="fas fa-edit"></i> Gerenciar
                        </button>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 20px; padding: 16px; background: rgba(255,255,255,0.02); border-radius: 8px;">
                        <div style="text-align: center; padding: 12px; background: rgba(255,199,0,0.1); border-radius: 8px; border: 1px solid rgba(255,199,0,0.2);">
                            <div style="font-size: 24px; font-weight: 800; color: var(--dourado-principal, #FFC700);">${l}</div>
                            <div style="font-size: 11px; color: var(--text-dark, #A1A1A1); margin-top: 4px; font-weight: 600;">Cadastrados</div>
                        </div>
                        <div style="text-align: center; padding: 12px; background: rgba(76,175,80,0.1); border-radius: 8px; border: 1px solid rgba(76,175,80,0.2);">
                            <div style="font-size: 24px; font-weight: 800; color: #4CAF50;">${p}</div>
                            <div style="font-size: 11px; color: var(--text-dark, #A1A1A1); margin-top: 4px; font-weight: 600;">Confirmados</div>
                        </div>
                        <div style="text-align: center; padding: 12px; background: rgba(33,150,243,0.1); border-radius: 8px; border: 1px solid rgba(33,150,243,0.2);">
                            <div style="font-size: 24px; font-weight: 800; color: #2196F3;">${r}</div>
                            <div style="font-size: 11px; color: var(--text-dark, #A1A1A1); margin-top: 4px; font-weight: 600;">Conferidos</div>
                        </div>
                        <div style="text-align: center; padding: 12px; background: rgba(244,67,54,0.1); border-radius: 8px; border: 1px solid rgba(244,67,54,0.2);">
                            <div style="font-size: 24px; font-weight: 800; color: #F44336;">${b}</div>
                            <div style="font-size: 11px; color: var(--text-dark, #A1A1A1); margin-top: 4px; font-weight: 600;">Faltam</div>
                        </div>
                        <div style="text-align: center; padding: 12px; background: rgba(255,255,255,0.05); border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);">
                            <div style="font-size: 24px; font-weight: 800; color: var(--dourado-principal, #FFC700);">${d}</div>
                            <div style="font-size: 11px; color: var(--text-dark, #A1A1A1); margin-top: 4px; font-weight: 600;">Total</div>
                        </div>
                    </div>
                    
                    <!-- Links Rápidos -->
                    <div style="margin-top: 16px; padding: 16px; background: rgba(74,144,226,0.1); border-radius: 8px; border: 1px solid rgba(74,144,226,0.2);">
                        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                            <button onclick="copyLinkToClipboard('${o}/guest-list/register/${a.registration_token}', event)" 
                                    class="btn btn-secondary" 
                                    style="flex: 1; min-width: 140px; padding: 10px 16px; font-size: 13px; background: rgba(74,144,226,0.2); border-color: #4A90E2; color: #4A90E2;">
                                <i class="fas fa-link"></i> Copiar Link Inscrição
                            </button>
                            <button onclick="copyLinkToClipboard('${o}/guest-list/view-full/${a.public_view_token}', event)" 
                                    class="btn btn-secondary" 
                                    style="flex: 1; min-width: 140px; padding: 10px 16px; font-size: 13px; background: rgba(255,199,0,0.2); border-color: #FFC700; color: #FFC700;">
                                <i class="fas fa-eye"></i> Copiar Link Portaria
                            </button>
                        </div>
                    </div>
                </div>
            `}),f+="</div>"),i.innerHTML=f;const u=i.querySelector("#search-lists-input");u&&u.addEventListener("input",a=>{const l=a.target.value.toLowerCase().trim();i.querySelectorAll(".list-card").forEach(r=>{const d=r.dataset.listName||"",b=r.dataset.listLocation||"";l===""||d.includes(l)||b.includes(l)?r.style.display="block":r.style.display="none"})})}async function W(){const e=_();if(!e){await M();return}x=e;const i=document.querySelector(".tabs-container");document.querySelectorAll(".tab-content"),i&&(i.style.display="flex");try{const t=k(),o=await C(`${E}/api/guest-lists/${e}`,{headers:$()});if(!o.ok){const u=await o.json().catch(()=>({message:"Erro ao carregar lista"}));throw new Error(u.message||`Erro ${o.status}: Não foi possível carregar a lista`)}const n=await o.json();if(!n||!n.id)throw new Error("Dados da lista inválidos");m=n,x=n.id||n.profile_item_id||e;const s=document.getElementById("event-title");s&&(s.textContent=n.event_title||"Lista de Convidados");const c=document.getElementById("use-custom-form");c&&(c.checked=n.use_custom_form===!0);const f=document.getElementById("custom-form-builder");if(f&&(f.style.display=n.use_custom_form===!0?"block":"none"),n.custom_form_fields&&typeof n.custom_form_fields=="string")try{n.custom_form_fields=JSON.parse(n.custom_form_fields)}catch{n.custom_form_fields=[]}n.custom_form_fields||(n.custom_form_fields=[]),Z(),m&&tt(),await P(),await J(),setTimeout(()=>{const u=document.getElementById("tab-links"),l=new URLSearchParams(window.location.search).get("tab");(u&&u.classList.contains("active")||l==="links")&&(x?(S(),A()):setTimeout(()=>{x&&(S(),A())},1e3))},500)}catch(t){const o=t.message||"Erro desconhecido ao carregar lista de convidados";let n=!1;(o.includes("404")||o.includes("não encontrada")||o.includes("não encontrado"))&&(n=!0);const s=document.getElementById("main-container")||document.querySelector(".main-container");if(s){let c=o,f="";n&&(c="Lista de convidados não encontrada",f=`
                    <p style="margin-top: 16px; color: var(--text-dark, #A1A1A1); font-size: 14px;">
                        Esta lista pode não ter sido criada ainda. O sistema tentará criá-la automaticamente.
                    </p>
                    <p style="margin-top: 8px; color: var(--text-dark, #A1A1A1); font-size: 14px;">
                        Aguarde alguns segundos e clique em "Tentar novamente".
                    </p>
                `),s.innerHTML=`
                <div style="text-align: center; padding: 60px 20px; color: var(--text-dark, #A1A1A1);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 16px; color: #FF9800;"></i>
                    <h4 style="color: var(--text, #ECECEC); margin-bottom: 12px;">Erro ao carregar lista</h4>
                    <p style="margin-bottom: 20px; font-size: 16px;">${c}</p>
                    ${f}
                    <div style="margin-top: 24px; display: flex; gap: 12px; justify-content: center;">
                        <button onclick="window.location.reload()" style="padding: 12px 24px; background: #FFC700; color: #000; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            <i class="fas fa-redo"></i> Tentar novamente
                        </button>
                        <button onclick="goBack()" style="padding: 12px 24px; background: rgba(255,255,255,0.1); color: var(--text, #ECECEC); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; cursor: pointer; font-weight: 600;">
                            <i class="fas fa-arrow-left"></i> Voltar
                        </button>
                    </div>
                </div>
            `}else alert(`Erro ao carregar lista de convidados: ${o}`)}}let w={total:0,limit:100,offset:0,hasMore:!1};function V(e){if(Array.isArray(e))return{guests:e,total:e.length,limit:e.length,offset:0,hasMore:!1};if(e&&typeof e=="object"){const i=Array.isArray(e.guests)?e.guests:Array.isArray(e.data)?e.data:[];return{guests:i,total:typeof e.total=="number"?e.total:i.length,limit:typeof e.limit=="number"?e.limit:100,offset:typeof e.offset=="number"?e.offset:0,hasMore:!!e.hasMore}}return{guests:[],total:0,limit:100,offset:0,hasMore:!1}}async function P(e){try{const i=k(),t=e?(w.offset||0)+(w.limit||100):0,o=await C(`${E}/api/guest-lists/${x}/guests?limit=100&offset=${t}`,{headers:$()});if(!o.ok)throw new Error("Erro ao carregar convidados");const n=V(await o.json());w={total:n.total,limit:n.limit,offset:n.offset,hasMore:n.hasMore},e?(h=(h||[]).concat(n.guests),q=[...h]):(h=n.guests,q=[...h]),D()}catch{}}async function J(){try{const e=k(),i=await C(`${E}/api/guest-lists/${x}/stats`,{headers:$()});if(!i.ok)throw new Error("Erro ao carregar estatísticas");const t=await i.json();K(t)}catch{}}function K(e){const i=`
        <div class="stat-card">
            <div class="stat-label">Total Cadastrados</div>
            <div class="stat-value">${e.registered_count||0}</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Geral</div>
            <div class="stat-value">${e.total_count||0}</div>
        </div>
    `,t=`
        <div class="stat-card">
            <div class="stat-label">Aguardando Confirmação</div>
            <div class="stat-value">${e.registered_count||0}</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Confirmados</div>
            <div class="stat-value">${e.confirmed_count||0}</div>
        </div>
    `,o=`
        <div class="stat-card">
            <div class="stat-label">Confirmados</div>
            <div class="stat-value">${e.confirmed_count||0}</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Conferidos</div>
            <div class="stat-value">${e.checked_in_count||0}</div>
        </div>
    `,n=document.getElementById("registered-stats"),s=document.getElementById("confirmation-stats"),c=document.getElementById("confirmed-stats");n&&(n.innerHTML=i),s&&(s.innerHTML=t),c&&(c.innerHTML=o)}function D(){const e=document.querySelector(".tab-button.active")?.dataset.tab||"registered";let i=[];e==="registered"?(i=h.filter(o=>o.status==="registered"),X(i)):e==="confirmation"?(i=h.filter(o=>o.status==="registered"),Y(i)):e==="confirmed"&&(i=h.filter(o=>o.status==="confirmed"||o.status==="checked_in"),Q(i));let t=document.getElementById("guests-load-more-btn");t||(t=document.createElement("button"),t.id="guests-load-more-btn",t.type="button",t.className="btn-secondary",t.style.cssText="display:none;margin:12px auto;",t.textContent="Carregar mais",t.onclick=function(){P(!0)},(document.querySelector(".tabs-content")||document.querySelector(".guest-list-container")||document.body).appendChild(t)),w&&w.hasMore?(t.style.display="block",t.textContent="Carregar mais ("+h.length+" / "+w.total+")"):t.style.display="none"}function X(e){const i=document.getElementById("registered-guests-list");if(i){if(e.length===0){i.innerHTML='<div class="empty-state"><i class="fas fa-user-plus"></i><p>Nenhum convidado cadastrado ainda</p><p style="font-size: 14px; margin-top: 8px; opacity: 0.7;">Compartilhe o link de inscrição acima para receber inscrições</p></div>';return}i.innerHTML=e.map(t=>{const o=t.created_at?new Date(t.created_at).toLocaleString("pt-BR"):"-";return`
            <div class="table-row">
                <div style="font-weight: 600;">${g(t.name||"-")}</div>
                <div>${g(t.email||"-")}</div>
                <div>${g(t.phone||"-")}</div>
                <div><span class="status-badge status-${t.status}">${z(t.status)}</span></div>
                <div>${o}</div>
                <div>
                    <button class="btn-icon" onclick="viewGuestDetails(${t.id})" title="Ver detalhes">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon" onclick="deleteGuest(${t.id})" title="Remover">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `}).join("")}}function Y(e){const i=document.getElementById("confirmation-guests-list");if(i){if(e.length===0){i.innerHTML='<div class="empty-state"><i class="fas fa-user-check"></i><p>Nenhum convidado aguardando confirmação</p><p style="font-size: 14px; margin-top: 8px; opacity: 0.7;">Os convidados cadastrados aparecerão aqui para confirmação</p></div>';return}i.innerHTML=e.map(t=>{const o=t.created_at?new Date(t.created_at).toLocaleString("pt-BR"):"-";return`
            <div class="table-row">
                <div style="font-weight: 600;">${g(t.name||"-")}</div>
                <div>${g(t.email||"-")}</div>
                <div>${g(t.phone||"-")}</div>
                <div><span class="status-badge status-${t.status}">${z(t.status)}</span></div>
                <div>${o}</div>
                <div>
                    <button class="btn-icon" onclick="viewGuestDetails(${t.id})" title="Ver detalhes" style="margin-right: 8px;">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon" onclick="confirmGuest(${t.id})" title="Confirmar Presença" style="background: #4CAF50; color: white; margin-right: 8px;">
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn-icon" onclick="deleteGuest(${t.id})" title="Remover">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `}).join("")}}function Q(e){const i=document.getElementById("confirmed-guests-list");if(i){if(e.length===0){i.innerHTML='<div class="empty-state"><i class="fas fa-check-circle"></i><p>Nenhum convidado confirmado ainda</p><p style="font-size: 14px; margin-top: 8px; opacity: 0.7;">Confirme os convidados na aba "Convidados para Confirmação"</p></div>';return}i.innerHTML=e.map(t=>{const o=t.confirmed_at?new Date(t.confirmed_at).toLocaleString("pt-BR"):"-";return`
            <div class="table-row">
                <div style="font-weight: 600;">${g(t.name||"-")}</div>
                <div>${g(t.email||"-")}</div>
                <div>${g(t.phone||"-")}</div>
                <div><span class="status-badge status-${t.status}">${z(t.status)}</span></div>
                <div>${o}</div>
                <div>
                    <button class="btn-icon" onclick="viewGuestDetails(${t.id})" title="Ver detalhes" style="margin-right: 8px;">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${t.status==="confirmed"?`
                        <button class="btn-icon" onclick="checkInGuest(${t.id})" title="Conferir Presença" style="background: #2196F3; color: white; margin-right: 8px;">
                            <i class="fas fa-check-circle"></i>
                        </button>
                    `:'<span style="color: var(--dourado-principal, #FFC700);"><i class="fas fa-check-circle"></i> Conferido</span>'}
                    <button class="btn-icon" onclick="deleteGuest(${t.id})" title="Remover">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `}).join("")}}function z(e){return{registered:"Inscrito",confirmed:"Confirmado",checked_in:"Conferido",cancelled:"Cancelado"}[e]||e}function L(e){document.querySelectorAll(".tab-button").forEach(t=>{t.classList.remove("active"),t.dataset.tab===e&&t.classList.add("active")}),document.querySelectorAll(".tab-content").forEach(t=>{t.classList.remove("active")});const i=document.getElementById(`tab-${e}`);i&&i.classList.add("active"),e!=="links"?D():(S(),A())}function Z(){if(!m)return;const e=window.location.hostname.includes("localhost")?window.location.origin:"https://tag.conectaking.com.br",i=m.registration_token,t=m.confirmation_token,o=x;if(i){const s=document.getElementById("registration-link");s&&(s.value=`${e}/guest-list/register/${i}`)}if(t||o){const s=document.getElementById("confirmation-link");s&&(s.value=`${e}/guest-list/confirm/${t||o}?tab=confirmation`)}if(o){const s=document.getElementById("confirmed-link");s&&(s.value=`${e}/guest-list/view/${o}?tab=confirmed`)}const n=m.public_view_token||m.confirmation_token;if(n){const s=document.getElementById("public-view-link");s&&(s.value=`${e}/guest-list/view-full/${n}`)}A()}function A(){if(!m)return;const e=window.location.hostname.includes("localhost")?window.location.origin:"https://tag.conectaking.com.br",i=m.portaria_slug||"portaria",t=document.getElementById("portaria-link"),o=document.getElementById("portaria-slug-input");t&&(t.value=`${e}/guest-list/view-full/${m.public_view_token||m.confirmation_token}`),o&&(o.value=i)}async function S(){const e=document.getElementById("personalized-links-list");if(e){if(!x){e.innerHTML='<p style="color: var(--text-dark, #A1A1A1); font-size: 14px; padding: 16px; text-align: center;">Carregando lista...</p>';return}e.innerHTML='<p style="color: var(--text-dark, #A1A1A1); font-size: 14px; padding: 16px; text-align: center;"><i class="fas fa-spinner fa-spin"></i> Carregando links personalizados...</p>';try{const i=k(),t={};i&&(t.Authorization="Bearer "+i);const o=await C(`${E}/api/guest-lists/${x}/cadastro-links`,{credentials:"include",headers:t});if(!o.ok){const c=await o.json().catch(()=>({message:"Erro desconhecido"}));throw new Error(c.message||`Erro ${o.status}: ${o.statusText}`)}const s=(await o.json()).data||[];s.length===0?B([]):B(s)}catch(i){e&&(e.innerHTML=`
                <div style="padding: 20px; text-align: center; background: rgba(255,68,68,0.1); border: 1px solid rgba(255,68,68,0.3); border-radius: 8px;">
                    <i class="fas fa-exclamation-triangle" style="color: #ff4444; font-size: 24px; margin-bottom: 8px;"></i>
                    <p style="color: #ff4444; margin: 0 0 8px 0; font-weight: 600;">Erro ao carregar links personalizados</p>
                    <p style="color: var(--text-dark, #A1A1A1); font-size: 13px; margin: 0;">${i.message||"Erro desconhecido"}</p>
                </div>
            `)}}}function B(e){const i=document.getElementById("personalized-links-list");if(!i)return;if(i&&(i.style.overflow="visible",i.style.width="100%",i.style.boxSizing="border-box"),e.length===0){i.innerHTML='<p style="color: var(--text-dark, #A1A1A1); font-size: 14px; padding: 16px; text-align: center;">Nenhum link personalizado criado ainda.</p>';return}const t=window.location.hostname.includes("localhost")?window.location.origin:"https://tag.conectaking.com.br";if(i.innerHTML=e.map((o,n)=>{if(!o||!o.slug)return"";const s=o.isExpired===!0,c=o.isUsed===!0,f=s?"status-cancelled":c?"status-registered":"status-checked_in",u=s?"Expirado":c?"Usado":"Disponível",a=s?"rgba(255,68,68,0.2)":c?"rgba(74,144,226,0.2)":"rgba(37,211,102,0.2)",l=s?"#ff4444":c?"#4A90E2":"#25D366",p=`${t}/usuario/form/share/${o.slug}`,r=o.description&&o.description.trim()||o.slug||`Link ${n+1}`,d=o.expires_at?new Date(o.expires_at).toLocaleDateString("pt-BR"):"Sem expiração",b=o.expires_at?"fa-calendar-times":"fa-infinity",y=o.max_uses===999999||o.max_uses===null?"Ilimitado":o.max_uses,I=o.current_uses||0,v=p.replace(/'/g,"\\'").replace(/"/g,"&quot;"),U=r.replace(/"/g,"&quot;").replace(/'/g,"&#39;");return`
            <div class="personalized-link-item mobile-link-item" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 16px; margin-bottom: 12px; overflow: visible; word-wrap: break-word; overflow-wrap: break-word; display: block; visibility: visible; opacity: 1; width: 100%; box-sizing: border-box;">
                <!-- Header: Status e Nome -->
                <div class="link-header-mobile link-header-content" style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; width: 100%; visibility: visible; opacity: 1;">
                    <span class="status-badge ${f}" style="font-size: 11px; padding: 4px 10px; border-radius: 6px; font-weight: 600; background: ${a}; color: ${l}; border: 1px solid ${l}; white-space: nowrap; display: inline-block; visibility: visible; opacity: 1;">
                        ${u}
                    </span>
                    <strong class="link-name-mobile link-name-content" style="color: var(--text, #ECECEC); font-size: 14px; font-weight: 700; flex: 1; min-width: 0; word-break: break-word; overflow-wrap: break-word; line-height: 1.4; display: block; visibility: visible; opacity: 1; width: 100%;">
                        ${U}
                    </strong>
                </div>
                
                <!-- URL do Link -->
                <div class="link-box link-box-mobile link-box-content" style="display: flex; gap: 10px; align-items: stretch; margin-bottom: 12px; flex-wrap: wrap; width: 100%; visibility: visible; opacity: 1;">
                    <input type="text" class="link-input link-input-mobile link-input-content" value="${v}" readonly style="flex: 1; min-width: 0; width: 100%; max-width: 100%; padding: 10px 12px; background: var(--background-color, #0D0D0F); border: 2px solid var(--border-color, #2C2C2F); border-radius: 10px; color: var(--text, #ECECEC); font-size: 12px; font-family: monospace; word-break: break-all; overflow-wrap: break-word; box-sizing: border-box; display: block; visibility: visible; opacity: 1;">
                    <button onclick="copyToClipboardPersonalized('${v}', this)" class="btn-copy btn-copy-mobile btn-copy-content" style="padding: 10px 16px; background: #000; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 13px; cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 6px; flex-shrink: 0; visibility: visible; opacity: 1; justify-content: center;">
                        <i class="fas fa-copy" style="display: inline-block; visibility: visible;"></i> <span class="btn-text" style="display: inline-block; visibility: visible; opacity: 1; font-size: 13px; font-weight: 700;">Copiar</span>
                    </button>
                </div>
                
                <!-- Detalhes: Expiração, Slug, Uso -->
                <div class="link-details-mobile link-details-content" style="display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px; font-size: 13px; color: var(--text-dark, #A1A1A1); width: 100%; box-sizing: border-box; visibility: visible; opacity: 1;">
                    <span class="detail-item-mobile detail-item-content" style="display: flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1;">
                        <i class="fas ${b}" style="color: var(--dourado-principal, #FFC700); flex-shrink: 0; display: inline-block; visibility: visible;"></i>
                        <span style="display: inline; visibility: visible; white-space: normal;"><strong style="color: var(--text, #ECECEC);">${d}</strong></span>
                    </span>
                    <span class="detail-item-mobile detail-item-content" style="display: flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1;">
                        <i class="fas fa-hashtag" style="color: var(--dourado-principal, #FFC700); flex-shrink: 0; display: inline-block; visibility: visible;"></i>
                        <span style="display: inline; visibility: visible; white-space: normal;">#Slug: <strong style="color: var(--text, #ECECEC);">${o.slug}</strong></span>
                    </span>
                    <span class="detail-item-mobile detail-item-content" style="display: flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1;">
                        <i class="fas fa-users" style="color: var(--dourado-principal, #FFC700); flex-shrink: 0; display: inline-block; visibility: visible;"></i>
                        <span style="display: inline; visibility: visible; white-space: normal;">Uso: <strong style="color: var(--text, #ECECEC);">${I}/${y}</strong></span>
                    </span>
                </div>
                
                <!-- Botões de Ação -->
                <div class="link-actions-mobile link-actions-content" style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; width: 100%; visibility: visible; opacity: 1;">
                    ${s?`
                        <button onclick="renewLink(${o.id})" class="btn-action-renew btn-action-content" style="padding: 10px 16px; background: linear-gradient(135deg, #4A90E2, #357ABD); color: #fff; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1; justify-content: center;">
                            <i class="fas fa-redo" style="display: inline-block; visibility: visible;"></i>
                            <span style="display: inline-block; visibility: visible; opacity: 1; font-size: 13px; font-weight: 700;">Renovar</span>
                        </button>
                    `:`
                        <button onclick="toggleLinkStatus(${o.id}, ${o.isActiveForProfile||!1})" class="btn-action-toggle btn-action-content" style="padding: 10px 16px; background: ${o.isActiveForProfile?"linear-gradient(135deg, #25D366, #1DB954)":"rgba(255,68,68,0.2)"}; color: ${o.isActiveForProfile?"#fff":"#ff4444"}; border: 2px solid ${o.isActiveForProfile?"#25D366":"#ff4444"}; border-radius: 8px; font-weight: 700; cursor: pointer; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; transition: all 0.3s; white-space: nowrap; visibility: visible; opacity: 1; justify-content: center;">
                            <i class="fas fa-${o.isActiveForProfile?"check-circle":"times-circle"}" style="display: inline-block; visibility: visible;"></i>
                            <span style="display: inline-block; visibility: visible; opacity: 1; font-size: 13px; font-weight: 700;">${o.isActiveForProfile?"Ativo":"Ativar"}</span>
                        </button>
                    `}
                    <button onclick="editPersonalizedLink(${o.id})" class="btn-action-edit btn-action-content" style="padding: 10px 16px; background: rgba(74,144,226,0.2); color: #4A90E2; border: 2px solid #4A90E2; border-radius: 8px; font-weight: 700; cursor: pointer; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1; justify-content: center;">
                        <i class="fas fa-edit" style="display: inline-block; visibility: visible;"></i>
                        <span style="display: inline-block; visibility: visible; opacity: 1; font-size: 13px; font-weight: 700;">Editar</span>
                    </button>
                    <button onclick="deletePersonalizedLink(${o.id})" class="btn-action-delete btn-action-content" style="padding: 10px 16px; background: rgba(255,68,68,0.2); color: #ff4444; border: 2px solid #ff4444; border-radius: 8px; font-weight: 700; cursor: pointer; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; visibility: visible; opacity: 1; justify-content: center;">
                        <i class="fas fa-trash" style="display: inline-block; visibility: visible;"></i>
                        <span style="display: inline-block; visibility: visible; opacity: 1; font-size: 13px; font-weight: 700;">Excluir</span>
                    </button>
                </div>
            </div>
        `}).join(""),i){i.offsetHeight;const o=window.innerWidth<=768||/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);i.querySelectorAll(".personalized-link-item").forEach(s=>{if(s&&(s.style.overflow="visible",s.style.width="100%",s.style.boxSizing="border-box",s.style.display="block",s.style.visibility="visible",s.style.opacity="1",o)){const c=s.querySelector(".link-header-content, .link-header-mobile");c&&(c.style.flexDirection="column",c.style.alignItems="flex-start");const f=s.querySelector(".link-name-content, .link-name-mobile");f&&(f.style.display="block",f.style.width="100%",f.style.fontSize="15px",f.style.fontWeight="700",f.style.color="var(--text, #ECECEC)",f.style.marginTop="8px");const u=s.querySelector(".link-box-content, .link-box-mobile");u&&(u.style.flexDirection="column",u.style.width="100%"),s.querySelectorAll(".link-input-content, .link-input-mobile, .link-input").forEach(d=>{d&&(d.style.width="100%",d.style.maxWidth="100%",d.style.minWidth="0",d.style.flex="none",d.style.boxSizing="border-box",d.style.overflow="visible",d.style.wordBreak="break-all",d.style.overflowWrap="break-word",d.style.display="block",d.style.visibility="visible")});const l=s.querySelector(".btn-copy-content, .btn-copy-mobile, .btn-copy");if(l){l.style.width="100%",l.style.justifyContent="center",l.style.display="flex";const d=l.querySelector(".btn-text");d&&(d.style.display="inline-block",d.style.visibility="visible",d.style.fontSize="13px",d.style.fontWeight="700")}const p=s.querySelector(".link-details-content, .link-details-mobile");p&&(p.style.flexDirection="column",p.style.width="100%",p.querySelectorAll(".detail-item-content, .detail-item-mobile").forEach(b=>{b.style.width="100%",b.style.flexWrap="wrap",b.querySelectorAll("span").forEach(v=>{v.style.display="inline",v.style.visibility="visible"}),b.querySelectorAll("strong").forEach(v=>{v.style.display="inline",v.style.visibility="visible"})}));const r=s.querySelector(".link-actions-content, .link-actions-mobile");r&&(r.style.flexDirection="column",r.style.width="100%",r.querySelectorAll("button").forEach(b=>{b.style.width="100%",b.style.justifyContent="center",b.style.flexDirection="row",b.querySelectorAll("span").forEach(v=>{v.style.display="inline-block",v.style.visibility="visible",v.style.fontSize="13px",v.style.fontWeight="700"}),b.querySelectorAll("i").forEach(v=>{v.style.display="inline-block",v.style.visibility="visible"})}))}})}setTimeout(()=>{G()},100)}function G(){const e=document.getElementById("personalized-links-list");if(!e)return;e.querySelectorAll(".personalized-link-item").forEach(t=>{if(!t)return;t.style.display="block",t.style.visibility="visible",t.style.opacity="1",t.style.width="100%";const o=t.querySelector(".link-header-content, .link-header-mobile");o&&(o.style.display="flex",o.style.flexDirection="row",o.style.alignItems="center",o.style.visibility="visible",o.style.opacity="1");const n=t.querySelector(".status-badge");n&&(n.style.display="inline-block",n.style.visibility="visible",n.style.opacity="1");const s=t.querySelector(".link-name-content, .link-name-mobile, strong");s&&(s.style.display="inline-block",s.style.flex="1",s.style.fontSize="14px",s.style.fontWeight="700",s.style.color="var(--text, #ECECEC)",s.style.visibility="visible",s.style.opacity="1");const c=t.querySelector(".link-box-content, .link-box-mobile, .link-box");c&&(c.style.display="flex",c.style.flexDirection="row",c.style.width="100%",c.style.visibility="visible",c.style.opacity="1"),t.querySelectorAll(".link-input-content, .link-input-mobile, .link-input").forEach(p=>{p&&(p.style.display="block",p.style.flex="1",p.style.minWidth="200px",p.style.visibility="visible",p.style.opacity="1")});const u=t.querySelector(".btn-copy-content, .btn-copy-mobile, .btn-copy");if(u){u.style.display="flex",u.style.flexShrink="0",u.style.visibility="visible",u.style.opacity="1";const p=u.querySelector(".btn-text");p&&(p.style.display="inline-block",p.style.visibility="visible",p.style.opacity="1")}const a=t.querySelector(".link-details-content, .link-details-mobile");a&&(a.style.display="flex",a.style.flexDirection="row",a.style.flexWrap="wrap",a.style.width="100%",a.style.visibility="visible",a.style.opacity="1",a.querySelectorAll(".detail-item-content, .detail-item-mobile, span").forEach(r=>{r.style.display="flex",r.style.alignItems="center",r.style.visibility="visible",r.style.opacity="1",r.querySelectorAll("span").forEach(y=>{y.style.display="inline",y.style.visibility="visible",y.style.opacity="1"}),r.querySelectorAll("strong").forEach(y=>{y.style.display="inline",y.style.visibility="visible",y.style.opacity="1"})}));const l=t.querySelector(".link-actions-content, .link-actions-mobile");l&&(l.style.display="flex",l.style.flexDirection="row",l.style.flexWrap="wrap",l.style.width="100%",l.style.justifyContent="flex-end",l.style.visibility="visible",l.style.opacity="1",l.querySelectorAll("button").forEach(r=>{r.style.display="inline-flex",r.style.width="auto",r.style.flexShrink="0",r.style.justifyContent="center",r.style.visibility="visible",r.style.opacity="1",r.querySelectorAll("span").forEach(y=>{y.style.display="inline-block",y.style.visibility="visible",y.style.opacity="1"}),r.querySelectorAll("i").forEach(y=>{y.style.display="inline-block",y.style.visibility="visible",y.style.opacity="1"})}))})}window.addEventListener("resize",()=>{setTimeout(()=>{G()},200)});function tt(){const e=document.getElementById("custom-fields-preview");if(!e)return;if(!m){e.innerHTML='<i class="fas fa-info-circle"></i> Nenhum campo customizado definido. Clique em "Editar Campos Customizados" para começar.';return}const i=m.custom_form_fields||[];let t=i;if(typeof i=="string")try{t=JSON.parse(i)}catch{t=[]}Array.isArray(t)||(t=[]),t.length===0?e.innerHTML='<i class="fas fa-info-circle"></i> Nenhum campo customizado definido. Clique em "Editar Campos Customizados" para começar.':e.innerHTML=`<strong>${t.length} campo(s) customizado(s):</strong><br>`+t.map((o,n)=>`${n+1}. ${g(o.label||"Campo sem nome")} (${g(o.type||"text")})${o.required?" *":""}`).join("<br>")}function j(){const e=document.getElementById("custom-fields-modal");e&&(e.classList.remove("active"),document.body.style.overflow="",m&&et())}async function et(){if(!x||!m){alert("Nenhuma lista carregada");return}try{const e=k(),i=document.getElementById("use-custom-form"),t={event_title:m.event_title||document.getElementById("event-title")?.textContent||"Lista de Convidados",custom_form_fields:m.custom_form_fields||[],use_custom_form:i?i.checked:!1},o=await C(`${E}/api/guest-lists/${x}`,{method:"PUT",headers:$({"Content-Type":"application/json"}),body:JSON.stringify(t)});if(o.ok){const n=await o.json();m=n.guest_list_data||n;const s=document.querySelector('.btn-primary[onclick*="saveGuestList"]');if(s){const c=s.innerHTML;s.innerHTML='<i class="fas fa-check"></i> Salvo!',setTimeout(()=>{s.innerHTML=c},2e3)}}else throw new Error("Erro ao salvar")}catch(e){alert("Erro ao salvar lista: "+e.message)}}function it(){const e=document.getElementById("guest-detail-modal"),i=document.getElementById("custom-fields-modal");e&&e.classList.remove("active"),i&&i.classList.remove("active");const o=new URLSearchParams(window.location.search).get("tab");if(_()&&o)["registered","confirmation","confirmed"].includes(o)?setTimeout(()=>{typeof L=="function"&&L(o)},1e3):o==="links"&&setTimeout(()=>{typeof L=="function"&&L("links")},1500);else{const s=document.getElementById("tab-links");s&&s.classList.contains("active")&&setTimeout(()=>{x&&(S(),A())},2e3)}}let q=[];function H(){const e=document.getElementById("guest-detail-modal");e&&(e.classList.remove("active"),document.body.style.overflow="")}document.addEventListener("click",e=>{const i=document.getElementById("guest-detail-modal"),t=document.getElementById("custom-fields-modal");i&&e.target===i&&H(),t&&e.target===t&&j()});document.addEventListener("keydown",e=>{if(e.key==="Escape"){const i=document.getElementById("guest-detail-modal"),t=document.getElementById("custom-fields-modal");i&&i.classList.contains("active")&&H(),t&&t.classList.contains("active")&&j()}});
