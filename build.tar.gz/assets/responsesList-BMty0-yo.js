import"./vendor-globals-DuOD7ypR.js";/* empty css                  */import"./ck-auth-gate-Bp-2Xmps.js";import"./ck-csrf-BWOPNFAq.js";import"./vendor-chart-Cdfw4CQO.js";import"./vendor-leaflet-DLsGkNfG.js";import"./cropper-xcpEI_u-.js";import"./vendor-pdf-qr-DM6zglqC.js";import"./vendor-qrcode-CZJ2nzDA.js";const S=(typeof window<"u"&&(window.API_BASE||window.API_URL||window.location.origin)||"").toString().replace(/\/$/,""),Ae=new URLSearchParams(window.location.search),C=Ae.get("itemId");function _(){let t="";try{window.CkAuth&&typeof window.CkAuth.lsToken=="function"&&(t=window.CkAuth.lsToken()||"")}catch{}if(t||(t=localStorage.getItem("conectaKingToken")||localStorage.getItem("authToken")||sessionStorage.getItem("authToken")||localStorage.getItem("userToken")||sessionStorage.getItem("userToken")||localStorage.getItem("token")||sessionStorage.getItem("token")||""),!t){const o=localStorage.getItem("user")||sessionStorage.getItem("user");if(o)try{const i=JSON.parse(o);t=i.token||i.authToken||i.accessToken||""}catch{}}const e={"Content-Type":"application/json"};return t&&(e.Authorization=`Bearer ${t}`),e}const Be=window.fetch.bind(window);function O(t,e){return Be(t,Object.assign({credentials:"include"},e||{}))}let b=[],E="all",I=!1,x=[],P="recent",D="all",R="all",oe=!0,k={registration_token:null,confirmation_token:null,public_view_token:null,share_token:null,cadastro_slug:null};const q=new Map,ye=6e4;let X=!1;const ee=500;async function $(t,e={}){const o=`${e.method||"GET"}:${t}`,i=q.get(o),r=Date.now();if(i&&r-i.timestamp<ye&&(!e.method||e.method==="GET"))return new Response(JSON.stringify(i.data),{ok:!0,status:200,headers:{"Content-Type":"application/json"}});X&&await new Promise(n=>setTimeout(n,ee)),X=!0;try{await new Promise(l=>setTimeout(l,ee/2));const n=await O(t,e);if(await new Promise(l=>setTimeout(l,ee/2)),n.ok&&(!e.method||e.method==="GET")){const l=await n.json();return q.set(o,{data:l,timestamp:r}),new Response(JSON.stringify(l),{ok:!0,status:200,headers:{"Content-Type":"application/json"}})}return n}finally{X=!1}}setInterval(()=>{const t=Date.now();for(const[e,o]of q.entries())t-o.timestamp>ye*2&&q.delete(e)},3e5);async function Te(){try{const t=_();if(!t||Object.keys(t).length===0){I=!1;return}await new Promise(o=>setTimeout(o,300));const e=await $(`${S}/api/profile/items/${C}`,{headers:t});if(e.ok){const o=await e.json(),i=o.data||o;if(i&&i.item_type==="guest_list"){I=!0;return}const r=i?.digital_form_data||{};let n=(r.send_mode||"").toString().toLowerCase();n==="system-only"&&(n="checkin"),(n==="both"||n==="whatsapp-only")&&(n="lead");const l=r.enable_guest_list_submit===!0||r.enable_guest_list_submit==="true"||r.enable_guest_list_submit===1||r.enable_guest_list_submit==="1";if(n==="checkin"||n!=="lead"&&l){I=!0;return}if(n==="lead"||r.enable_guest_list_submit===!1||r.enable_guest_list_submit==="false"){I=!1;return}}}catch{}I=!1}async function Fe(){const t=document.getElementById("loading"),e=document.getElementById("content"),o=document.getElementById("empty");if(!(!t||!e||!o)&&!(window.CkAuth&&typeof window.CkAuth.requireAuth=="function"&&!await window.CkAuth.requireAuth("/login")))try{t.style.display="block",e.style.display="none",o.style.display="none",await Te(),I?await se():await De()}catch(i){document.getElementById("loading").style.display="block",document.getElementById("content").style.display="none",document.getElementById("empty").style.display="none";let r="Erro ao carregar dados";if(i.message?r=i.message:typeof i=="string"&&(r=i),r.includes("Autenticação")||r.includes("401")||r.includes("Unauthorized")){setTimeout(()=>{alert("Sua sessão expirou. Por favor, faça login novamente."),window.location.href="/dashboard"},1e3);return}document.getElementById("loading").innerHTML=`
                    <div style="color: #ff4444; text-align: center; padding: 40px;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 16px; color: #ff4444;"></i>
                        <h3 style="color: #ff4444; margin-bottom: 12px;">Erro ao Carregar Dados</h3>
                        <div style="color: #ECECEC; margin-bottom: 20px;">${v(r)}</div>
                        <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                            <i class="fas fa-redo"></i> Tentar Novamente
                        </button>
                    </div>
                `}}async function se(){try{const t=document.getElementById("page-title"),e=document.getElementById("loading"),o=document.getElementById("content"),i=document.getElementById("tabs-container");if(!e||!o)throw new Error("Elementos do DOM não encontrados");t&&(t.textContent="Confirmação de Check-in");const r=_();let n=!!(r&&r.Authorization);if(!n&&window.CkAuth&&typeof window.CkAuth.probeCookieAuth=="function"&&(n=await window.CkAuth.probeCookieAuth()),!n){e.innerHTML=`
                        <div style="color: #ff4444; text-align: center; padding: 40px;">
                            <i class="fas fa-lock" style="font-size: 3rem; margin-bottom: 16px;"></i>
                            <h3 style="color: #ff4444; margin-bottom: 12px;">Autenticação Necessária</h3>
                            <div style="color: #ECECEC; margin-bottom: 20px;">Por favor, faça login novamente.</div>
                            <button onclick="window.location.href='/login'" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                                <i class="fas fa-sign-in-alt"></i> Ir para Login
                            </button>
                        </div>
                    `;return}const l=await $(`${S}/api/profile/items/${C}`,{headers:r});if(l.ok){const f=await l.json();k.share_token=f.data?.share_token||null}await new Promise(f=>setTimeout(f,300));const a=await $(`${S}/api/guest-lists/${C}`,{headers:r});if(a.ok){const f=await a.json();k.registration_token=f.registration_token,k.confirmation_token=f.confirmation_token,k.public_view_token=f.public_view_token,k.portaria_slug=f.portaria_slug,k.cadastro_slug=f.cadastro_slug||null}const s=document.getElementById("links-hero-section");s&&(s.style.display="none");try{typeof ie=="function"&&ie()}catch{}const c=document.getElementById("tabs-container");if(!c)throw new Error("Elemento tabs-container não encontrado");const d=localStorage.getItem(`activeTab_${C}`)||"registered";c.innerHTML=`
                    <button class="tab-btn ${d==="all"?"active":""}" data-tab="all">
                        <i class="fas fa-users"></i> Escritos (<span id="tab-count-all">0</span>)
                    </button>
                    <button class="tab-btn ${d==="registered"?"active":""}" data-tab="registered">
                        <i class="fas fa-user-plus"></i> Inscritos (<span id="tab-count-registered">0</span>)
                    </button>
                    <button class="tab-btn ${d==="arrived"?"active":""}" data-tab="arrived">
                        <i class="fas fa-check-circle"></i> Quem Chegou (<span id="tab-count-arrived">0</span>)
                    </button>
                    <button class="tab-btn ${d==="not-arrived"?"active":""}" data-tab="not-arrived">
                        <i class="fas fa-clock"></i> Quem Não Chegou (<span id="tab-count-not-arrived">0</span>)
                    </button>
                    <button class="tab-btn ${d==="links"?"active":""}" data-tab="links">
                        <i class="fas fa-link"></i> Links
                    </button>
                    <button class="tab-btn ${d==="pdf-settings"?"active":""}" data-tab="pdf-settings">
                        <i class="fas fa-file-pdf"></i> Personalizar PDF
                    </button>
                    <button class="tab-btn" data-tab="customize-portaria">
                        <i class="fas fa-paint-brush"></i> Personalizar Portaria
                    </button>
                `,E=d;try{typeof Q=="function"&&(Q(),d&&d!=="registered"&&setTimeout(()=>{const f=document.querySelector(`.tab-btn[data-tab="${d}"]`);f&&f.click()},300))}catch{}const p=_();if(!p||Object.keys(p).length===0)throw new Error("Headers de autenticação não disponíveis");await new Promise(f=>setTimeout(f,500));const u=await $(`${S}/api/guest-lists/${C}/guests?mode=checkin&limit=100&offset=0`,{headers:p});if(u.ok){const f=await u.json();b=Array.isArray(f)?f:f.guests||f.data||[],window.__guestListMeta={total:f.total??b.length,limit:f.limit??100,offset:f.offset??0,hasMore:!!f.hasMore}}else if(u.status===404)b=[];else{const f=await u.text();throw new Error(`Erro ao carregar convidados: ${u.status} ${u.statusText}`)}b||(b=[]),(!E||E==="registered")&&(E=d||"registered");try{const f=await $(`${S}/api/guest-lists/${C}`,{headers:_()});if(f.ok){const m=await f.json();if(m.custom_form_fields){let h=m.custom_form_fields;if(typeof h=="string")try{h=JSON.parse(h)}catch{h=[]}Array.isArray(h)&&h.length>0&&(x=h)}}if(!x||x.length===0){await new Promise(h=>setTimeout(h,300));const m=await $(`${S}/api/profile/items/${C}`,{headers:_()});if(m.ok){const h=await m.json();if(h.data&&h.data.digital_form_data&&h.data.digital_form_data.form_fields){const w=h.data.digital_form_data.form_fields;x=Array.isArray(w)?w:typeof w=="string"?JSON.parse(w):[]}}}x.length>0}catch{}try{typeof W=="function"&&W()}catch(f){throw f}const y=document.getElementById("loading"),g=document.getElementById("content");y&&(y.style.display="none"),g&&(g.style.display="block"),typeof K=="function"&&K(),typeof ne=="function"&&ne()}catch{const e=document.getElementById("loading"),o=document.getElementById("content");e&&(e.style.display="block",e.innerHTML=`
                        <div style="color: #ff4444; text-align: center; padding: 40px;">
                            <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 16px;"></i>
                            <h3 style="color: #ff4444; margin-bottom: 12px;">Erro ao Carregar Lista</h3>
                            <div style="color: #ECECEC; margin-bottom: 20px;">Não foi possível carregar os dados dos convidados.</div>
                            <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer; margin-right: 10px;">
                                <i class="fas fa-redo"></i> Tentar Novamente
                            </button>
                            <button onclick="window.location.href='/dashboard'" style="padding: 12px 24px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #ECECEC; font-weight: 600; cursor: pointer;">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </button>
                        </div>
                    `),o&&(o.style.display="none");return}}async function De(){try{const t=document.getElementById("page-title");t&&(t.innerHTML='<i class="fas fa-user-plus"></i> Captação de Clientes');const e=document.getElementById("tabs-container");if(!e)throw new Error("Elemento tabs-container não encontrado");e.innerHTML=`
                    <button class="tab-btn active" data-tab="all">
                        <i class="fas fa-list"></i> Todos (<span id="tab-count-all">0</span>)
                    </button>
                    <button class="tab-btn" data-tab="today">
                        <i class="fas fa-calendar-day"></i> Hoje (<span id="tab-count-today">0</span>)
                    </button>
                    <button class="tab-btn" data-tab="week">
                        <i class="fas fa-calendar-week"></i> Esta Semana (<span id="tab-count-week">0</span>)
                    </button>
                    <button class="tab-btn" data-tab="month">
                        <i class="fas fa-calendar-alt"></i> Este Mês (<span id="tab-count-month">0</span>)
                    </button>
                `;const o=_();if(!o||Object.keys(o).length===0){const y=document.getElementById("loading");y&&(y.innerHTML=`
                            <div style="color: #ff4444; text-align: center; padding: 40px;">
                                <i class="fas fa-lock" style="font-size: 3rem; margin-bottom: 16px;"></i>
                                <h3 style="color: #ff4444; margin-bottom: 12px;">Autenticação Necessária</h3>
                                <div style="color: #ECECEC; margin-bottom: 20px;">Por favor, faça login novamente.</div>
                                <button onclick="window.location.href='/dashboard'" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-sign-in-alt"></i> Ir para Login
                                </button>
                            </div>
                        `);return}await new Promise(y=>setTimeout(y,300));const i=await $(`${S}/api/profile/items/digital_form/${C}/responses?mode=lead&limit=100&offset=0`,{headers:o});await new Promise(y=>setTimeout(y,500));const r=await $(`${S}/api/profile`,{headers:o});if(!i.ok)throw new Error(`Erro ao carregar respostas: ${i.status} ${i.statusText}`);let n=await i.json(),l=Array.isArray(n)?n:n.responses||n.data||[];window.__formResponsesMeta={total:n.total??l.length,limit:n.limit??100,offset:n.offset??0,hasMore:!!n.hasMore,itemId:String(C)};const s=(await r.json()).items?.find(y=>String(y.id)===String(C));b=l,E="all",P="recent";try{x=[];const y=await $(`${S}/api/profile/items/${C}`,{headers:o});if(y.ok){const g=await y.json();let m=(g?.data?.digital_form_data||g?.digital_form_data||{}).form_fields||[];if(typeof m=="string")try{m=JSON.parse(m)}catch{m=[]}x=Array.isArray(m)?m:[]}}catch{x=[]}const c=document.getElementById("export-csv");c&&(c.style.display="inline-flex");const d=document.getElementById("search-input");d&&(d.placeholder="Buscar por nome, CPF, WhatsApp ou email..."),typeof Z=="function"&&Z(),typeof Q=="function"&&Q(),re();const p=document.getElementById("loading"),u=document.getElementById("content");p&&(p.style.display="none"),u&&(u.style.display="block")}catch(t){document.getElementById("loading").style.display="block",document.getElementById("content").style.display="none",document.getElementById("loading").innerHTML=`
                    <div style="color: #ff4444; text-align: center; padding: 40px;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 16px;"></i>
                        <h3 style="color: #ff4444; margin-bottom: 12px;">Erro ao Carregar Formulário</h3>
                        <div style="color: #ECECEC; margin-bottom: 20px;">${t.message||"Erro desconhecido"}</div>
                        <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer; margin-right: 10px;">
                            <i class="fas fa-redo"></i> Tentar Novamente
                        </button>
                        <button onclick="window.location.href='/dashboard'" style="padding: 12px 24px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #ECECEC; font-weight: 600; cursor: pointer;">
                            <i class="fas fa-arrow-left"></i> Voltar
                        </button>
                    </div>
                `}}function re(){const t=window.__formResponsesMeta||{};let e=document.getElementById("form-responses-load-more-wrap");const o=document.getElementById("items-list")?.parentElement;if(!o)return;if(e||(e=document.createElement("div"),e.id="form-responses-load-more-wrap",e.style.cssText="text-align:center;padding:16px 0 8px;",o.appendChild(e)),!t.hasMore){e.innerHTML="",e.style.display="none";return}e.style.display="block";const i=Array.isArray(b)?b.length:0,r=Number(t.total||i);e.innerHTML=`
                <button type="button" id="form-responses-load-more" style="padding:12px 22px;border-radius:10px;border:1px solid rgba(255,255,255,0.15);background:rgba(74,144,226,0.15);color:#ECECEC;font-weight:600;cursor:pointer;">
                    <i class="fas fa-plus"></i> Carregar mais respostas (${i} de ${r})
                </button>`;const n=document.getElementById("form-responses-load-more");n&&(n.onclick=()=>Pe())}async function Pe(){const t=window.__formResponsesMeta||{};if(!t.hasMore||!t.itemId)return;const e=document.getElementById("form-responses-load-more");e&&(e.disabled=!0,e.innerHTML='<i class="fas fa-spinner fa-spin"></i> A carregar…');try{const o=_(),i=Number(t.offset||0)+Number(t.limit||100),r=Number(t.limit||100),n=await $(`${S}/api/profile/items/digital_form/${t.itemId}/responses?mode=lead&limit=${r}&offset=${i}&_nc=${Date.now()}`,{headers:o});if(!n.ok)throw new Error("Falha ao carregar mais respostas");const l=await n.json(),a=Array.isArray(l)?l:l.responses||l.data||[],s=new Set((b||[]).map(c=>String(c.id??c.response_id??"")));a.forEach(c=>{const d=String(c.id??c.response_id??"");d&&s.has(d)||(d&&s.add(d),b.push(c))}),window.__formResponsesMeta={...t,total:l.total??t.total,limit:l.limit??r,offset:l.offset??i,hasMore:!!l.hasMore},typeof Z=="function"&&Z(),re()}catch{e&&(e.disabled=!1,e.innerHTML='<i class="fas fa-exclamation-triangle"></i> Tentar novamente')}}async function ne(){const t=window.__guestListMeta||{};let e=document.getElementById("guest-load-more-btn");e||(e=document.createElement("button"),e.id="guest-load-more-btn",e.type="button",e.className="btn-secondary",e.style.cssText="display:none;margin:16px auto;",e.onclick=async function(){const i=window.__guestListMeta||{};if(!i.hasMore)return;const r=(i.offset||0)+(i.limit||100),n=_(),l=await $(`${S}/api/guest-lists/${C}/guests?mode=checkin&limit=100&offset=${r}`,{headers:n});if(!l.ok)return;const a=await l.json(),s=Array.isArray(a)?a:a.guests||a.data||[];b=(b||[]).concat(s),window.__guestListMeta={total:a.total??b.length,limit:a.limit??100,offset:a.offset??r,hasMore:!!a.hasMore},typeof W=="function"&&W(),ne()},(document.getElementById("content")||document.body).appendChild(e)),t.hasMore?(e.style.display="block",e.innerHTML=`<i class="fas fa-plus"></i> Carregar mais convidados (${(b||[]).length} de ${t.total||"?"})`):e.style.display="none"}function W(){const t=b.length,e=b.filter(u=>u.status==="checked_in").length,o=b.filter(u=>u.status==="registered").length,i=b.filter(u=>u.status==="confirmed").length,r=document.getElementById("tab-count-registered"),n=document.getElementById("tab-count-arrived"),l=document.getElementById("tab-count-not-arrived"),a=document.getElementById("tab-count-confirmed"),s=document.getElementById("tab-count-all");if(r&&(r.textContent=t),n&&(n.textContent=e),l&&(l.textContent=o),a&&(a.textContent=i),s&&(s.textContent=t),E!=="links"&&E!=="pdf-settings"&&E!=="customize-portaria"){Ke();const u=document.getElementById("stats-hero-section");u&&(u.style.display="grid",u.style.visibility="visible")}else{const u=document.getElementById("stats-hero-section");u&&(u.style.display="none",u.style.visibility="hidden")}const c=document.getElementById("stats-grid");c&&(c.style.display="none");const d=document.getElementById("admin-controls");d&&(E!=="links"&&E!=="pdf-settings"&&E!=="customize-portaria"?(d.style.display="flex",d.style.visibility="visible"):(d.style.display="none",d.style.visibility="hidden"));const p=document.querySelector(".search-bar");p&&(E!=="links"&&E!=="pdf-settings"&&E!=="customize-portaria"?(p.style.display="flex",p.style.visibility="visible"):(p.style.display="none",p.style.visibility="hidden")),J()}function J(){const t=document.getElementById("search-input").value.toLowerCase();let e=[...b];if(E==="registered")e=[...b];else if(E==="arrived")e=e.filter(n=>n.status==="checked_in");else if(E==="not-arrived")e=e.filter(n=>n.status==="registered");else if(E==="confirmed")e=e.filter(n=>n.status==="confirmed");else if(E==="all")e=[...b];else if(E==="links"){we();return}const o=document.getElementById("items-list"),i=document.getElementById("links-hero-section"),r=document.getElementById("pdf-settings-container");o&&(o.style.display="block"),i&&(i.style.display="none"),r&&(r.style.display="none"),t&&(e=e.filter(n=>{const l=(n.name||"").toLowerCase(),a=(n.whatsapp||"").toLowerCase(),s=(n.email||"").toLowerCase(),c=(n.document||"").toLowerCase();return l.includes(t)||a.includes(t)||s.includes(t)||c.includes(t)})),ze(e)}function ze(t){const e=document.getElementById("items-list");if(t.length===0){document.getElementById("content").style.display="none",document.getElementById("empty").style.display="block",document.getElementById("empty").querySelector(".empty-icon").innerHTML='<i class="fas fa-users"></i>',document.getElementById("empty").querySelector(".empty-title").textContent="Nenhum convidado encontrado";return}document.getElementById("content").style.display="block",document.getElementById("empty").style.display="none",e.innerHTML=t.map(o=>{const i=o.checked_in_at?new Date(o.checked_in_at).toLocaleString("pt-BR"):"",r=o.confirmed_at?new Date(o.confirmed_at).toLocaleString("pt-BR"):"",n=o.status==="checked_in"||o.status==="confirmed"?"success":o.status==="confirmed"?"info":"warning",l=o.status==="checked_in"?"Chegou":o.status==="confirmed"?"Confirmado":"Não Chegou",a=o.status==="checked_in"?"check-circle":o.status==="confirmed"?"user-check":"clock",{displayName:s,displayEmail:c,displayWhatsapp:d,displayDocument:p}=Ce(o),u=v(s||""),y=v(c||""),g=v(d||""),f=v(p||""),m=v(o.address||""),h=String(Number(o.id)||0),w=v(s||"").replace(/'/g,"&#39;");return`
                    <div class="item-card" data-guest-id="${h}">
                        <div class="item-header">
                            <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                                <input type="checkbox" class="guest-checkbox" data-guest-id="${h}" style="width: 20px; height: 20px; cursor: pointer; accent-color: #FFC700;">
                                <div style="flex: 1;">
                                    <h4 class="item-title">${u}</h4>
                                    <span class="status-badge ${n}">
                                        <i class="fas fa-${a}"></i> ${l}
                                    </span>
                                </div>
                            </div>
                            <div class="item-actions-container" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; width: 100%;">
                                ${o.status!=="checked_in"?`
                                <button class="item-action" onclick="checkInGuest(${h}, '${w}')">
                                    <i class="fas fa-check"></i> <span class="btn-text">Confirmar Chegada</span>
                                </button>
                                `:""}
                                <button class="item-action" style="background: linear-gradient(135deg, #4A90E2, #357ABD);" onclick="viewGuestDetails(${h})">
                                    <i class="fas fa-eye"></i> <span class="btn-text">Ver Inscrição</span>
                                </button>
                                <button class="item-action delete" onclick="deleteGuest(${h}, '${w}')">
                                    <i class="fas fa-times"></i> <span class="btn-text">Excluir</span>
                                </button>
                            </div>
                        </div>
                        <div class="item-details">
                            <div style="font-weight: 600; color: #FFC700; margin-bottom: 8px;">Informações de Contato:</div>
                            <div><i class="fab fa-whatsapp" style="color: #25D366;"></i> <strong>WhatsApp:</strong> ${g}</div>
                            <div><i class="fas fa-envelope" style="color: #FFC700;"></i> <strong>Email:</strong> ${y}</div>
                            ${f?`<div><i class="fas fa-id-card"></i> <strong>CPF/Documento:</strong> ${f}</div>`:""}
                            ${m?`<div><i class="fas fa-map-marker-alt"></i> <strong>Endereço:</strong> ${m}</div>`:""}
                            ${i?`<div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.1);"><i class="fas fa-clock"></i> <strong>Chegou:</strong> ${v(i)}</div>`:""}
                            ${r?`<div><i class="fas fa-check-double"></i> <strong>Confirmado:</strong> ${v(r)}</div>`:""}
                        </div>
                    </div>
                `}).join(""),st()}function F(t){const e=t.response_data||t.responses||{},o=e.name||e.nome||e["Nome completo"]||e.nome_completo||e.Nome;return(t.responder_name||t.name||o||"Cliente sem nome").toString().trim()||"Cliente sem nome"}function N(t){const e=t.response_data||t.responses||{},o=t.responder_email||t.email||e.email||e.Email||e["E-mail"]||"",i=t.responder_phone||t.phone||t.whatsapp||e.whatsapp||e.phone||e.telefone||e["Telefone/WhatsApp"]||e.Telefone||"";return{email:String(o||"").trim(),phone:String(i||"").trim()}}function be(t){const o=(t||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim().charAt(0).toUpperCase();return o>="A"&&o<="Z"?o:"#"}function U(t){if(t==null||t==="")return"—";if(Array.isArray(t))return t.join(", ");if(typeof t=="object")try{return JSON.stringify(t)}catch{return String(t)}return String(t)}function le(t){const e=t.response_data||t.responses||{},o=e.cpf||e.CPF||e.document||e.documento||e.CPF||e.cnpj||e.CNPJ||"";return String(o||"").trim()}function j(t){return String(t||"").replace(/\D/g,"")}function he(t){return String(t.id||t.response_id||(t.submitted_at||"")+"_"+F(t))}function xe(){return"captacao_meta_"+(C||"0")}function ve(){try{return JSON.parse(localStorage.getItem(xe())||"{}")||{}}catch{return{}}}function Me(t){localStorage.setItem(xe(),JSON.stringify(t||{}))}function T(t){return ve()[he(t)]||{contacted:!1,favorite:!1}}function V(t,e){const o=ve(),i=he(t);return o[i]={...o[i]||{contacted:!1,favorite:!1},...e},Me(o),o[i]}function G(t){const e=t.response_data||t.responses||{},o=Object.keys(e||{});for(const i of o){const r=((typeof z=="function"?z(i):i)+" "+i).toLowerCase();if(/l[ií]der|equipe|c[eé]lula|pastor|rede|ministerio|ministério/.test(r)){const n=U(e[i]);if(n&&n!=="—")return String(n).trim()}}for(const i of o){const r=String(i).toLowerCase();if(/lider|líder|equipe|celula|célula|pastor/.test(r)){const n=U(e[i]);if(n&&n!=="—")return String(n).trim()}}return""}function Re(){const t=new Set;return(b||[]).forEach(e=>{const o=G(e);o&&t.add(o)}),Array.from(t).sort((e,o)=>e.localeCompare(o,"pt-BR",{sensitivity:"base"}))}function Ne(t){if(!t)return"Sem data";const e=new Date(t);if(isNaN(e.getTime()))return"Sem data";const o=new Date,i=new Date(o.getFullYear(),o.getMonth(),o.getDate()),r=new Date(e.getFullYear(),e.getMonth(),e.getDate()),n=Math.round((i-r)/864e5);return n===0?"Hoje":n===1?"Ontem":n>1&&n<7?"Esta semana":n>=7&&n<30?"Este mês":e.toLocaleDateString("pt-BR",{month:"long",year:"numeric"})}function de(){let t=document.getElementById("lead-toolbar");const e=document.querySelector(".search-bar");if(!e)return;t||(t=document.createElement("div"),t.id="lead-toolbar",t.className="lead-toolbar",e.parentNode.insertBefore(t,e.nextSibling));const o=Re(),i=o.map(a=>`<option value="${v(a)}" ${R===a?"selected":""}>${v(a)}</option>`).join("");t.innerHTML=`
                <div class="lead-toolbar-filters">
                    <button type="button" class="lead-chip ${D==="all"?"active":""}" data-status="all">Todos</button>
                    <button type="button" class="lead-chip ${D==="pending"?"active":""}" data-status="pending">Pendentes</button>
                    <button type="button" class="lead-chip ok ${D==="contacted"?"active":""}" data-status="contacted">Contatados</button>
                    <button type="button" class="lead-chip ${D==="favorite"?"active":""}" data-status="favorite"><i class="fas fa-star"></i> Favoritos</button>
                </div>
                <div class="lead-sort-row">
                    <label for="lead-sort-select"><i class="fas fa-sort-alpha-down"></i> Ordenar</label>
                    <select id="lead-sort-select" class="lead-sort-select">
                        <option value="recent" ${P==="recent"?"selected":""}>Mais recentes</option>
                        <option value="az" ${P==="az"?"selected":""}>Nome A — Z</option>
                        <option value="za" ${P==="za"?"selected":""}>Nome Z — A</option>
                    </select>
                    ${o.length?`
                    <label for="lead-leader-select"><i class="fas fa-users"></i> Líder/Equipe</label>
                    <select id="lead-leader-select" class="lead-sort-select">
                        <option value="all" ${R==="all"?"selected":""}>Todas</option>
                        ${i}
                    </select>`:""}
                    <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                        <input type="checkbox" id="lead-group-date" ${oe?"checked":""} style="accent-color:#FFC700;">
                        Agrupar por data
                    </label>
                </div>
                <div class="lead-result-count" id="lead-result-count"></div>
            `,t.style.display="flex",t.querySelectorAll(".lead-chip[data-status]").forEach(a=>{a.onclick=()=>{D=a.dataset.status||"all",de(),L()}});const r=document.getElementById("lead-sort-select");r&&(r.onchange=()=>{P=r.value||"recent",L()});const n=document.getElementById("lead-leader-select");n&&(n.onchange=()=>{R=n.value||"all",L()});const l=document.getElementById("lead-group-date");l&&(l.onchange=()=>{oe=!!l.checked,L()})}function K(){const t=document.getElementById("lead-toolbar");t&&(t.style.display="none")}function Oe(t,e){const o=document.getElementById("lead-result-count");o&&(t===e?o.textContent=e+" cliente"+(e===1?"":"s")+" na lista":o.textContent="Mostrando "+t+" de "+e)}function ae(t){const e=document.getElementById("lead-detail-overlay");e&&e.remove(),document.body.style.overflow="hidden";const o=F(t),{email:i,phone:r}=N(t),n=le(t),l=t.submitted_at||t.created_at,a=l?new Date(l).toLocaleString("pt-BR"):"",s=t.response_data||t.responses||{},c=j(r),d=be(o)==="#"?o.slice(0,2).toUpperCase()||"CL":o.split(/\s+/).filter(Boolean).slice(0,2).map(w=>w[0]).join("").toUpperCase(),p=new Set(["name","nome","nome completo","nome_completo","email","e-mail","phone","telefone","whatsapp","telefone/whatsapp","cpf","cnpj","document","documento"]),u=[];Object.entries(s||{}).forEach(([w,M])=>{const A=String(w).toLowerCase();if(p.has(A))return;const H=typeof z=="function"?z(w):w,Y=U(M),Le=String(Y).length>80;u.push(`<div class="lead-detail-field${Le?" wide":""}"><div class="label">${v(H)}</div><div class="value">${v(Y)}</div></div>`)});const y=[];y.push(`<div class="lead-detail-field"><div class="label">Nome completo</div><div class="value">${v(o)}</div></div>`),n&&y.push(`<div class="lead-detail-field"><div class="label">CPF / Documento</div><div class="value">${v(n)}</div></div>`),r&&y.push(`<div class="lead-detail-field"><div class="label">WhatsApp / Telefone</div><div class="value">${v(r)}</div></div>`),i&&y.push(`<div class="lead-detail-field"><div class="label">Email</div><div class="value">${v(i)}</div></div>`),a&&y.push(`<div class="lead-detail-field"><div class="label">Data do cadastro</div><div class="value">${v(a)}</div></div>`);const g=T(t),f=[];if(c){const w=c.startsWith("55")?c:"55"+c;f.push(`<a class="lead-action-btn" style="background:linear-gradient(135deg,#25D366,#128C7E);" href="https://wa.me/${w}" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> WhatsApp</a>`),f.push(`<a class="lead-action-btn" style="background:rgba(74,144,226,0.95);" href="tel:${c}"><i class="fas fa-phone"></i> Ligar</a>`)}i&&f.push(`<a class="lead-action-btn" style="background:linear-gradient(135deg,#FFC700,#FFA500);color:#000;" href="mailto:${v(i)}"><i class="fas fa-envelope"></i> Email</a>`),f.push(`<button type="button" class="lead-action-btn" id="lead-toggle-contacted" style="background:${g.contacted?"rgba(37,211,102,0.25)":"rgba(255,255,255,0.08)"};color:${g.contacted?"#25D366":"#ECECEC"};border:1px solid rgba(255,255,255,0.12);"><i class="fas fa-check"></i> ${g.contacted?"Contatado":"Marcar contatado"}</button>`),f.push(`<button type="button" class="lead-action-btn" id="lead-toggle-favorite" style="background:${g.favorite?"rgba(255,199,0,0.2)":"rgba(255,255,255,0.08)"};color:${g.favorite?"#FFC700":"#ECECEC"};border:1px solid rgba(255,255,255,0.12);"><i class="fas fa-star"></i> ${g.favorite?"Favorito":"Favoritar"}</button>`);const m=document.createElement("div");m.id="lead-detail-overlay",m.className="lead-detail-overlay",m.innerHTML=`
                <div class="lead-detail-page" role="dialog" aria-modal="true" aria-label="Ficha de ${v(o)}">
                    <div class="lead-detail-topbar">
                        <button type="button" class="lead-back-btn" id="lead-detail-close">
                            <i class="fas fa-arrow-left"></i> Voltar à lista
                        </button>
                        <div style="color:#A1A1A1;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;">Ficha do cliente</div>
                    </div>
                    <div class="lead-detail-hero">
                        <div class="lead-avatar">${v(d)}</div>
                        <h1>${v(o)}</h1>
                        <div class="lead-sub">${a?"Cadastrado em "+v(a):"Cliente captado via King Forms"}</div>
                    </div>
                    <div class="lead-action-row">${f.join("")||'<span style="color:#A1A1A1;font-size:13px;">Sem contato rápido disponível</span>'}</div>
                    <div class="lead-detail-section">
                        <div class="lead-detail-section-title"><i class="fas fa-id-card"></i> Dados principais</div>
                        <div class="lead-detail-grid">${y.join("")}</div>
                    </div>
                    ${u.length?`
                    <div class="lead-detail-section">
                        <div class="lead-detail-section-title"><i class="fas fa-folder-open"></i> Respostas do formulário</div>
                        <div class="lead-detail-grid">${u.join("")}</div>
                    </div>`:""}
                </div>
            `,document.body.appendChild(m),m.scrollTop=0;const h=()=>{m.remove(),document.body.style.overflow=""};m.querySelector("#lead-detail-close")?.addEventListener("click",h),m.querySelector("#lead-toggle-contacted")?.addEventListener("click",()=>{const w=!T(t).contacted;V(t,{contacted:w}),ae(t),L()}),m.querySelector("#lead-toggle-favorite")?.addEventListener("click",()=>{const w=!T(t).favorite;V(t,{favorite:w}),ae(t),L()}),document.addEventListener("keydown",function w(M){M.key==="Escape"&&(h(),document.removeEventListener("keydown",w))})}function v(t){return String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Z(){const t=document.getElementById("admin-controls");t&&(t.style.display="none");const e=document.getElementById("stats-hero-section");e&&(e.style.display="none",e.style.visibility="hidden");const o=document.querySelector(".search-bar");o&&(o.style.display="flex",o.style.visibility="visible"),de();const i=b.length,r=Number(window.__formResponsesMeta?.total),n=Number.isFinite(r)&&r>0?r:i,l=new Date().toISOString().split("T")[0],a=new Date;a.setDate(a.getDate()-7);const s=new Date;s.setMonth(s.getMonth()-1);const c=b.filter(m=>new Date(m.submitted_at||m.created_at).toISOString().split("T")[0]===l),d=b.filter(m=>new Date(m.submitted_at||m.created_at)>=a),p=b.filter(m=>new Date(m.submitted_at||m.created_at)>=s),u=b.filter(m=>!!N(m).email).length,y=b.filter(m=>!!N(m).phone).length,g=(m,h)=>{const w=document.getElementById(m);w&&(w.textContent=h)};g("tab-count-all",n),g("tab-count-today",c.length),g("tab-count-week",d.length),g("tab-count-month",p.length);const f=document.getElementById("stats-grid");f&&(f.style.display="grid",f.style.visibility="visible",f.innerHTML=`
                <div class="stat-card purple">
                    <div class="stat-content">
                        <i class="fas fa-user-plus" style="font-size: 1.5rem;"></i>
                        <div class="stat-value">${n}</div>
                    </div>
                    <div class="stat-label">Clientes captados${r>i?` (${i} carregados)`:""}</div>
                </div>
                <div class="stat-card blue">
                    <div class="stat-content">
                        <i class="fas fa-envelope" style="font-size: 1.5rem;"></i>
                        <div class="stat-value">${u}</div>
                    </div>
                    <div class="stat-label">Com Email</div>
                </div>
                <div class="stat-card green">
                    <div class="stat-content">
                        <i class="fab fa-whatsapp" style="font-size: 1.5rem;"></i>
                        <div class="stat-value">${y}</div>
                    </div>
                    <div class="stat-label">Com WhatsApp</div>
                </div>
            `),L()}function L(){const e=(document.getElementById("search-input")?.value||"").toLowerCase().trim();let o=[...b];const i=new Date().toISOString().split("T")[0],r=new Date;r.setDate(r.getDate()-7);const n=new Date;if(n.setMonth(n.getMonth()-1),E==="today"?o=o.filter(a=>new Date(a.submitted_at||a.created_at).toISOString().split("T")[0]===i):E==="week"?o=o.filter(a=>new Date(a.submitted_at||a.created_at)>=r):E==="month"&&(o=o.filter(a=>new Date(a.submitted_at||a.created_at)>=n)),D==="pending"?o=o.filter(a=>!T(a).contacted):D==="contacted"?o=o.filter(a=>!!T(a).contacted):D==="favorite"&&(o=o.filter(a=>!!T(a).favorite)),R&&R!=="all"&&(o=o.filter(a=>G(a)===R)),e){const a=j(e);o=o.filter(s=>{const c=F(s).toLowerCase(),{email:d,phone:p}=N(s),u=le(s),y=G(s).toLowerCase(),g=JSON.stringify(s.response_data||s.responses||{}).toLowerCase(),f=c.includes(e)||d.toLowerCase().includes(e)||p.toLowerCase().includes(e)||u.toLowerCase().includes(e)||y.includes(e)||g.includes(e),m=a.length>=3&&(j(p).includes(a)||j(u).includes(a)||j(g).includes(a));return f||m})}P==="az"?o.sort((a,s)=>F(a).localeCompare(F(s),"pt-BR",{sensitivity:"base"})):P==="za"?o.sort((a,s)=>F(s).localeCompare(F(a),"pt-BR",{sensitivity:"base"})):o.sort((a,s)=>{const c=new Date(a.submitted_at||a.created_at||0).getTime();return new Date(s.submitted_at||s.created_at||0).getTime()-c}),window.__leadFilteredCache=o;const l=Number(window.__formResponsesMeta?.total);Oe(o.length,Number.isFinite(l)&&l>0?l:b.length),He(o),re()}function He(t){const e=document.getElementById("items-list"),o=document.getElementById("pdf-settings-container");if(o&&(o.style.display="none"),!e)return;if(t.length===0){document.getElementById("content").style.display="block";const a=document.getElementById("empty");if(a){a.style.display="block";const s=a.querySelector(".empty-title"),c=a.querySelector(".empty-text");s&&(s.textContent="Nenhum cliente neste filtro"),c&&(c.textContent="Tente outro período, status ou busque por nome, CPF ou WhatsApp.")}e.innerHTML="";return}document.getElementById("content").style.display="block",document.getElementById("empty").style.display="none",window.__leadResponsesCache=t;const i=oe&&P==="recent";let r="",n=null,l=0;t.forEach(a=>{const s=a.submitted_at||a.created_at;if(i){const A=Ne(s);A!==n&&(n=A,r+=`<div class="lead-date-group"><i class="fas fa-calendar-day"></i> ${v(A)}</div>`)}const c=s?new Date(s).toLocaleString("pt-BR"):"",d=F(a),{email:p,phone:u}=N(a),y=be(d),g=T(a),f=G(a),m=a.response_data||a.responses||{},h=Object.entries(m).filter(([A])=>{const H=String(A).toLowerCase();return!["name","nome","nome completo","nome_completo","email","e-mail","phone","telefone","whatsapp","telefone/whatsapp"].includes(H)}).slice(0,2).map(([A,H])=>`${typeof z=="function"?z(A):A}: ${U(H)}`).join(" Â· "),w=l++,M=["item-card","lead-card"];g.contacted&&M.push("contacted"),g.favorite&&M.push("favorited"),r+=`
                    <div class="${M.join(" ")}" data-lead-index="${w}" role="button" tabindex="0">
                        <div class="item-header">
                            <h4 class="item-title" style="display:flex;align-items:center;gap:10px;flex:1;min-width:0;">
                                <span style="width:36px;height:36px;border-radius:10px;background:rgba(255,199,0,0.15);color:#FFC700;display:inline-flex;align-items:center;justify-content:center;font-weight:800;flex-shrink:0;">${v(y)}</span>
                                <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${v(d)}</span>
                            </h4>
                            <div class="lead-mini-actions">
                                <button type="button" class="lead-mini-btn ${g.favorite?"on-star":""}" data-action="favorite" title="Favoritar"><i class="fas fa-star"></i></button>
                                <button type="button" class="lead-mini-btn ${g.contacted?"on-check":""}" data-action="contacted" title="Marcar contatado"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                        <div class="item-details">
                            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                                <span class="lead-status-pill ${g.contacted?"done":"pending"}">
                                    <i class="fas ${g.contacted?"fa-check-circle":"fa-clock"}"></i>
                                    ${g.contacted?"Contatado":"Pendente"}
                                </span>
                                ${f?`<span class="lead-status-pill pending"><i class="fas fa-user-tie"></i> ${v(f)}</span>`:""}
                            </div>
                            ${p?`<div><i class="fas fa-envelope"></i> ${v(p)}</div>`:""}
                            ${u?`<div><i class="fab fa-whatsapp"></i> ${v(u)}</div>`:""}
                            ${c?`<div><i class="fas fa-clock"></i> ${v(c)}</div>`:""}
                            ${h?`<div class="lead-card-preview">${v(h)}</div>`:'<div class="lead-card-preview">Toque para abrir a ficha completa</div>'}
                        </div>
                    </div>
                `}),e.innerHTML=r,e.querySelectorAll(".lead-card").forEach(a=>{const s=()=>{const c=parseInt(a.dataset.leadIndex,10),d=window.__leadResponsesCache?.[c];d&&ae(d)};a.addEventListener("click",c=>{const d=c.target.closest("[data-action]");if(d){c.preventDefault(),c.stopPropagation();const p=parseInt(a.dataset.leadIndex,10),u=window.__leadResponsesCache?.[p];if(!u)return;d.dataset.action==="favorite"?V(u,{favorite:!T(u).favorite}):d.dataset.action==="contacted"&&V(u,{contacted:!T(u).contacted}),L();return}s()}),a.addEventListener("keydown",c=>{(c.key==="Enter"||c.key===" ")&&(c.preventDefault(),s())})})}function we(){const t=document.getElementById("stats-hero-section");t&&(t.style.display="none",t.style.visibility="hidden");const e=document.getElementById("stats-grid");e&&(e.style.display="none",e.style.visibility="hidden");const o=document.getElementById("admin-controls");o&&(o.style.display="none",o.style.visibility="hidden");const i=document.querySelector(".search-bar");i&&(i.style.display="none",i.style.visibility="hidden"),setTimeout(()=>{qe(),Ee()},200);const r=document.getElementById("loading"),n=document.getElementById("empty"),l=document.getElementById("items-list"),a=document.getElementById("pdf-settings-container");r&&(r.style.display="none"),n&&(n.style.display="none"),l&&(l.style.display="none"),a&&(a.style.display="none");const s=document.getElementById("content");s&&(s.style.display="block");const c=document.getElementById("links-hero-section");c&&(c.style.display="block",setTimeout(()=>{ce()},100),ie())}function ie(){const t=document.getElementById("links-hero-section"),e=document.getElementById("stats-hero-section");if(!t)return;const o=(typeof window<"u"&&(window.API_BASE||window.API_URL||window.location.origin)||"").toString().replace(/\/$/,"");document.getElementById("link-cadastro"),document.getElementById("link-portaria");const i=document.getElementById("link-cadastro-original-group"),r=document.getElementById("link-cadastro-personalizado-group"),n=document.getElementById("link-cadastro"),l=document.getElementById("link-cadastro-personalizado"),a=document.getElementById("cadastro-slug-input");a&&(a.value=k.cadastro_slug||""),k.cadastro_slug?(i&&(i.style.display="none"),r&&(r.style.display="flex"),l&&(l.value=`${o}/form/${k.cadastro_slug}`,l.style.color="#ECECEC")):(i&&(i.style.display="flex"),r&&(r.style.display="none"),n&&(k.share_token?(n.value=`${o}/form/${k.share_token}`,n.style.color="#ECECEC"):(n.value="Link não disponível - Salve o formulário primeiro",n.style.color="#A1A1A1")));const s=document.getElementById("link-portaria-original-group"),c=document.getElementById("link-portaria-personalizado-group"),d=document.getElementById("link-portaria"),p=document.getElementById("link-portaria-personalizado");k.portaria_slug?(s&&(s.style.display="none"),c&&(c.style.display="flex"),p&&(p.value=`${o}/portaria/${k.portaria_slug}`,p.style.color="#ECECEC")):(s&&(s.style.display="flex"),c&&(c.style.display="none"),d&&(k.public_view_token?(d.value=`${o}/portaria/${k.public_view_token}`,d.style.color="#ECECEC"):k.confirmation_token?(d.value=`${o}/portaria/${k.confirmation_token}`,d.style.color="#ECECEC"):(d.value="Link não disponível - Salve o formulário primeiro",d.style.color="#A1A1A1")));const u=document.getElementById("portaria-slug-input");u&&(u.value=k.portaria_slug||""),e&&(e.style.display="grid")}function z(t){const e=t.toString();if(!x||!Array.isArray(x)||x.length===0)return/^\d+$/.test(e)?`Campo ${e}`:e.replace(/^field_\d+_/,"").replace(/^field_/,"").replace(/_/g," ")||"Campo";const o=e.match(/field[_-]\d+[_-](\d+)$/i);if(o&&o[1]){const a=parseInt(o[1]);if(a>=0&&a<x.length){const s=x[a];if(s)return s.label||s.question||s.placeholder||s.name||s.title||`Campo ${a+1}`}}if(/^\d+$/.test(e)){const a=parseInt(e);if(a>=0&&a<x.length){const s=x[a];if(s)return s.label||s.question||s.placeholder||s.name||s.title||`Campo ${a+1}`}}const i=e.match(/field[_-](\d+)$/i);if(i&&i[1]){const a=parseInt(i[1]);if(a>=0&&a<x.length){const s=x[a];if(s)return s.label||s.question||s.name||`Campo ${a+1}`}}let r=x.find(a=>{const s=(a.id||"").toString();return s===e||s===`field_${e}`||s===`field${e}`});if(r)return r.label||r.question||r.name||e;const n=e.replace(/^field[_-]?\d+[_-]?/i,"").replace(/[_-]/g,"");if(r=x.find(a=>(a.id||"").toString().replace(/^field[_-]?/i,"").replace(/[_-]/g,"")===n),r)return r.label||r.question||r.name||e;const l=e.toLowerCase();return r=x.find(a=>{const s=(a.label||a.question||a.name||"").toLowerCase();return s.includes(l)||l.includes(s)}),r?r.label||r.question||r.name||e:/^\d+$/.test(e)?`Campo ${parseInt(e)+1}`:e.replace(/^field[_-]?\d+[_-]?/i,"").replace(/[_-]/g," ")||"Campo"}function je(){const t=document.getElementById("cadastro-expires-type").value;document.getElementById("cadastro-expires-hours").style.display=t==="hours"?"block":"none",document.getElementById("cadastro-expires-minutes").style.display=t==="minutes"?"block":"none",document.getElementById("cadastro-expires-date").style.display=t==="date"?"block":"none"}function Ue(){const t=document.getElementById("cadastro-max-uses-type").value;document.getElementById("cadastro-max-uses").style.display=t==="limited"?"block":"none"}function Ge(t){if(t.cadastro_current_uses!==void 0){const e=document.getElementById("cadastro-current-uses-display");e&&(e.textContent=t.cadastro_current_uses||0)}if(t.cadastro_max_uses!==void 0){const e=document.getElementById("cadastro-max-uses-display");e&&(t.cadastro_max_uses===999999||t.cadastro_max_uses===null?e.textContent="Ilimitado":e.textContent=t.cadastro_max_uses)}if(t.cadastro_expires_at){const e=document.getElementById("cadastro-expires-info"),o=document.getElementById("cadastro-expires-display");o&&(o.textContent=new Date(t.cadastro_expires_at).toLocaleString("pt-BR")),e&&(e.style.display="block")}else{const e=document.getElementById("cadastro-expires-info");e&&(e.style.display="none")}}async function qe(){const e=new URLSearchParams(window.location.search).get("itemId");if(e)try{const o=_(),i=(typeof window<"u"&&(window.API_BASE||window.API_URL||window.location.origin)||"").toString().replace(/\/$/,""),r=await O(`${i}/api/guest-lists/${e}`,{headers:o});if(r.ok){const n=await r.json(),l=n.guest_list_data||n,a=document.getElementById("cadastro-description");if(a&&l.cadastro_description&&(a.value=l.cadastro_description),l.cadastro_expires_at){const s=document.getElementById("cadastro-expires-type");if(s){s.value="date";const c=new Date(l.cadastro_expires_at),d=document.getElementById("cadastro-expires-date");d&&(d.value=c.toISOString().slice(0,16)),je()}}if(l.cadastro_max_uses&&l.cadastro_max_uses!==999999){const s=document.getElementById("cadastro-max-uses-type"),c=document.getElementById("cadastro-max-uses");s&&(s.value="limited"),c&&(c.value=l.cadastro_max_uses),Ue()}Ge(l)}}catch{}}async function Ee(){const t=document.getElementById("cadastro-links-list");if(!t)return;const o=new URLSearchParams(window.location.search).get("itemId");if(!o){t.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;">ID do item não encontrado.</p>';return}const i=_(),r=(typeof window<"u"&&(window.API_BASE||window.API_URL||window.location.origin)||"").toString().replace(/\/$/,"");t.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Carregando links personalizados...</p>';try{const n=await O(`${r}/api/guest-lists/${o}/cadastro-links`,{method:"GET",headers:i});if(n.ok){const l=await n.json();l.success&&l.data&&Array.isArray(l.data)&&l.data.length>0?We(l.data):t.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;">Nenhum link personalizado criado ainda.</p>'}else if(n.status===404)t.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;">Nenhum link personalizado criado ainda. Clique em "Criar Múltiplos Links Personalizados" para começar.</p>';else throw new Error(`Erro HTTP: ${n.status}`)}catch(n){n.message.includes("404")||n.message.includes("not found")?t.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;">Nenhum link personalizado criado ainda. Clique em "Criar Múltiplos Links Personalizados" para começar.</p>':t.innerHTML=`<p style="color: #ff4444; text-align: center; padding: 20px; line-height: 1.6;"><i class="fas fa-exclamation-triangle"></i> <strong>Erro ao carregar links:</strong><br>${n.message}</p>`}}function pe(t,e){const o=document.getElementById(t);if(!o)return;const i=o.querySelector(".countdown-text");if(!i)return;function r(){const l=new Date,a=e.getTime()-l.getTime();if(a<=0){i.textContent="Expirado",i.style.color="#ff4444";return}const s=Math.floor(a/(1e3*60*60*24)),c=Math.floor(a%(1e3*60*60*24)/(1e3*60*60)),d=Math.floor(a%(1e3*60*60)/(1e3*60)),p=Math.floor(a%(1e3*60)/1e3);let u="";s>0?u=`${s}d ${c}h ${d}m ${p}s`:c>0?u=`${c}h ${d}m ${p}s`:d>0?u=`${d}m ${p}s`:u=`${p}s`,i.textContent=`Faltam ${u}`,i.style.color="#43e97b"}r();const n=setInterval(()=>{r();const l=new Date;e.getTime()<=l.getTime()&&(clearInterval(n),setTimeout(()=>Ee(),1e3))},1e3)}function We(t){const e=document.getElementById("cadastro-links-list");if(!e)return;if(!t||t.length===0){e.innerHTML='<p style="color: #A1A1A1; text-align: center; padding: 20px;">Nenhum link personalizado criado ainda.</p>';return}const o=(typeof window<"u"&&(window.API_BASE||window.API_URL||window.location.origin)||"").toString().replace(/\/$/,"");new URLSearchParams(window.location.search).get("itemId");const r=n=>{if(!n)return"";const l=document.createElement("div");return l.textContent=String(n),l.innerHTML};e.innerHTML=t.map(n=>{const l=n.isExpired?"expired":n.isUsed?"used":"active",a=l==="active"?"#43e97b":l==="used"?"#ff4444":"#A1A1A1",s=l==="active"?"Disponível":l==="used"?"Usado":"Expirado",c=n.expires_at!==null&&n.expires_at!==void 0,d=n.expires_at?new Date(n.expires_at):null,p=d&&d<new Date,u=`${o}/form/${r(n.slug)}`,y=n.description?r(n.description):"",g=n.id;let f="",m="";if(c&&d&&!p){const h=`countdown-desktop-${g}`,w=`countdown-mobile-${g}`;f=`<div id="${h}" style="color: #43e97b; font-weight: 600; font-size: 13px;">
                        <i class="fas fa-clock"></i> <span class="countdown-text">Calculando...</span>
                    </div>`,m=`<div id="${w}" style="color: #43e97b; font-weight: 600; font-size: 13px;">
                        <i class="fas fa-clock"></i> <span class="countdown-text">Calculando...</span>
                    </div>`}else p?(f='<div style="color: #ff4444; font-weight: 600;"><i class="fas fa-exclamation-triangle"></i> Expirado</div>',m='<div style="color: #ff4444; font-weight: 600;"><i class="fas fa-exclamation-triangle"></i> Expirado</div>'):(f='<div style="color: #43e97b;"><i class="fas fa-infinity"></i> <strong>Sem expiração</strong></div>',m='<div style="color: #43e97b;"><i class="fas fa-infinity"></i> <strong>Sem expiração</strong></div>');return`
                    <div class="personalized-link-item-mobile" style="background: rgba(43,233,123,0.1); border: 1px solid ${a}40; border-radius: 12px; padding: 16px; margin-bottom: 12px;">
                        <!-- Versão Desktop -->
                        <div class="link-item-desktop" style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                                    <span style="padding: 4px 12px; background: ${a}20; color: ${a}; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                        ${s}
                                    </span>
                                    ${y?`<span style="color: #ECECEC; font-weight: 600; font-size: 14px;">${y}</span>`:""}
                                </div>
                                <div class="cadastro-link-input-group" style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 8px; flex-wrap: wrap;">
                                    <input type="text" id="cadastro-link-input-${g}" value="${u}" readonly 
                                           style="flex: 1; min-width: 0; padding: 10px 12px; background: rgba(0,0,0,0.4); border: 1px solid rgba(43,233,123,0.3); border-radius: 8px; color: #ECECEC; font-size: 12px; font-family: monospace; word-break: break-all; overflow-wrap: break-word;">
                                    <button onclick="copyCadastroLink('cadastro-link-input-${g}', event)"
                                            class="cadastro-link-copy-btn"
                                            style="padding: 10px 16px; background: #000; border: 2px solid #43e97b; border-radius: 8px; color: #43e97b; font-weight: 600; cursor: pointer; white-space: nowrap; transition: all 0.3s; min-width: fit-content;"
                                            onmouseover="this.style.background='#43e97b'; this.style.color='#000';"
                                            onmouseout="this.style.background='#000'; this.style.color='#43e97b';">
                                        <i class="fas fa-copy"></i> Copiar
                                    </button>
                                </div>
                                <div style="color: #A1A1A1; font-size: 12px; display: flex; flex-direction: column; gap: 4px;">
                                    ${f}
                                    <div><i class="fas fa-hashtag"></i> Slug: <code style="background: rgba(0,0,0,0.3); padding: 2px 6px; border-radius: 4px;">${r(n.slug)}</code></div>
                                    <div><i class="fas fa-users"></i> Uso: <strong style="color: #ECECEC;">${n.current_uses||0}</strong>/${n.max_uses===999999||n.max_uses===null?"Ilimitado":n.max_uses}</div>
                                </div>
                            </div>
                            <div style="display: flex; gap: 8px; flex-direction: column;">
                                <div style="display: flex; gap: 8px;">
                                    <button onclick="editCadastroLink(${g}, event)" 
                                            style="padding: 8px 12px; background: rgba(67,233,123,0.2); border: 1px solid #43e97b; border-radius: 8px; color: #43e97b; font-weight: 600; cursor: pointer; font-size: 12px; white-space: nowrap;"
                                            title="Editar link">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteCadastroLink(${g}, event)" 
                                            style="padding: 8px 12px; background: rgba(255,68,68,0.2); border: 1px solid #ff4444; border-radius: 8px; color: #ff4444; font-weight: 600; cursor: pointer; font-size: 12px; white-space: nowrap;"
                                            title="Apagar link">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                                <button onclick="toggleActiveCadastroLink(${g}, event)" 
                                        style="padding: 6px 10px; background: ${n.isActiveForProfile?"rgba(67,233,123,0.3)":"rgba(255,68,68,0.1)"}; border: 1px solid ${n.isActiveForProfile?"#43e97b":"#ff4444"}; border-radius: 6px; color: ${n.isActiveForProfile?"#43e97b":"#ff4444"}; font-weight: 600; cursor: pointer; font-size: 11px; white-space: nowrap; width: 100%; transition: all 0.3s;"
                                        onmouseover="this.style.background='${n.isActiveForProfile?"rgba(67,233,123,0.2)":"rgba(255,68,68,0.2)"}';"
                                        onmouseout="this.style.background='${n.isActiveForProfile?"rgba(67,233,123,0.3)":"rgba(255,68,68,0.1)"}';"
                                        title="${n.isActiveForProfile?"Desativar do cartão público":"Ativar no cartão público"}">
                                    <i class="fas fa-${n.isActiveForProfile?"check-circle":"circle"}"></i> ${n.isActiveForProfile?"Ativo":"Ativar"}
                                </button>
                                ${n.isExpired||n.isUsed?`
                                <button onclick="renewCadastroLink(${g}, event)" 
                                        style="padding: 6px 10px; background: rgba(67,233,123,0.1); border: 1px solid #43e97b; border-radius: 6px; color: #43e97b; font-weight: 600; cursor: pointer; font-size: 11px; white-space: nowrap; width: 100%; transition: all 0.3s;"
                                        onmouseover="this.style.background='rgba(67,233,123,0.2)';"
                                        onmouseout="this.style.background='rgba(67,233,123,0.1)';"
                                        title="Renovar link (permitir mais um uso)">
                                    <i class="fas fa-redo"></i> Renovar
                                </button>
                                `:""}
                            </div>
                        </div>
                        <!-- Versão Mobile - Ordem reorganizada -->
                        <div class="link-item-mobile" style="display: none;">
                            ${y?`<div class="link-mobile-name" style="color: #ECECEC; font-weight: 600; font-size: 16px; margin-bottom: 8px;">${y}</div>`:""}
                            <div class="link-mobile-status" style="margin-bottom: 8px;">
                                <span style="padding: 4px 12px; background: ${a}20; color: ${a}; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                    ${s}
                                </span>
                            </div>
                            <div class="link-mobile-slug" style="color: #ECECEC; font-size: 14px; margin-bottom: 8px; font-weight: 600;">
                                <i class="fas fa-hashtag"></i> ${r(n.slug)}
                            </div>
                            <div class="link-mobile-url" style="margin-bottom: 8px;">
                                <input type="text" id="cadastro-link-input-mobile-${g}" value="${u}" readonly 
                                       style="width: 100%; padding: 10px 12px; background: rgba(0,0,0,0.4); border: 1px solid rgba(43,233,123,0.3); border-radius: 8px; color: #ECECEC; font-size: 12px; font-family: monospace; word-break: break-all; overflow-wrap: break-word; box-sizing: border-box;">
                            </div>
                            <div class="link-mobile-copy" style="margin-bottom: 8px;">
                                <button onclick="copyCadastroLink('cadastro-link-input-mobile-${g}', event)"
                                        class="cadastro-link-copy-btn"
                                        style="width: 100%; padding: 10px 16px; background: #000; border: 2px solid #43e97b; border-radius: 8px; color: #43e97b; font-weight: 600; cursor: pointer; transition: all 0.3s; box-sizing: border-box;"
                                        onmouseover="this.style.background='#43e97b'; this.style.color='#000';"
                                        onmouseout="this.style.background='#000'; this.style.color='#43e97b';">
                                    <i class="fas fa-copy"></i> Copiar
                                </button>
                            </div>
                            <div class="link-mobile-actions" style="display: flex; gap: 8px; margin-bottom: 8px;">
                                <button onclick="editCadastroLink(${g}, event)" 
                                        style="flex: 1; padding: 8px 12px; background: rgba(67,233,123,0.2); border: 1px solid #43e97b; border-radius: 8px; color: #43e97b; font-weight: 600; cursor: pointer; font-size: 12px;"
                                        title="Editar link">
                                    <i class="fas fa-edit"></i> Editar
                                </button>
                                <button onclick="deleteCadastroLink(${g}, event)" 
                                        style="flex: 1; padding: 8px 12px; background: rgba(255,68,68,0.2); border: 1px solid #ff4444; border-radius: 8px; color: #ff4444; font-weight: 600; cursor: pointer; font-size: 12px;"
                                        title="Apagar link">
                                    <i class="fas fa-trash"></i> Excluir
                                </button>
                            </div>
                            <div class="link-mobile-activate" style="margin-bottom: 8px;">
                                <button onclick="toggleActiveCadastroLink(${g}, event)" 
                                        style="width: 100%; padding: 8px 12px; background: ${n.isActiveForProfile?"rgba(67,233,123,0.3)":"rgba(255,68,68,0.1)"}; border: 1px solid ${n.isActiveForProfile?"#43e97b":"#ff4444"}; border-radius: 8px; color: ${n.isActiveForProfile?"#43e97b":"#ff4444"}; font-weight: 600; cursor: pointer; font-size: 12px; transition: all 0.3s; box-sizing: border-box;"
                                        title="${n.isActiveForProfile?"Desativar do cartão público":"Ativar no cartão público"}">
                                    <i class="fas fa-${n.isActiveForProfile?"check-circle":"circle"}"></i> ${n.isActiveForProfile?"Ativo":"Ativar"}
                                </button>
                            </div>
                            ${n.isExpired||n.isUsed?`
                            <div class="link-mobile-renew" style="margin-bottom: 8px;">
                                <button onclick="renewCadastroLink(${g}, event)" 
                                        style="width: 100%; padding: 8px 12px; background: rgba(67,233,123,0.1); border: 1px solid #43e97b; border-radius: 8px; color: #43e97b; font-weight: 600; cursor: pointer; font-size: 12px; transition: all 0.3s; box-sizing: border-box;"
                                        title="Renovar link (permitir mais um uso)">
                                    <i class="fas fa-redo"></i> Renovar
                                </button>
                            </div>
                            `:""}
                            <div class="link-mobile-expiration" style="color: #A1A1A1; font-size: 12px;">
                                ${m}
                            </div>
                        </div>
                    </div>
                `}).join(""),t.forEach(n=>{if(n.expires_at&&!n.isExpired){const l=new Date(n.expires_at);pe(`countdown-desktop-${n.id}`,l),pe(`countdown-mobile-${n.id}`,l)}})}function Je(){const t=document.getElementById("renew-link-expires-type").value;document.getElementById("renew-link-expires-minutes").style.display=t==="minutes"?"block":"none",document.getElementById("renew-link-expires-hours").style.display=t==="hours"?"block":"none",document.getElementById("renew-link-expires-days").style.display=t==="days"?"block":"none",document.getElementById("renew-link-expires-datetime").style.display=t==="datetime"?"flex":"none"}function Ve(){const t=document.getElementById("renew-link-max-uses").value,e=document.getElementById("renew-link-max-uses-custom");e&&(e.style.display=t==="custom"?"block":"none")}typeof window<"u"&&(window.toggleRenewExpiresInputs=Je,window.toggleRenewMaxUsesInput=Ve);function Ce(t){let e=t.name||"",o=t.email||"",i=t.whatsapp||t.phone||"",r=t.document||"";if(!e||e.trim()===""||e.toLowerCase()==="visitante"||!o||o.trim()===""||!i||i.trim()===""||!r||r.trim()==="")try{const n=typeof t.custom_responses=="string"?JSON.parse(t.custom_responses):t.custom_responses||{};if(Object.keys(n).forEach(l=>{const a=l.toLowerCase().trim(),s=n[l],c=Array.isArray(s)?s[0]:(s||"").toString().trim();(!e||e.trim()===""||e.toLowerCase()==="visitante")&&(a.includes("nome")||a.includes("name")||a.includes("nome completo"))&&(e=c),(!i||i.trim()==="")&&(a.includes("whatsapp")||a.includes("telefone")||a.includes("phone")||a.includes("celular"))&&(i=c),(!o||o.trim()==="")&&(a.includes("email")||a.includes("e-mail")||a.includes("correio"))&&(o=c),(!r||r.trim()==="")&&(a.includes("cpf")||a.includes("documento")||a.includes("cnpj")||a.includes("document"))&&(r=c)}),(!e||e.trim()===""||e.toLowerCase()==="visitante")&&x&&x.length>0){const l=x.find(a=>{const s=(a.label||"").toLowerCase();return s.includes("nome")||s.includes("name")});if(l&&l.id&&n[l.id]){const a=n[l.id];e=Array.isArray(a)?a[0]:(a||"").toString().trim()}}if((!i||i.trim()==="")&&x&&x.length>0){const l=x.find(a=>{const s=(a.label||"").toLowerCase();return s.includes("whatsapp")||s.includes("telefone")||s.includes("phone")});if(l&&l.id&&n[l.id]){const a=n[l.id];i=Array.isArray(a)?a[0]:(a||"").toString().trim()}}if((!o||o.trim()==="")&&x&&x.length>0){const l=x.find(a=>{const s=(a.label||"").toLowerCase();return s.includes("email")||s.includes("e-mail")});if(l&&l.id&&n[l.id]){const a=n[l.id];o=Array.isArray(a)?a[0]:(a||"").toString().trim()}}if((!r||r.trim()==="")&&x&&x.length>0){const l=x.find(a=>{const s=(a.label||"").toLowerCase();return s.includes("cpf")||s.includes("documento")||s.includes("cnpj")||s.includes("document")});if(l&&l.id&&n[l.id]){const a=n[l.id];r=Array.isArray(a)?a[0]:(a||"").toString().trim()}}}catch{}return e=e&&e.trim()&&e.toLowerCase()!=="visitante"?e.trim():"Sem nome",o=o&&o.trim()?o.trim():"-",i=i&&i.trim()?i.trim():"-",r=r&&r.trim()?r.trim():"",{displayName:e,displayEmail:o,displayWhatsapp:i,displayDocument:r}}function Ke(){if(E==="links"||E==="pdf-settings"||E==="customize-portaria"){const l=document.getElementById("stats-hero-section");l&&(l.style.display="none",l.style.visibility="hidden");return}const t=b.length,e=b.filter(l=>l.status==="checked_in").length,o=b.filter(l=>l.status==="registered"||l.status==="confirmed").length,i=document.getElementById("stat-total"),r=document.getElementById("stat-chegou"),n=document.getElementById("stat-falta");i&&(i.textContent=t),r&&(r.textContent=e),n&&(n.textContent=o)}function Q(){document.querySelectorAll(".tab-btn").forEach(t=>{const e=t.cloneNode(!0);t.parentNode.replaceChild(e,t)}),window.addEventListener("message",t=>{if(t.data&&t.data.type==="customize-portaria-back"&&t.data.action==="switch-tab"&&t.data.tab){const e=document.querySelector(`.tab-btn[data-tab="${t.data.tab}"]`);e&&e.click()}}),document.querySelectorAll(".tab-btn").forEach(t=>{t.addEventListener("click",()=>{document.querySelectorAll(".tab-btn").forEach(g=>g.classList.remove("active")),t.classList.add("active"),E=t.dataset.tab;const o=new URLSearchParams(window.location.search).get("itemId");o&&localStorage.setItem(`activeTab_${o}`,t.dataset.tab);const i=document.getElementById("admin-controls"),r=["registered","arrived","not-arrived","all","confirmed"],l=I?r.includes(t.dataset.tab):["all","today","week","month"].includes(t.dataset.tab);i&&(i.style.display=I&&r.includes(t.dataset.tab)?"flex":"none");const a=document.getElementById("stats-hero-section"),s=document.getElementById("stats-grid"),c=document.querySelector(".search-bar");l?(I?a&&(a.style.display="grid",a.style.visibility="visible"):a&&(a.style.display="none",a.style.visibility="hidden"),s&&(s.style.display="grid",s.style.visibility="visible"),c&&(c.style.display="flex",c.style.visibility="visible"),I?K():de()):(a&&(a.style.display="none",a.style.visibility="hidden"),s&&(s.style.display="none",s.style.visibility="hidden"),c&&(c.style.display="none",c.style.visibility="hidden"),K());const d=document.getElementById("pdf-settings-container"),p=document.getElementById("customize-portaria-container"),u=document.getElementById("items-list"),y=document.getElementById("links-hero-section");d&&(d.style.display="none"),p&&(p.style.display="none"),t.dataset.tab==="pdf-settings"?Ze():t.dataset.tab==="customize-portaria"?Xe():t.dataset.tab==="links"?we():(u&&(u.style.display="block"),y&&(y.style.display="none"),I?J():L())})})}function Ze(){const t=document.getElementById("content"),e=document.getElementById("loading"),o=document.getElementById("items-list"),i=document.getElementById("links-hero-section"),r=document.getElementById("empty"),n=document.getElementById("admin-controls"),l=document.getElementById("customize-portaria-container"),a=document.getElementById("stats-hero-section"),s=document.getElementById("stats-grid"),c=document.querySelector(".search-bar");e&&(e.style.display="none"),o&&(o.style.display="none"),i&&(i.style.display="none"),r&&(r.style.display="none"),n&&(n.style.display="none"),l&&(l.style.display="none"),a&&(a.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="none");let d=document.getElementById("pdf-settings-container");d?d.style.display="block":(d=document.createElement("div"),d.id="pdf-settings-container",d.style.display="block",t.appendChild(d)),t&&(t.style.display="block");const p=Ye();d.innerHTML=`
                <div style="padding: 20px;">
                    <h2 style="color: #FFC700; margin-bottom: 24px; display: flex; align-items: center; gap: 12px;">
                        <i class="fas fa-file-pdf"></i> Personalizar PDF Exportado
                    </h2>
                    
                    <div class="pdf-settings-card" style="background: linear-gradient(135deg, rgba(255,199,0,0.15), rgba(255,199,0,0.05)); border: 2px solid rgba(255,199,0,0.3); border-radius: 16px; padding: 20px 16px; margin-bottom: 20px; box-shadow: 0 4px 20px rgba(255,199,0,0.1);">
                        <h3 style="color: #FFC700; margin-bottom: 20px; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-palette"></i> Cores do PDF
                        </h3>
                        
                        <div style="display: flex; flex-direction: column; gap: 24px;">
                            <!-- Degradê do Cabeçalho -->
                            <div class="pdf-setting-item" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,199,0,0.2); border-radius: 12px; padding: 16px;">
                                <label style="display: block; color: #FFC700; margin-bottom: 12px; font-weight: 700; font-size: 15px;">
                                    <i class="fas fa-fill-drip"></i> Cabeçalho com Degradê
                                </label>
                                
                                <div style="display: flex; flex-direction: column; gap: 16px;">
                                    <div>
                                        <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600; font-size: 13px;">
                                            Cor Inicial (Topo):
                                        </label>
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <input type="color" id="pdf-header-color-start" value="${p.headerColorStart||p.headerColor||"#FFC700"}" 
                                                   style="width: 70px; height: 45px; border: 2px solid rgba(255,199,0,0.5); border-radius: 10px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                                            <input type="text" id="pdf-header-color-start-text" value="${p.headerColorStart||p.headerColor||"#FFC700"}" 
                                                   style="flex: 1; padding: 12px; background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15); border-radius: 10px; color: #ECECEC; font-family: monospace; max-width: 130px; font-size: 13px;">
                                            <button onclick="resetPDFColor('headerStart')" style="padding: 12px 18px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; color: #ECECEC; cursor: pointer; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.background='rgba(255,199,0,0.2)'; this.style.borderColor='#FFC700';" onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                                                <i class="fas fa-undo"></i> Padrão
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600; font-size: 13px;">
                                            Cor Final (Base):
                                        </label>
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <input type="color" id="pdf-header-color-end" value="${p.headerColorEnd||p.headerColor||"#FFB700"}" 
                                                   style="width: 70px; height: 45px; border: 2px solid rgba(255,199,0,0.5); border-radius: 10px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                                            <input type="text" id="pdf-header-color-end-text" value="${p.headerColorEnd||p.headerColor||"#FFB700"}" 
                                                   style="flex: 1; padding: 12px; background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15); border-radius: 10px; color: #ECECEC; font-family: monospace; max-width: 130px; font-size: 13px;">
                                            <button onclick="resetPDFColor('headerEnd')" style="padding: 12px 18px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; color: #ECECEC; cursor: pointer; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.background='rgba(255,199,0,0.2)'; this.style.borderColor='#FFC700';" onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                                                <i class="fas fa-undo"></i> Padrão
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <!-- Preview do degradê -->
                                    <div style="margin-top: 12px; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 10px;">
                                        <label style="display: block; color: #A1A1A1; margin-bottom: 8px; font-size: 12px; font-weight: 600;">
                                            Preview do Degradê:
                                        </label>
                                        <div id="gradient-preview" style="height: 50px; border-radius: 8px; background: linear-gradient(135deg, ${p.headerColorStart||p.headerColor||"#FFC700"}, ${p.headerColorEnd||p.headerColor||"#FFB700"}); border: 2px solid rgba(255,199,0,0.3); box-shadow: inset 0 2px 8px rgba(0,0,0,0.2);"></div>
                                    </div>
                                </div>
                                <p style="color: #A1A1A1; font-size: 12px; margin-top: 12px; line-height: 1.5;">
                                    <i class="fas fa-info-circle"></i> O cabeçalho terá um efeito degradê bonito da cor inicial até a cor final
                                </p>
                            </div>
                            
                            <!-- Cor do Texto do Cabeçalho -->
                            <div class="pdf-setting-item" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,199,0,0.2); border-radius: 12px; padding: 16px;">
                                <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                                    Cor do Texto do Cabeçalho:
                                </label>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <input type="color" id="pdf-header-text-color" value="${p.headerTextColor}" 
                                           style="width: 70px; height: 45px; border: 2px solid rgba(255,199,0,0.5); border-radius: 10px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                                    <input type="text" id="pdf-header-text-color-text" value="${p.headerTextColor}" 
                                           style="flex: 1; padding: 12px; background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15); border-radius: 10px; color: #ECECEC; font-family: monospace; max-width: 130px; font-size: 13px;">
                                    <button onclick="resetPDFColor('headerText')" style="padding: 12px 18px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; color: #ECECEC; cursor: pointer; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.background='rgba(255,199,0,0.2)'; this.style.borderColor='#FFC700';" onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                                        <i class="fas fa-undo"></i> Padrão
                                    </button>
                                </div>
                                <p style="color: #A1A1A1; font-size: 12px; margin-top: 8px;">
                                    Cor do texto no cabeçalho (recomendado: branco ou preto para contraste)
                                </p>
                            </div>
                            
                            <!-- Cor do Texto Normal -->
                            <div class="pdf-setting-item" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,199,0,0.2); border-radius: 12px; padding: 16px;">
                                <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                                    Cor do Texto Normal (Conteúdo):
                                </label>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <input type="color" id="pdf-text-color" value="${p.textColor||"#000000"}" 
                                           style="width: 70px; height: 45px; border: 2px solid rgba(255,199,0,0.5); border-radius: 10px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                                    <input type="text" id="pdf-text-color-text" value="${p.textColor||"#000000"}" 
                                           style="flex: 1; padding: 12px; background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15); border-radius: 10px; color: #ECECEC; font-family: monospace; max-width: 130px; font-size: 13px;">
                                    <button onclick="resetPDFColor('text')" style="padding: 12px 18px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; color: #ECECEC; cursor: pointer; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.background='rgba(255,199,0,0.2)'; this.style.borderColor='#FFC700';" onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                                        <i class="fas fa-undo"></i> Padrão
                                    </button>
                                </div>
                                <p style="color: #A1A1A1; font-size: 12px; margin-top: 8px;">
                                    Cor do texto do conteúdo do PDF (nome, informações, etc.)
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div style="background: rgba(255,199,0,0.1); border: 2px solid rgba(255,199,0,0.3); border-radius: 16px; padding: 20px 16px; margin-bottom: 20px;">
                        <h3 style="color: #FFC700; margin-bottom: 16px; font-size: 18px;">
                            <i class="fas fa-image"></i> Logomarca
                        </h3>
                        
                        <div style="display: flex; flex-direction: column; gap: 16px;">
                            <div>
                                <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600;">
                                    Logo do PDF:
                                </label>
                                <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                                    <div id="pdf-logo-preview" style="width: 120px; height: 120px; border: 2px dashed rgba(255,199,0,0.5); border-radius: 12px; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.05); overflow: hidden;">
                                        ${p.logoUrl?`<img src="${p.logoUrl}" style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="Logo">`:`<div style="text-align: center; color: #A1A1A1;">
                                                <i class="fas fa-image" style="font-size: 32px; margin-bottom: 8px;"></i>
                                                <div style="font-size: 12px;">Sem logo</div>
                                            </div>`}
                                    </div>
                                    <div style="flex: 1; min-width: 200px;">
                                        <input type="file" id="pdf-logo-input" accept="image/*" 
                                               style="display: none;" onchange="handleLogoUpload(event)">
                                        <button onclick="document.getElementById('pdf-logo-input').click()" 
                                                style="padding: 12px 24px; background: linear-gradient(135deg, #FFC700, #FFB700); border: none; border-radius: 8px; color: #000; font-weight: 600; cursor: pointer; margin-bottom: 8px; display: block; width: 100%;">
                                            <i class="fas fa-upload"></i> ${p.logoUrl?"Alterar Logo":"Adicionar Logo"}
                                        </button>
                                        ${p.logoUrl?`<button onclick="removePDFLogo()" style="padding: 10px 20px; background: rgba(255,68,68,0.2); border: 1px solid rgba(255,68,68,0.5); border-radius: 8px; color: #ff4444; font-weight: 600; cursor: pointer; width: 100%;">
                                                <i class="fas fa-trash"></i> Remover Logo
                                            </button>`:""}
                                        <p style="color: #A1A1A1; font-size: 12px; margin-top: 8px;">
                                            Formatos aceitos: PNG, JPG, SVG (recomendado: PNG transparente)
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label style="display: block; color: #ECECEC; margin-bottom: 8px; font-weight: 600;">
                                    Tamanho da Logo:
                                </label>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <input type="range" id="pdf-logo-size" min="20" max="80" value="${p.logoSize}" 
                                           style="flex: 1;" oninput="updateLogoSize(this.value)">
                                    <span id="pdf-logo-size-value" style="color: #FFC700; font-weight: 600; min-width: 50px;">${p.logoSize}mm</span>
                                </div>
                                <p style="color: #A1A1A1; font-size: 12px; margin-top: 6px;">
                                    Ajuste o tamanho da logo no PDF (20mm a 80mm)
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                        <button onclick="savePDFSettings()" 
                                style="padding: 14px 28px; background: linear-gradient(135deg, #43e97b, #38f9d7); border: none; border-radius: 12px; color: #000; font-weight: 700; cursor: pointer; font-size: 16px;">
                            <i class="fas fa-save"></i> Salvar Configurações
                        </button>
                    </div>
                </div>
            `,Qe(),typeof window<"u"&&(window.handleLogoUpload=Se,window.removePDFLogo=_e,window.updateLogoSize=$e,window.savePDFSettings=ke,window.resetPDFColor=Ie,window.updateGradientPreview=B),setTimeout(()=>{typeof B=="function"&&B()},150)}function Qe(){const t=document.getElementById("pdf-header-color-start"),e=document.getElementById("pdf-header-color-start-text");t&&e&&(t.addEventListener("input",s=>{e.value=s.target.value,B()}),e.addEventListener("input",s=>{/^#[0-9A-F]{6}$/i.test(s.target.value)&&(t.value=s.target.value,B())}));const o=document.getElementById("pdf-header-color-end"),i=document.getElementById("pdf-header-color-end-text");o&&i&&(o.addEventListener("input",s=>{i.value=s.target.value,B()}),i.addEventListener("input",s=>{/^#[0-9A-F]{6}$/i.test(s.target.value)&&(o.value=s.target.value,B())}));const r=document.getElementById("pdf-header-text-color"),n=document.getElementById("pdf-header-text-color-text");r&&n&&(r.addEventListener("input",s=>{n.value=s.target.value}),n.addEventListener("input",s=>{/^#[0-9A-F]{6}$/i.test(s.target.value)&&(r.value=s.target.value)}));const l=document.getElementById("pdf-text-color"),a=document.getElementById("pdf-text-color-text");l&&a&&(l.addEventListener("input",s=>{a.value=s.target.value}),a.addEventListener("input",s=>{/^#[0-9A-F]{6}$/i.test(s.target.value)&&(l.value=s.target.value)}))}function B(){const t=document.getElementById("gradient-preview");if(t){const e=document.getElementById("pdf-header-color-start")?.value||"#FFC700",o=document.getElementById("pdf-header-color-end")?.value||"#FFB700";t.style.background=`linear-gradient(135deg, ${e}, ${o})`}}function Ye(){const t={headerColor:"#FFC700",headerColorStart:"#FFC700",headerColorEnd:"#FFB700",headerTextColor:"#000000",textColor:"#000000",logoUrl:null,logoSize:40},e=localStorage.getItem(`pdfSettings_${C}`);if(e)try{const o=JSON.parse(e);return o.headerColor&&!o.headerColorStart&&(o.headerColorStart=o.headerColor,o.headerColorEnd=o.headerColor),{...t,...o}}catch{return t}return t}function ke(){const t={headerColorStart:document.getElementById("pdf-header-color-start").value,headerColorEnd:document.getElementById("pdf-header-color-end").value,headerTextColor:document.getElementById("pdf-header-text-color").value,textColor:document.getElementById("pdf-text-color").value,logoUrl:document.getElementById("pdf-logo-preview").querySelector("img")?.src||null,logoSize:parseInt(document.getElementById("pdf-logo-size").value)};localStorage.setItem(`pdfSettings_${C}`,JSON.stringify(t));const e=event.target,o=e.innerHTML;e.innerHTML='<i class="fas fa-check"></i> Salvo!',e.style.background="linear-gradient(135deg, #43e97b, #38f9d7)",setTimeout(()=>{e.innerHTML=o,e.style.background="linear-gradient(135deg, #43e97b, #38f9d7)"},2e3)}function Ie(t){const e={headerColorStart:"#FFC700",headerColorEnd:"#FFB700",headerTextColor:"#000000",textColor:"#000000"};t==="headerStart"?(document.getElementById("pdf-header-color-start").value=e.headerColorStart,document.getElementById("pdf-header-color-start-text").value=e.headerColorStart,B()):t==="headerEnd"?(document.getElementById("pdf-header-color-end").value=e.headerColorEnd,document.getElementById("pdf-header-color-end-text").value=e.headerColorEnd,B()):t==="headerText"?(document.getElementById("pdf-header-text-color").value=e.headerTextColor,document.getElementById("pdf-header-text-color-text").value=e.headerTextColor):t==="text"&&(document.getElementById("pdf-text-color").value=e.textColor,document.getElementById("pdf-text-color-text").value=e.textColor)}function Se(t){const e=t.target.files[0];if(!e)return;if(!e.type.startsWith("image/")){alert("Por favor, selecione um arquivo de imagem válido.");return}const o=new FileReader;o.onload=i=>{const r=document.getElementById("pdf-logo-preview");r.innerHTML=`<img src="${i.target.result}" style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="Logo">`;const n=r.nextElementSibling?.querySelector("button");n&&(n.innerHTML='<i class="fas fa-upload"></i> Alterar Logo')},o.readAsDataURL(e)}function _e(){const t=document.getElementById("pdf-logo-preview");t.innerHTML=`
                <div style="text-align: center; color: #A1A1A1;">
                    <i class="fas fa-image" style="font-size: 32px; margin-bottom: 8px;"></i>
                    <div style="font-size: 12px;">Sem logo</div>
                </div>
            `;const e=t.nextElementSibling?.querySelector("button");e&&(e.innerHTML='<i class="fas fa-upload"></i> Adicionar Logo')}function $e(t){document.getElementById("pdf-logo-size-value").textContent=`${t}mm`}typeof window<"u"&&(window.handleLogoUpload=Se,window.removePDFLogo=_e,window.updateLogoSize=$e,window.savePDFSettings=ke,window.resetPDFColor=Ie,window.updateGradientPreview=B);async function Xe(){const t=document.getElementById("content"),e=document.getElementById("loading"),o=document.getElementById("items-list"),i=document.getElementById("links-hero-section"),r=document.getElementById("empty"),n=document.getElementById("admin-controls"),l=document.getElementById("pdf-settings-container"),a=document.getElementById("stats-hero-section"),s=document.getElementById("stats-grid"),c=document.querySelector(".search-bar");e&&(e.style.display="none"),o&&(o.style.display="none"),i&&(i.style.display="none"),r&&(r.style.display="none"),n&&(n.style.display="none"),l&&(l.style.display="none"),a&&(a.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="none");let d=document.getElementById("customize-portaria-container");d?d.style.display="block":(d=document.createElement("div"),d.id="customize-portaria-container",d.style.display="block",d.style.width="100%",d.style.height="100%",d.style.minHeight="600px",d.style.border="none",d.style.overflow="hidden",t.appendChild(d)),t&&(t.style.display="block");let p=localStorage.getItem("conectaKingToken")||localStorage.getItem("authToken")||sessionStorage.getItem("authToken")||localStorage.getItem("userToken")||sessionStorage.getItem("userToken")||localStorage.getItem("token")||sessionStorage.getItem("token");if(!p){const m=localStorage.getItem("user")||sessionStorage.getItem("user");if(m)try{const h=JSON.parse(m);p=h.token||h.authToken||h.accessToken}catch{}}const u=C||new URLSearchParams(window.location.search).get("itemId");if(!u){d.innerHTML=`
                    <div style="padding: 40px; text-align: center;">
                        <h2 style="color: #FFC700; margin-bottom: 24px;">
                            <i class="fas fa-exclamation-triangle"></i> Erro
                        </h2>
                        <p style="color: #ECECEC; margin-bottom: 24px;">
                            ID do item não encontrado. Por favor, acesse a página de Confirmação de Check-in novamente.
                        </p>
                    </div>
                `;return}try{p&&await O((window.API_BASE||window.API_URL||window.location.origin||"").replace(/\/$/,"")+"/api/auth/sync-session-cookie",{method:"POST",credentials:"include",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+p},body:"{}"})}catch{}const g=`${(window.API_BASE||window.API_URL||window.location.origin||"").replace(/\/$/,"")}/api/guest-lists/${u}/customize-portaria`;d.innerHTML=`
                <iframe 
                    id="customize-portaria-iframe"
                    src="${g}" 
                    style="width: 100%; height: calc(100vh - 200px); min-height: 600px; border: none; border-radius: 16px; overflow: hidden; background: transparent;"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals allow-top-navigation"
                    title="Personalizar Portaria"
                    allow="camera; microphone"
                    loading="eager"
                ></iframe>
            `;const f=document.getElementById("customize-portaria-iframe");f&&(f.onload=function(){},f.onerror=function(m){d.innerHTML=`
                        <div style="padding: 40px; text-align: center;">
                            <h2 style="color: #FFC700; margin-bottom: 24px;">
                                <i class="fas fa-exclamation-triangle"></i> Erro ao Carregar
                            </h2>
                            <p style="color: #ECECEC; margin-bottom: 24px;">
                                Não foi possível carregar a página de personalização. Por favor, verifique sua conexão e tente novamente.
                            </p>
                            <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #FFC700, #FFB700); border: none; border-radius: 8px; color: #000; font-weight: 600; cursor: pointer; margin-right: 12px;">
                                <i class="fas fa-sync-alt"></i> Recarregar
                            </button>
                        </div>
                    `})}function te(){const t=document.querySelectorAll(".guest-checkbox:not(#select-all-checkbox)"),e=Array.from(t).filter(n=>n.checked).length,o=document.getElementById("selected-count"),i=document.getElementById("delete-selected-btn"),r=document.getElementById("select-all-checkbox");o&&(o.textContent=e),i&&(i.style.display=e>0?"inline-flex":"none"),r&&(r.checked=e>0&&e===t.length,r.indeterminate=e>0&&e<t.length)}async function et(){const t=document.querySelectorAll(".guest-checkbox:not(#select-all-checkbox):checked"),e=Array.from(t).map(i=>parseInt(i.dataset.guestId));if(e.length===0){alert("Nenhum convidado selecionado.");return}if(!confirm(`Tem certeza que deseja excluir ${e.length} convidado(s)? Esta ação não pode ser desfeita.`))return;const o=document.getElementById("delete-selected-btn");o&&(o.disabled=!0,o.innerHTML='<i class="fas fa-spinner fa-spin"></i> Excluindo...');try{const i=_();if(!i||Object.keys(i).length===0){alert("Sua sessão expirou. Por favor, faça login novamente."),window.location.href="/dashboard";return}const r=await O(`${S}/api/guest-lists/${C}/guests/delete-bulk`,{method:"POST",headers:{...i,"Content-Type":"application/json"},body:JSON.stringify({guestIds:e})}),n=await r.json().catch(()=>({success:!1}));if(r.ok&&n.success!==!1)alert(`${n.deleted_count??e.length} convidado(s) excluído(s) com sucesso.`),await se();else throw new Error(n.message||"Alguns convidados não puderam ser excluídos")}catch(i){alert("Erro ao excluir convidados: "+i.message)}finally{o&&(o.disabled=!1,o.innerHTML='<i class="fas fa-trash-alt"></i> Excluir Selecionados (<span id="selected-count">0</span>)')}}async function tt(){if(!confirm("Tem certeza que deseja excluir TODOS os convidados? Esta ação não pode ser desfeita."))return;const t=document.getElementById("delete-all-btn");t&&(t.disabled=!0,t.innerHTML='<i class="fas fa-spinner fa-spin"></i> Excluindo...');try{const e=_();if(!e||Object.keys(e).length===0){alert("Sua sessão expirou. Por favor, faça login novamente."),window.location.href="/dashboard";return}const o=await O(`${S}/api/guest-lists/${C}/guests`,{method:"DELETE",headers:e}),i=await o.json();if(o.ok&&i.success)alert(`Todos os convidados foram excluídos com sucesso (${i.deleted_count||0} excluídos).`),await se();else throw new Error(i.message||"Erro ao excluir convidados")}catch(e){alert("Erro ao excluir convidados: "+e.message)}finally{t&&(t.disabled=!1,t.innerHTML='<i class="fas fa-trash"></i> Excluir Todos')}}function ue(){I?ot():nt()}function ot(){const{jsPDF:t}=window.jspdf,e=new t;e.setFontSize(20),e.text("Lista de Convidados",14,20),e.setFontSize(12);let o=35;const i=b.length,r=b.filter(a=>a.status==="checked_in").length,n=b.filter(a=>a.status==="registered"||a.status==="confirmed").length;e.text(`Cadastrados: ${i}`,14,o),o+=7,e.text(`Não Chegou: ${n}`,14,o),o+=7,e.text(`Chegou: ${r}`,14,o),o+=15,e.setFontSize(10),e.setFont(void 0,"bold"),e.text("Nome",14,o),e.text("WhatsApp",60,o),e.text("Email",105,o),e.text("Status",150,o),e.text("Chegada",180,o),o+=7,e.setLineWidth(.5),e.line(14,o,200,o),o+=5,e.setFont(void 0,"normal"),e.setFontSize(9),b.forEach((a,s)=>{o>270&&(e.addPage(),o=20,e.setFontSize(10),e.setFont(void 0,"bold"),e.text("Nome",14,o),e.text("WhatsApp",60,o),e.text("Email",105,o),e.text("Status",150,o),e.text("Chegada",180,o),o+=7,e.line(14,o,200,o),o+=5,e.setFont(void 0,"normal"),e.setFontSize(9));const{displayName:c,displayEmail:d,displayWhatsapp:p}=Ce(a),u=a.checked_in_at?new Date(a.checked_in_at).toLocaleDateString("pt-BR"):"-",y=a.status==="checked_in"?"Chegou":a.status==="confirmed"?"Confirmado":"Não Chegou";e.text(c.substring(0,25),14,o),e.text(p.substring(0,15),60,o),e.text(d.substring(0,20),105,o),e.text(y,150,o),e.text(u.substring(0,10),180,o),o+=7});const l=`lista_convidados_${new Date().toISOString().split("T")[0]}.pdf`;e.save(l)}function nt(){const{jsPDF:t}=window.jspdf,e=new t;e.text("Exportação de respostas em PDF - Em desenvolvimento",14,20),e.save("respostas.pdf")}function fe(){I?at():it()}function at(){const t=["Nome","WhatsApp","Email","CPF/CNPJ","Status","Data de Chegada","Data de Confirmação"],e=b.map(n=>[n.name||"",n.whatsapp||"",n.email||"",n.document||"",n.status==="checked_in"?"Chegou":n.status==="confirmed"?"Confirmado":"Não Chegou",n.checked_in_at?new Date(n.checked_in_at).toLocaleString("pt-BR"):"",n.confirmed_at?new Date(n.confirmed_at).toLocaleString("pt-BR"):""]),o=[t.join(","),...e.map(n=>n.map(l=>`"${l}"`).join(","))].join(`
`),i=new Blob(["\uFEFF"+o],{type:"text/csv;charset=utf-8;"}),r=document.createElement("a");r.href=URL.createObjectURL(i),r.download=`lista_convidados_${new Date().toISOString().split("T")[0]}.csv`,r.click()}function it(){const t=Array.isArray(window.__leadFilteredCache)?window.__leadFilteredCache:window.__leadResponsesCache||b||[];if(!t.length){alert("Não há clientes para exportar neste filtro.");return}const e=new Set;t.forEach(s=>{const c=s.response_data||s.responses||{};Object.keys(c||{}).forEach(d=>e.add(d))});const o=Array.from(e),i=["Nome","WhatsApp","Email","CPF","Lider/Equipe","Status","Favorito","Data cadastro",...o.map(s=>typeof z=="function"?z(s):s)],r=t.map(s=>{const{email:c,phone:d}=N(s),p=T(s),u=s.response_data||s.responses||{},y=s.submitted_at||s.created_at,g=[F(s),d,c,le(s),G(s),p.contacted?"Contatado":"Pendente",p.favorite?"Sim":"Não",y?new Date(y).toLocaleString("pt-BR"):""],f=o.map(m=>U(u[m]));return[...g,...f]}),n=[i.join(","),...r.map(s=>s.map(c=>'"'+String(c??"").replace(/"/g,'""')+'"').join(","))].join(`
`),l=new Blob(["\uFEFF"+n],{type:"text/csv;charset=utf-8;"}),a=document.createElement("a");a.href=URL.createObjectURL(l),a.download="captacao_clientes_"+new Date().toISOString().split("T")[0]+".csv",a.click()}function me(){try{const t=document.getElementById("search-input");t&&t.addEventListener("input",()=>{I?typeof J=="function"&&J():typeof L=="function"&&L()});const e=document.getElementById("export-pdf");e&&typeof ue=="function"&&e.addEventListener("click",ue);const o=document.getElementById("export-csv");o&&typeof fe=="function"&&o.addEventListener("click",fe);const i=document.getElementById("btn-voltar");i&&(i.onclick=function(r){r.preventDefault(),r.stopPropagation();const n=C||new URLSearchParams(window.location.search).get("itemId");return n?window.location.href=`/formPageEdit?itemId=${n}`:window.location.href="/dashboard",!1},C?i.href=`/formPageEdit?itemId=${C}`:i.href="/dashboard")}catch{}}function st(){try{const t=document.getElementById("select-all-checkbox");t&&(t.onclick=function(){document.querySelectorAll(".guest-checkbox:not(#select-all-checkbox)").forEach(n=>n.checked=t.checked),te()}),document.querySelectorAll(".guest-checkbox:not(#select-all-checkbox)").forEach(r=>{r.onclick=te});const o=document.getElementById("delete-selected-btn");o&&(o.onclick=et);const i=document.getElementById("delete-all-btn");i&&(i.onclick=tt),te()}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",me):setTimeout(me,100);window.addEventListener("error",function(t){const e=document.getElementById("loading");e&&e.style.display!=="none"&&(e.innerHTML=`
                    <div style="color: #ff4444; text-align: center; padding: 40px;">
                        <i class="fas fa-bug" style="font-size: 3rem; margin-bottom: 16px;"></i>
                        <h3 style="color: #ff4444; margin-bottom: 12px;">Erro no JavaScript</h3>
                        <div style="color: #ECECEC; margin-bottom: 20px; font-family: monospace; font-size: 12px; background: rgba(0,0,0,0.3); padding: 12px; border-radius: 8px; max-width: 600px; margin: 0 auto 20px;">
                            ${t.message||"Erro desconhecido"}
                        </div>
                        <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                            <i class="fas fa-redo"></i> Recarregar Página
                        </button>
                    </div>
                `)});window.addEventListener("unhandledrejection",function(t){t.preventDefault()});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ge):setTimeout(ge,100);function ce(){const t=document.getElementById("links-hero-section");return t&&window.innerWidth<=768?(t.style.setProperty("overflow-y","visible","important"),t.style.setProperty("overflow-x","hidden","important"),t.style.setProperty("max-height","none","important"),t.style.setProperty("height","auto","important"),t.style.setProperty("webkit-overflow-scrolling","auto","important"),t.style.setProperty("ms-overflow-style","none","important"),t.style.setProperty("scrollbar-width","none","important"),t.style.setProperty("width","100%","important"),t.style.setProperty("max-width","100%","important"),t.style.setProperty("margin","0","important"),t.style.setProperty("padding","8px 0","important"),t.style.setProperty("padding-left","0","important"),t.style.setProperty("padding-right","0","important"),t.style.setProperty("box-sizing","border-box","important"),t.style.setProperty("position","relative","important"),!0):!1}typeof MutationObserver<"u"&&setTimeout(()=>{const t=document.getElementById("links-hero-section");t&&new MutationObserver(o=>{o.forEach(i=>{if(i.type==="attributes"&&i.attributeName==="style"){const r=i.target;r.id==="links-hero-section"&&r.style.display==="block"&&setTimeout(ce,100)}})}).observe(t,{attributes:!0,attributeFilter:["style","class"]})},1e3);window.addEventListener("resize",()=>{window.innerWidth<=768&&ce()});function ge(){try{const t=document.getElementById("loading"),e=document.getElementById("content"),o=document.getElementById("empty");if(!t||!e||!o){document.body.innerHTML=`
                        <div style="color: #ff4444; text-align: center; padding: 40px;">
                            <h1>Erro: Elementos do DOM não encontrados</h1>
                            <p>Por favor, recarregue a página.</p>
                            <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                                Recarregar
                            </button>
                        </div>
                    `;return}if(C)Fe().catch(i=>{const r=document.getElementById("loading");r&&(r.innerHTML=`
                                <div style="color: #ff4444; text-align: center; padding: 40px;">
                                    <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 16px;"></i>
                                    <h3 style="color: #ff4444; margin-bottom: 12px;">Erro ao Carregar</h3>
                                    <div style="color: #ECECEC; margin-bottom: 20px; font-family: monospace; font-size: 12px; background: rgba(0,0,0,0.3); padding: 12px; border-radius: 8px; max-width: 600px; margin: 0 auto 20px;">
                                        ${i.message||"Erro desconhecido"}
                                    </div>
                                    <div style="display: flex; gap: 12px; justify-content: center;">
                                        <button onclick="location.reload()" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                                            <i class="fas fa-redo"></i> Tentar Novamente
                                        </button>
                                        <button onclick="window.location.href='/dashboard'" style="padding: 12px 24px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #ECECEC; font-weight: 600; cursor: pointer;">
                                            <i class="fas fa-arrow-left"></i> Voltar
                                        </button>
                                    </div>
                                </div>
                            `)});else{const i=document.getElementById("loading");i&&(i.innerHTML=`
                            <div style="color: #ff4444; text-align: center; padding: 40px;">
                                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 16px;"></i>
                                <h3 style="color: #ff4444; margin-bottom: 12px;">ID do Item Não Fornecido</h3>
                                <div style="color: #ECECEC; margin-bottom: 20px;">Por favor, acesse esta página através do dashboard.</div>
                                <button onclick="window.location.href='/dashboard'" style="padding: 12px 24px; background: linear-gradient(135deg, #4A90E2, #357ABD); border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-arrow-left"></i> Voltar ao Dashboard
                                </button>
                            </div>
                        `)}}catch{}}
