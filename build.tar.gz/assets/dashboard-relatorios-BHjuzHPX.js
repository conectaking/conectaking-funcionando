(function(g){function _(){return g.DashboardCore||{}}var d={get API_URL(){var t=_();return typeof t.getApiUrl=="function"?t.getApiUrl()||"":g.API_URL||g.API_BASE||""},get HEADERS(){var t=_();return typeof t.getHeaders=="function"?t.getHeaders()||{}:{"Content-Type":"application/json"}},get HEADERS_AUTH(){var t=_();return typeof t.getHeadersAuth=="function"?t.getHeadersAuth()||{}:{}}},r={periodSelector:function(){return document.getElementById("period-selector")},kpiTotalViews:function(){return document.getElementById("kpi-total-views")},kpiTotalClicks:function(){return document.getElementById("kpi-total-clicks")},kpiCtr:function(){return document.getElementById("kpi-ctr")},kpiTotalSaves:function(){return document.getElementById("kpi-total-saves")},performanceChartCanvas:function(){return document.getElementById("performance-chart")},topItemsList:function(){return document.getElementById("top-items-list")}},L=null,I=null,$=null,S=!1;async function P(t="30"){try{const[e,n,s]=await Promise.all([fetch(`${d.API_URL}/api/analytics/kpis?period=${t}`,{credentials:"include",headers:d.HEADERS}),fetch(`${d.API_URL}/api/analytics/performance?period=${t}`,{credentials:"include",headers:d.HEADERS}),fetch(`${d.API_URL}/api/analytics/top-items?period=${t}`,{credentials:"include",headers:d.HEADERS})]);if(!e.ok||!n.ok||!s.ok)throw new Error("Falha ao buscar dados de analytics.");return{kpis:await e.json(),performance:await n.json(),topItems:await s.json()}}catch(e){return alert(e.message),null}}function D(t){t&&(r.kpiTotalViews().textContent=t.totalViews||0,r.kpiTotalClicks().textContent=t.totalClicks||0,r.kpiCtr().textContent=`${t.clickThroughRate||"0.0"}%`,r.kpiTotalSaves().textContent=t.totalSaves||0)}function R(t){if(r.topItemsList().innerHTML="",t.length===0){r.topItemsList().innerHTML="<li>Nenhum clique registrado no período.</li>";return}t.forEach(e=>{const n=document.createElement("li");n.innerHTML=`
            <div class="item-info">
                <i class="${e.icon_class||"fas fa-link"}"></i>
                <span>${e.title}</span>
            </div>
            <span class="click-count">${e.click_count} cliques</span>
        `,r.topItemsList().appendChild(n)})}function T(t){L&&L.destroy();const e=t.map(p=>new Date(p.date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"})),n=t.map(p=>parseInt(p.views,10)),s=t.map(p=>parseInt(p.clicks,10)),l=r.performanceChartCanvas().getContext("2d");L=new Chart(l,{type:"line",data:{labels:e,datasets:[{label:"Visualizações",data:n,borderColor:"rgba(201, 164, 68, 0.8)",backgroundColor:"rgba(201, 164, 68, 0.2)",fill:!0,tension:.4},{label:"Cliques",data:s,borderColor:"rgba(236, 236, 236, 0.8)",backgroundColor:"rgba(236, 236, 236, 0.1)",fill:!0,tension:.4}]},options:{responsive:!0,maintainAspectRatio:!1,scales:{y:{beginAtZero:!0,ticks:{color:"#A1A1A1"},grid:{color:"rgba(255, 255, 255, 0.1)"}},x:{ticks:{color:"#A1A1A1"},grid:{color:"rgba(255, 255, 255, 0.1)"}}},plugins:{legend:{labels:{color:"#ECECEC"}}}}})}async function y(){const t=r.periodSelector().value;r.kpiTotalViews().textContent="...",r.kpiTotalClicks().textContent="...",r.kpiCtr().textContent="...%",r.kpiTotalSaves().textContent="...";const e=document.getElementById("all-links-details");e&&(e.innerHTML='<p style="color: var(--text-dark); text-align: center; padding: 20px;">Carregando detalhes dos links...</p>');try{const[n,s,l]=await Promise.all([fetch(`${d.API_URL}/api/analytics/kpis?period=${t}`,{credentials:"include",headers:d.HEADERS}),fetch(`${d.API_URL}/api/analytics/performance?period=${t}`,{credentials:"include",headers:d.HEADERS}),fetch(`${d.API_URL}/api/analytics/top-items?period=${t}`,{credentials:"include",headers:d.HEADERS})]);if(!n.ok||!s.ok||!l.ok)throw new Error("Falha ao buscar um ou mais dados de analytics.");const p=await n.json(),v=await s.json(),k=await l.json();let m=null;const h=`${d.API_URL}/api/analytics/details?period=${t}`,E=await fetch(h,{credentials:"include",headers:d.HEADERS});if(E.ok?(m=await E.json(),B(m,t)):e&&(e.innerHTML='<p style="color: var(--text-dark); text-align: center; padding: 20px;">Não foi possível carregar os detalhes dos links.</p>'),typeof window.ckEnsureChart=="function")try{await window.ckEnsureChart()}catch{}D(p),T(v),R(k),S=!0}catch(n){e&&(e.innerHTML='<p style="color: var(--danger); text-align: center; padding: 20px;">Erro ao carregar detalhes dos links.</p>'),alert(n.message)}}function B(t,e="30"){const n=document.getElementById("all-links-details");if(!n||!t)return;const s=t.links||[],l=t.stats||{},p=t.period_stats||{},v=t.performance||[],k=t.recent_clicks||[];if(s.length===0&&v.length===0){n.innerHTML='<p style="color: var(--text-dark); text-align: center; padding: 20px;">Você ainda não possui links cadastrados ou dados de analytics. Adicione links na aba "Editar Tag" e comece a compartilhar sua Tag!</p>';return}const m=parseInt(l.total_views)||0,h=parseInt(l.total_clicks)||0,E=parseInt(l.total_vcard_downloads)||0,A=parseInt(p.views_period)||0,z=parseInt(p.clicks_period)||0,j=l.last_view_date?new Date(l.last_view_date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Nunca",M=l.last_click_date?new Date(l.last_click_date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Nunca",N=l.first_view_date?new Date(l.first_view_date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric"}):"Nunca",G=m>0?(h/m*100).toFixed(1):"0.0",Y=A>0?(z/A*100).toFixed(1):"0.0";let w=`
    <!-- Estatísticas Gerais -->
    <div style="margin-bottom: 30px;">
        <h3 style="color: var(--text, #ECECEC); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-chart-bar"></i> Estatísticas Gerais do Seu Perfil
        </h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Visualizações Totais -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--dourado-principal, #FFC700); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${m.toLocaleString()}</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Visualizações Totais</div>
            </div>
            <!-- Visualizações no Período -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--dourado-principal, #FFC700); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${A.toLocaleString()}</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Visualizações no Período</div>
            </div>
            <!-- Cliques Totais -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--text, #ECECEC); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${h.toLocaleString()}</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Cliques Totais</div>
            </div>
            <!-- Cliques no Período -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--text, #ECECEC); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${z.toLocaleString()}</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Cliques no Período</div>
            </div>
            <!-- Taxa de Conversão Total -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--text, #ECECEC); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${G}%</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Taxa de Conversão Total</div>
            </div>
            <!-- Taxa de Conversão no Período -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--text, #ECECEC); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${Y}%</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">Taxa de Conversão no Período</div>
            </div>
            <!-- vCards Baixados -->
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); text-align: center;">
                <div style="color: var(--text, #ECECEC); font-size: 2.5rem; font-weight: bold; margin-bottom: 5px;">${E.toLocaleString()}</div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem;">vCards Baixados</div>
            </div>
        </div>
        <div style="background: var(--card-background-color, #1C1C21); padding: 15px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">Primeira visualização:</div>
                <div style="color: var(--text, #ECECEC); font-size: 0.9rem; font-weight: 500;">${N}</div>
            </div>
            <div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">ltima visualização:</div>
                <div style="color: var(--text, #ECECEC); font-size: 0.9rem; font-weight: 500;">${j}</div>
            </div>
            <div>
                <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">ltimo clique:</div>
                <div style="color: var(--text, #ECECEC); font-size: 0.9rem; font-weight: 500;">${M}</div>
            </div>
        </div>
    </div>
    
    <!-- Gráfico de Performance -->
    ${v.length>0?`
    <div style="margin-bottom: 30px;">
        <h3 style="color: var(--text, #ECECEC); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-chart-line"></i> Performance ao Longo do Tempo
        </h3>
        <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F);">
            <canvas id="client-performance-chart" style="max-height: 300px;"></canvas>
        </div>
    </div>
    `:""}
    
    <!-- Gráfico de Distribuição de Cliques por Link -->
    ${s.length>0?`
    <div style="margin-bottom: 30px;">
        <h3 style="color: var(--text, #ECECEC); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-chart-pie"></i> Distribuição de Cliques por Link
        </h3>
        <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F);">
            <canvas id="client-links-distribution-chart" style="max-height: 300px;"></canvas>
        </div>
    </div>
    `:""}
    
    <!-- Detalhes por Link -->
    <div style="margin-bottom: 30px;">
        <h3 style="color: var(--text, #ECECEC); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-link"></i> Detalhes de Cada Link (${s.length} ${s.length===1?"link cadastrado":"links cadastrados"})
        </h3>
    </div>
`;if(s.length===0)w+='<p style="color: var(--text-dark); text-align: center; padding: 20px;">Você ainda não possui links cadastrados. Adicione links na aba "Editar Tag".</p>';else{const c=[...s].sort((i,a)=>(parseInt(a.click_count)||0)-(parseInt(i.click_count)||0));w+='<div style="display: grid; gap: 15px;">'+c.map(i=>{const a=parseInt(i.click_count)||0,o=parseInt(i.click_count_period)||0,f=i.last_click_date?new Date(i.last_click_date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Nunca",C=i.first_click_date?new Date(i.first_click_date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric"}):"Nunca",W=i.icon_class||"fas fa-link",Z=i.title||"Sem título",x=i.url||"N/A";let b="Link Personalizado",u="var(--dourado-principal, #FFC700)";x.includes("whatsapp.com")||x.includes("wa.me")?(b="WhatsApp",u="#25D366"):x.includes("instagram.com")?(b="Instagram",u="#E4405F"):x.includes("facebook.com")?(b="Facebook",u="#1877F2"):x.includes("youtube.com")?(b="YouTube",u="#FF0000"):x.includes("linkedin.com")&&(b="LinkedIn",u="#0077B5");const K=m>0?(a/m*100).toFixed(1):"0.0";return`
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 2px solid var(--border-color, #2C2C2F); transition: all 0.2s;" 
                 onmouseover="this.style.borderColor='var(--dourado-principal, #FFC700)'; this.style.transform='translateY(-2px)'"
                 onmouseout="this.style.borderColor='var(--border-color, #2C2C2F)'; this.style.transform='translateY(0)'">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                    <div style="background: rgba(255, 199, 0, 0.1); padding: 15px; border-radius: 10px; border: 2px solid ${u};">
                        <i class="${W}" style="color: ${u}; font-size: 2rem;"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px; flex-wrap: wrap;">
                            <span style="color: var(--text, #ECECEC); font-weight: 600; font-size: 1.1rem;">${Z}</span>
                            <span style="background: ${u}; color: white; padding: 4px 10px; border-radius: 5px; font-size: 0.75rem; font-weight: bold;">${b}</span>
                        </div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.9rem; word-break: break-all; margin-bottom: 5px;">${x}</div>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; padding-top: 15px; border-top: 1px solid var(--border-color, #2C2C2F);">
                    <div>
                        <div style="color: ${u}; font-weight: bold; font-size: 1.8rem; margin-bottom: 3px;">${a.toLocaleString()}</div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.75rem;">Total de Cliques</div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.7rem; margin-top: 3px; opacity: 0.7;">${o} no período</div>
                    </div>
                    <div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">Primeiro clique:</div>
                        <div style="color: var(--text, #ECECEC); font-size: 0.85rem; font-weight: 500;">${C}</div>
                    </div>
                    <div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">ltimo clique:</div>
                        <div style="color: var(--text, #ECECEC); font-size: 0.85rem; font-weight: 500;">${f}</div>
                    </div>
                    <div>
                        <div style="color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-bottom: 3px;">Taxa de conversão:</div>
                        <div style="color: var(--text, #ECECEC); font-size: 0.85rem; font-weight: 500;">${K}%</div>
                    </div>
                </div>
            </div>
        `}).join("")+"</div>"}k.length>0&&(w+=`
        <div style="margin-bottom: 30px; margin-top: 30px;">
            <h3 style="color: var(--text, #ECECEC); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-history"></i> Histórico Recente de Cliques (últimos ${k.length})
            </h3>
            <div style="background: var(--card-background-color, #1C1C21); padding: 20px; border-radius: 12px; border: 1px solid var(--border-color, #2C2C2F); overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 1px solid var(--border-color, #2C2C2F);">
                            <th style="padding: 10px; text-align: left; color: var(--text, #ECECEC); font-weight: 600;">Data/Hora</th>
                            <th style="padding: 10px; text-align: left; color: var(--text, #ECECEC); font-weight: 600;">Link</th>
                            <th style="padding: 10px; text-align: left; color: var(--text, #ECECEC); font-weight: 600;">Tipo</th>
                            <th style="padding: 10px; text-align: left; color: var(--text, #ECECEC); font-weight: 600;">URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${k.map(c=>{const i=new Date(c.created_at).toLocaleString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}),a=c.title||"Sem título",o=c.url||"N/A";let f="Outro",C="var(--dourado-principal, #FFC700)";return o.includes("whatsapp.com")||o.includes("wa.me")?(f="WhatsApp",C="#25D366"):o.includes("instagram.com")?(f="Instagram",C="#E4405F"):o.includes("facebook.com")?(f="Facebook",C="#1877F2"):o.includes("youtube.com")?(f="YouTube",C="#FF0000"):o.includes("linkedin.com")&&(f="LinkedIn",C="#0077B5"),`
                                <tr style="border-bottom: 1px solid rgba(255, 255, 255, 0.05);">
                                    <td style="padding: 10px; color: var(--text-dark, #A1A1A1); font-size: 0.9rem;">${i}</td>
                                    <td style="padding: 10px; color: var(--text, #ECECEC);">${a}</td>
                                    <td style="padding: 10px;"><span style="background: ${C}; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold;">${f}</span></td>
                                    <td style="padding: 10px;"><a href="${o}" target="_blank" style="color: var(--dourado-principal, #FFC700); text-decoration: none; font-size: 0.85rem; word-break: break-all;">${o.length>40?o.substring(0,40)+"...":o}</a></td>
                                </tr>
                            `}).join("")}
                    </tbody>
                </table>
            </div>
        </div>
    `),n.innerHTML=w;const F=function(){if(v.length>0&&typeof Chart<"u"){const c=document.getElementById("client-performance-chart");if(c){I&&I.destroy();const i=v.map(a=>new Date(a.date).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"}));I=new Chart(c,{type:"line",data:{labels:i,datasets:[{label:"Visualizações",data:v.map(a=>parseInt(a.views)||0),borderColor:"rgb(255, 199, 0)",backgroundColor:"rgba(255, 199, 0, 0.1)",tension:.4,fill:!0},{label:"Cliques",data:v.map(a=>parseInt(a.clicks)||0),borderColor:"rgb(255, 255, 255)",backgroundColor:"rgba(255, 255, 255, 0.1)",tension:.4,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!0,plugins:{legend:{labels:{color:"#ECECEC"}}},scales:{y:{beginAtZero:!0,ticks:{color:"#A1A1A1"},grid:{color:"rgba(255, 255, 255, 0.1)"}},x:{ticks:{color:"#A1A1A1"},grid:{color:"rgba(255, 255, 255, 0.1)"}}}}})}}if(s.length>0&&typeof Chart<"u"){const c=document.getElementById("client-links-distribution-chart");if(c){$&&$.destroy();const i=[...s].sort((a,o)=>(parseInt(o.click_count)||0)-(parseInt(a.click_count)||0)).slice(0,10);$=new Chart(c,{type:"bar",data:{labels:i.map(a=>{const o=a.title||"Sem título";return o.length>20?o.substring(0,20)+"...":o}),datasets:[{label:"Cliques",data:i.map(a=>parseInt(a.click_count)||0),backgroundColor:"rgba(255, 199, 0, 0.8)",borderColor:"rgb(255, 199, 0)",borderWidth:1}]},options:{responsive:!0,maintainAspectRatio:!0,plugins:{legend:{display:!1}},scales:{y:{beginAtZero:!0,ticks:{color:"#A1A1A1"},grid:{color:"rgba(255, 255, 255, 0.1)"}},x:{ticks:{color:"#A1A1A1",maxRotation:45,minRotation:45},grid:{display:!1}}}}})}}};typeof window.ckEnsureChart=="function"?window.ckEnsureChart().then(F).catch(function(){}):F()}var H=D;D=function(t){if(r.kpiTotalViews())return H(t)};var V=R;R=function(t){if(r.topItemsList())return V(t)};var q=T;T=function(t){var e=r.performanceChartCanvas();if(!(!e||typeof Chart>"u"))return q(t)};var U=y;y=async function(){if(r.periodSelector())return U()},g.loadReportsData=y,g.DashboardRelatorios={init:function(){var t=r.periodSelector();t&&!t.dataset.relatoriosBound&&(t.addEventListener("change",function(){y()}),t.dataset.relatoriosBound="1")},load:y,fetchAnalyticsData:P},document.readyState==="loading"?document.addEventListener("DOMContentLoaded",function(){g.DashboardRelatorios&&g.DashboardRelatorios.init()}):g.DashboardRelatorios.init()})(typeof window<"u"?window:void 0);
