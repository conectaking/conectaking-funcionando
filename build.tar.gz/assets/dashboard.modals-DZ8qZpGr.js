(function(){const v={confirm(t){return new Promise(e=>{const{title:c="Confirmar",message:n="Tem certeza?",confirmText:i="Confirmar",cancelText:l="Cancelar",confirmClass:o="btn-primary",cancelClass:d="btn-secondary"}=t,a=document.createElement("div");a.className="modal active",a.innerHTML=`
                    <div class="modal-content modal-small">
                        <div class="modal-header">
                            <h3>${this.escapeHtml(c)}</h3>
                            <button class="modal-close" data-action="cancel">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>${this.escapeHtml(n)}</p>
                        </div>
                        <div class="modal-footer">
                            <button class="${d}" data-action="cancel">${l}</button>
                            <button class="${o}" data-action="confirm">${i}</button>
                        </div>
                    </div>
                `,document.body.appendChild(a);const m=s=>{const r=s.target.closest("[data-action]")?.dataset.action;r==="confirm"?(e(!0),this.closeModal(a)):r==="cancel"&&(e(!1),this.closeModal(a))};a.addEventListener("click",s=>{s.target===a?(e(!1),this.closeModal(a)):m(s)})})},alert(t){return new Promise(e=>{const{title:c="Aviso",message:n="",buttonText:i="OK",buttonClass:l="btn-primary"}=t,o=document.createElement("div");o.className="modal active",o.innerHTML=`
                    <div class="modal-content modal-small">
                        <div class="modal-header">
                            <h3>${this.escapeHtml(c)}</h3>
                            <button class="modal-close" data-action="close">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>${this.escapeHtml(n)}</p>
                        </div>
                        <div class="modal-footer">
                            <button class="${l}" data-action="close">${i}</button>
                        </div>
                    </div>
                `,document.body.appendChild(o);const d=()=>{e(),this.closeModal(o)};o.addEventListener("click",a=>{(a.target.closest("[data-action]")?.dataset.action==="close"||a.target===o)&&d()})})},closeModal(t){t&&t.parentNode&&(t.classList.remove("active"),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t)},300))},escapeHtml(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}};window.DashboardModals=v})();
