(function(H){var se=function(){try{localStorage.getItem("ck_debug")}catch{}};function I(){return H.DashboardCore||{}}function Se(){return H.DashboardCartao||{}}function Pe(){return H.DashboardEditor||{}}var fe=H.fetch.bind(H),M={get API_URL(){var e=I();return typeof e.getApiUrl=="function"?e.getApiUrl()||"":H.API_URL||H.API_BASE||""},get HEADERS(){var e=I();return typeof e.getHeaders=="function"?e.getHeaders()||{}:{"Content-Type":"application/json"}},get HEADERS_AUTH(){var e=I();return typeof e.getAuthHeaders=="function"?e.getAuthHeaders()||{}:typeof e.getHeadersAuth=="function"?e.getHeadersAuth()||{}:{}},getAuthHeaders:function(){var e=I();return typeof e.getAuthHeaders=="function"?e.getAuthHeaders():this.HEADERS_AUTH},safeFetch:function(e,a){var o=I();return typeof o.safeFetch=="function"?o.safeFetch(e,a):fe(e,Object.assign({credentials:"include"},a||{}))},setAvatarSrc:function(e,a){var o=I();if(typeof o.setAvatarSrc=="function")return o.setAvatarSrc(e,a);e&&(e.src=a||"")},parseBannerDestination:function(e){var a=I();return typeof a.parseBannerDestination=="function"?a.parseBannerDestination(e):{primary_url:String(e||"").trim(),instagram_url:"",whatsapp_url:""}},serializeBannerDestination:function(){var e=I();return typeof e.serializeBannerDestination=="function"?e.serializeBannerDestination.apply(e,arguments):String(arguments[0]||"").trim()},bannerUrlModelsHtml:function(){var e=I();return typeof e.bannerUrlModelsHtml=="function"?e.bannerUrlModelsHtml():""},bannerDestDisplayLabel:function(e){var a=I();return typeof a.bannerDestDisplayLabel=="function"?a.bannerDestDisplayLabel(e):String(e||"").trim()},wifiBannerUploadBlockHtml:function(){var e=I();return typeof e.wifiBannerUploadBlockHtml=="function"?e.wifiBannerUploadBlockHtml.apply(e,arguments):""},getDefaultIcon:function(e){var a=I();return typeof a.getDefaultIcon=="function"?a.getDefaultIcon(e):"fas fa-link"},moduleListDisplayTitle:function(e){var a=I();return typeof a.moduleListDisplayTitle=="function"?a.moduleListDisplayTitle(e):e&&(e.title||e.item_type)||"Módulo"},updateLivePreviewFromForm:function(){var e=Se();if(e&&typeof e.updateLivePreviewFromForm=="function")return e.updateLivePreviewFromForm()},renderEditor:function(e){var a=Pe();if(a&&typeof a.renderEditor=="function")return a.renderEditor(e)},handleBackgroundUpload:function(e){var a=I();if(typeof a.handleBackgroundUpload=="function")return a.handleBackgroundUpload(e);if(typeof H.handleBackgroundUpload=="function")return H.handleBackgroundUpload(e)},handleShareImageUpload:function(e){var a=I();if(typeof a.handleShareImageUpload=="function")return a.handleShareImageUpload(e);if(typeof H.handleShareImageUpload=="function")return H.handleShareImageUpload(e)},handleVitrineHeroUpload:function(e){var a=I();if(typeof a.handleVitrineHeroUpload=="function")return a.handleVitrineHeroUpload(e);if(typeof H.handleVitrineHeroUpload=="function")return H.handleVitrineHeroUpload(e)}},u=new Proxy({},{get:function(e,a){var o=I(),P=typeof o.getSelectors=="function"?o.getSelectors():null;return P?P[a]:null}}),ve=function(e,a){return M.safeFetch(e,a||{})};async function $e(e){const a=e.dataset.id,o=e.dataset.itemType;if(o==="sales_page"||o==="guest_list"||o==="contract"||o==="king_selection"||o==="convite"||o==="bible"){const g=!a||!/^\d+$/.test(String(a).trim())||String(a).startsWith("temp_")||String(a).startsWith("te_")||e.dataset.isTemporary==="true"||e.hasAttribute("data-is-temporary")||e.dataset.isUnsaved==="true";if(se("Verificando se sales_page é temporário:",{itemId:a,isTemporary:g,hasDataIsTemporary:e.hasAttribute("data-is-temporary"),datasetIsTemporary:e.dataset.isTemporary}),g){alert('Este módulo ainda não foi salvo. Por favor, clique em "Publicar alterações" primeiro para salvar o módulo antes de editá-lo.');return}try{updateHeaders();const k=await ve(`${M.API_URL}/api/profile/items/${a}`,{method:"GET",headers:M.HEADERS});if(!k.ok){if(k.status===404){alert("Este módulo não existe mais no servidor. Ele pode ter sido deletado. Removendo do dashboard..."),e.remove(),window.currentProfileData&&window.currentProfileData.items&&(window.currentProfileData.items=window.currentProfileData.items.filter(A=>String(A.id)!==String(a)));return}throw new Error(`Erro ${k.status} ao verificar item`)}}catch{alert("Erro ao verificar se o módulo existe. Tente novamente.");return}if(o==="sales_page")window.location.href=`/salesPageEdit?itemId=${a}`;else if(o==="guest_list")window.location.href=`/guestListEdit?itemId=${a}`;else if(o==="contract"||o==="agenda"||o==="kingbrief"||o==="king_bolao"){alert("Este módulo foi descontinuado e já não está disponível.");return}else if(o==="king_selection")typeof window.navigateToKingSelectionAdmin=="function"?window.navigateToKingSelectionAdmin():typeof window.kingSelectionAdminUrl=="function"?window.location.href=window.kingSelectionAdminUrl():window.location.href="/kingSelection";else if(o==="convite")window.location.href=`/conviteEdit?itemId=${a}`;else if(o==="bible"){try{sessionStorage.setItem("bible_item_id",String(a)),sessionStorage.setItem("bible_panel_item_id",String(a))}catch{}window.location.href="/biblia"}return}let P="";function ye(g){const k="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDE1MCAxNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxNTAiIGhlaWdodD0iMTUwIiBmaWxsPSIjMzMzMzMzIi8+Cjx0ZXh0IHg9Ijc1IiB5PSI3NSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iIzk5OTk5OSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5JbWFnZW08L3RleHQ+Cjwvc3ZnPgo=";if(!g||typeof g!="string")return k;const A=g.trim();return A.includes("placeholder.com")||A.includes("via.placeholder")?k:A.startsWith("data:image/")||A.startsWith("http://")||A.startsWith("https://")?A:k}const L=e.querySelector(".item-title-input")?.value||"";let c=e.querySelector(".item-destination-url-input")?.value||"";const de=e.querySelector(".item-pix-key-input")?.value||"",ie=e.querySelector(".item-pdf-url-input")?.value||"",xe=e.dataset.aspectRatio||"tarja";let pe=null;if(o==="banner"&&e.dataset.originalData)try{pe=JSON.parse(e.dataset.originalData)}catch(g){se("Erro ao parsear originalData:",g)}if(pe&&o==="banner"&&(!c||c==="#"||c.includes("placeholder"))&&(c=pe.destination_url||""),o==="banner"){window.currentCarouselItemId=null;const g=c;if(g.trim().startsWith("["))c="";else{const k=M.parseBannerDestination(g);c=g.trim().startsWith("{")?k.primary_url:(()=>{const A=String(g).split(",").map(E=>E.trim()).filter(Boolean);return(A.filter(E=>!E.includes("imagedelivery.net"))[0]||A[0]||"").trim()})()}}const ue=e.classList.contains("banner-carousel")||o==="banner"&&c&&(c.startsWith("[")||c==="[]"),we=e.querySelector(".item-image-url-input")?.value||"";let Q=ye(we);switch(pe&&o==="banner"&&(!Q||Q.includes("placeholder"))&&(Q=ye(pe.image_url||"")),se("Abrindo modal para item:",{itemId:e.dataset.id,itemType:o,currentDestUrl:c,currentImageUrl:Q,isCarouselItem:ue,itemOriginalData:pe}),o){case"link":const g=e.querySelector(".item-image-url-input")?.value||"",k=e.querySelector(".item-icon-picker i")?.className||"fas fa-link",A=g&&g.trim()&&!g.includes("placeholder")?"display: block;":"display: none;",$=e.dataset.logoSize?parseInt(e.dataset.logoSize):e.querySelector(".item-logo-size-input")?.value||24,E=Math.min($,100);let D="contain";if(window.currentProfileData&&window.currentProfileData.items){const v=window.currentProfileData.items.find(l=>String(l.id)===String(a));v&&v.logo_fit_mode&&(D=v.logo_fit_mode)}const R=e.querySelector(".item-logo-fit-mode-input");R&&R.value&&(D=R.value),P=`
            <div class="input-group">
                <label>Logo (PNG ou JPG)</label>
                <div class="logo-upload-area" style="margin-bottom: 15px; position: relative; border: 2px dashed var(--border-color, #2C2C2F); border-radius: 8px; padding: 20px; text-align: center; cursor: pointer; background: var(--card-background-color, #1C1C21);">
                    <input type="file" class="item-logo-file-input" accept="image/png,image/jpeg,image/jpg" style="display: none;">
                    <img src="${g||""}" class="item-logo-upload-preview" style="max-width: ${E}px; max-height: ${E}px; width: ${E}px; height: ${E}px; object-fit: contain; margin-bottom: 10px; border-radius: 8px; ${A}">
                    <div class="logo-upload-text" style="${!g||g.includes("placeholder")?"":"display: none;"}">
                        <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: var(--dourado-principal, #FFC700); margin-bottom: 10px;"></i>
                        <p style="margin: 5px 0; color: var(--text, #ECECEC);">Clique para fazer upload</p>
                        <span style="font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">PNG ou JPG (máx. 5MB)</span>
                    </div>
                    <button type="button" class="remove-logo-btn" style="display: ${g&&!g.includes("placeholder")?"block":"none"}; margin-top: 10px; padding: 5px 15px; background: #ff4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-trash"></i> Remover Logo
                    </button>
                    <div class="upload-loader" style="display: none;"></div>
                </div>
                <input type="hidden" class="item-image-url-input" id="edit-link-image-url" value="${g||""}">
            </div>
            ${g&&!g.includes("placeholder")?`
            <div class="input-group">
                <label>Tamanho da Logo (em pixels)</label>
                <div class="range-slider" style="margin-bottom: 15px;">
                    <div class="range-slider-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <label style="margin: 0; color: var(--text, #ECECEC);">Tamanho: <span id="edit-logo-size-value-${a}">${$}</span>px</label>
                        <input type="number" class="item-logo-size-input" id="edit-logo-size-input-${a}" value="${$}" min="20" max="600" step="1" style="width: 80px; padding: 5px 10px; border-radius: 4px; border: 1px solid var(--border-color, #2C2C2F); background: var(--card-background-color, #1C1C21); color: var(--text, #ECECEC); text-align: center;">
                    </div>
                    <input type="range" class="item-logo-size-slider" id="edit-logo-size-slider-${a}" value="${$}" min="20" max="600" step="5" style="width: 100%;">
                    <div style="display: flex; justify-content: space-between; margin-top: 5px; font-size: 0.75rem; color: var(--text-dark, #A1A1A1);">
                        <span>20px</span>
                        <span>600px</span>
                    </div>
                </div>
            </div>
            <div class="input-group">
                <label>Ajuste da Logo</label>
                <div class="segmented-control" style="display: flex; gap: 8px; background: var(--card-background-color, #1C1C21); padding: 4px; border-radius: 8px; border: 1px solid var(--border-color, #2C2C2F);">
                    <input type="radio" id="edit-logo-fit-contain-${a}" name="edit-logo-fit-mode-${a}" value="contain" ${!D||D==="contain"?"checked":""} style="display: none;">
                    <label for="edit-logo-fit-contain-${a}" style="flex: 1; padding: 8px 12px; text-align: center; border-radius: 6px; cursor: pointer; background: ${!D||D==="contain"?"var(--dourado-principal, #FFC700)":"transparent"}; color: ${!D||D==="contain"?"#000":"var(--text, #ECECEC)"}; font-size: 0.85rem; font-weight: 600; transition: all 0.2s;">
                        <i class="fas fa-expand" style="margin-right: 5px;"></i> Automático
                    </label>
                    <input type="radio" id="edit-logo-fit-cover-${a}" name="edit-logo-fit-mode-${a}" value="cover" ${D==="cover"?"checked":""} style="display: none;">
                    <label for="edit-logo-fit-cover-${a}" style="flex: 1; padding: 8px 12px; text-align: center; border-radius: 6px; cursor: pointer; background: ${D==="cover"?"var(--dourado-principal, #FFC700)":"transparent"}; color: ${D==="cover"?"#000":"var(--text, #ECECEC)"}; font-size: 0.85rem; font-weight: 600; transition: all 0.2s;">
                        <i class="fas fa-crop" style="margin-right: 5px;"></i> Com Corte
                    </label>
                </div>
                <input type="hidden" class="item-logo-fit-mode-input" id="edit-logo-fit-mode-input-${a}" value="${D||"contain"}">
            </div>
            `:""}
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Link Personalizado">
            </div>
            <div class="input-group">
                <label>URL de Destino</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://exemplo.com">
            </div>
            <div class="input-group">
                <label>Ícone (opcional - usado se não houver logo)</label>
                <div class="item-icon-picker" style="font-size: 2rem; cursor: pointer; color: var(--dourado-principal, #FFC700); width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; border: 2px solid var(--border-color, #2C2C2F); border-radius: 8px; margin: 10px 0;" title="Clique para alterar ícone">
                    <i class="${k}"></i>
                </div>
            </div>
        `;break;case"telegram":case"facebook":case"instagram":case"pinterest":case"reddit":case"tiktok":case"twitch":case"twitter":case"spotify":case"linkedin":case"portfolio":case"youtube":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Link">
            </div>
            <div class="input-group">
                <label>URL de Destino</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://exemplo.com">
            </div>
        `;break;case"banner":const p=e.querySelector(".item-banner-name-input"),m=e.querySelector(".item-title-input-hidden"),f=p?.value||L||"",C=m?.value||"";P=`
            <div class="input-group">
                <label>Nome do Banner</label>
                <input type="text" id="edit-banner-name" value="${f}" placeholder="Ex: Banner WhatsApp, Banner Instagram">
            </div>
            <!-- Proporção do Banner: ajustada diretamente na tela de corte ao trocar a imagem -->
            <input type="hidden" name="aspect-ratio-selector" id="edit-banner-aspect-ratio" value="${xe}">
            <div class="input-group">
                <label>Imagem do Banner</label>
                <div class="image-upload-area" data-item-type="banner" data-item-id="${a}">
                    <input type="file" class="item-file-input" accept="image/*" data-item-type="banner" data-item-id="${a}">
                    <div class="image-upload-text">
                        <p><i class="fas fa-cloud-upload-alt"></i> Trocar Imagem</p>
                        <span>Clique para fazer upload ou arraste uma imagem aqui</span>
                    </div>
                    <img id="edit-banner-preview" class="banner-preview" src="${Q||""}" style="max-width: 100%; max-height: 200px; margin-top: 10px; display: ${Q&&!Q.includes("placeholder")?"block":"none"}; border-radius: 8px;">
                    <div class="upload-loader"></div>
                </div>
            </div>
            <div class="input-group">
                <label>URL ao clicar na imagem (opcional)</label>
                <input type="text" id="edit-dest-url" value="${(c&&!c.startsWith("[")?c:"").replace(/"/g,"&quot;")}" placeholder="https://link.do.banner">
            </div>
            <div class="input-group">
                <label>Mensagem WhatsApp (opcional)</label>
                <small style="display:block;color:#a1a1a1;font-size:0.8rem;margin:0 0 8px;">Se a URL acima for WhatsApp (wa.me), esta mensagem vai pré-preenchida no chat.</small>
                <input type="text" id="edit-banner-title" value="${(C||"").replace(/"/g,"&quot;")}" placeholder="Ex: Olá! Gostaria de saber mais sobre seus produtos.">
            </div>
            ${M.bannerUrlModelsHtml()}
            <input type="hidden" id="edit-image-url" value="${Q||""}">
        `;break;case"carousel":let S=[];const F=e.querySelector(".carousel-images-json-new");if(F&&F.value&&F.value.trim())try{const v=JSON.parse(F.value);Array.isArray(v)&&(S=v.filter(l=>{const b=typeof l=="string"?l:l.image_url||l;return b&&!b.includes("placeholder")&&!b.startsWith("data:image/svg")}))}catch{}else if(c&&c.startsWith("["))try{const v=JSON.parse(c);Array.isArray(v)&&(S=v.filter(l=>{const b=typeof l=="string"?l:l.image_url||l;return b&&!b.includes("placeholder")&&!b.startsWith("data:image/svg")}))}catch{}const J=e.dataset.aspectRatio||"auto",U=S.length>0?typeof S[0]=="string"?S[0]:S[0].image_url||S[0]:"";P=`
            <div class="input-group">
                <label>Proporção de Aspecto</label>
                <div class="aspect-ratio-selector" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 8px;">
                    <input type="radio" name="aspect-ratio-selector" id="ratio-auto-carousel-${a}" value="auto" ${J==="auto"?"checked":""}>
                    <label for="ratio-auto-carousel-${a}">Automática</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-tarja-carousel-${a}" value="tarja" ${J==="tarja"?"checked":""}>
                    <label for="ratio-tarja-carousel-${a}">Tarja</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-2-1-carousel-${a}" value="2:1" ${J==="2:1"?"checked":""}>
                    <label for="ratio-2-1-carousel-${a}">2:1</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-4-3-carousel-${a}" value="4:3" ${J==="4:3"?"checked":""}>
                    <label for="ratio-4-3-carousel-${a}">4:3</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-1-1-carousel-${a}" value="1:1" ${J==="1:1"?"checked":""}>
                    <label for="ratio-1-1-carousel-${a}">1:1</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-3-4-carousel-${a}" value="3:4" ${J==="3:4"?"checked":""}>
                    <label for="ratio-3-4-carousel-${a}">3:4</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-10-16-carousel-${a}" value="10:16" ${J==="10:16"?"checked":""}>
                    <label for="ratio-10-16-carousel-${a}">10:16</label>
                    <input type="radio" name="aspect-ratio-selector" id="ratio-16-9-carousel-${a}" value="16:9" ${J==="16:9"?"checked":""}>
                    <label for="ratio-16-9-carousel-${a}">16:9</label>
                </div>
            </div>
            <div class="input-group">
                <label>Imagens do Carrossel</label>
                <div id="carousel-images-list-new-${a}" class="carousel-images-list-new" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin-bottom: 15px; min-height: 50px;">
                    ${S.length===0?'<p style="color: #999; text-align: center; padding: 20px; font-size: 0.9rem; grid-column: 1/-1;">Nenhuma imagem adicionada ainda.</p>':""}
                </div>
                <label class="carousel-upload-label-new" for="carousel-file-new-${a}" style="position: relative; border: 2px dashed var(--border-color, #2C2C2F); border-radius: 8px; padding: 20px; text-align: center; cursor: pointer; background: var(--card-background-color, #1C1C21); display: block; margin-top: 10px;">
                    <input type="file" id="carousel-file-new-${a}" class="carousel-file-input-new" accept="image/png,image/jpeg,image/jpg" data-item-id="${a}" multiple style="position: absolute; width: 1px; height: 1px; opacity: 0; overflow: hidden; clip: rect(0,0,0,0); pointer-events: none;">
                    <div style="pointer-events: none;">
                        <i class="fas fa-plus-circle" style="font-size: 2rem; color: var(--dourado-principal, #FFC700); margin-bottom: 10px;"></i>
                        <p style="margin: 5px 0; color: var(--text, #ECECEC);">Clique para adicionar imagens</p>
                        <span style="font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">PNG, JPG ou JPEG (máx. 5MB por imagem)</span>
                    </div>
                    <div class="carousel-upload-loader-new" style="display: none; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 2000; width: 40px; height: 40px; border: 5px solid rgba(255,255,255,0.3); border-top-color: var(--dourado-principal, #FFC700); border-radius: 50%; animation: spin 1s linear infinite;"></div>
                </label>
                <input type="hidden" class="carousel-images-json-new" data-item-id="${a}" value='${JSON.stringify(S)}'>
                <input type="hidden" id="edit-image-url" value="${U}">
                <small style="color: #999; display: block; margin-top: 10px;"><i class="fas fa-info-circle"></i> As imagens passam automaticamente a cada 3 segundos</small>
            </div>
        `;break;case"whatsapp":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Ex: Chamar no WhatsApp">
            </div>
            <div class="input-group">
                <label>Telefone (com código do país)</label>
                <input type="tel" id="edit-dest-url" value="${c}" placeholder="5521999999999">
            </div>
        `;break;case"email":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Ex: Enviar Email">
            </div>
            <div class="input-group">
                <label>Endereço de Email</label>
                <input type="email" id="edit-dest-url" value="${c}" placeholder="contato@exemplo.com">
            </div>
        `;break;case"pix":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título (ex: PIX Celular)">
            </div>
            <div class="input-group">
                <label>Nome do Recebedor</label>
                <input type="text" id="edit-recipient-name" value="${e.querySelector(".item-recipient-name-input")?.value||""}" placeholder="Seu nome completo">
            </div>
            <div class="input-group">
                <label>Chave PIX (Aleatória, CPF/CNPJ, E-mail ou Telefone)</label>
                <div class="pix-key-examples">
                    <small><strong>?ož Celular:</strong> Apenas números (ex: +5511999999999)</small>
                    <small><strong>?o§ Email:</strong> seuemail@exemplo.com</small>
                    <small><strong> CPF:</strong> Apenas números (ex: 12345678901)</small>
                    <small><strong>?~ Chave Aleatória:</strong> Copie e cole (ex: 12345678-1234-...)</small>
                </div>
                <input type="text" id="edit-pix-key" value="${de}" placeholder="Ex: +5511999999999 (celular) ou seuemail@exemplo.com">
            </div>
            <div class="input-group">
                <label>Valor (opcional)</label>
                <input type="number" id="edit-pix-amount" value="${e.querySelector(".item-pix-amount-input")?.value||""}" placeholder="Valor em reais" step="0.01">
            </div>
            <div class="input-group">
                <label>Descrição (opcional)</label>
                <input type="text" id="edit-pix-description" value="${e.querySelector(".item-pix-description-input")?.value||""}" placeholder="Descrição do pagamento">
            </div>
        `;break;case"pix_qrcode":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título (ex: Faça um PIX)">
            </div>
            <div class="input-group">
                <label>Nome do Recebedor</label>
                <input type="text" id="edit-recipient-name" value="${e.querySelector(".item-recipient-name-input")?.value||""}" placeholder="Seu nome completo">
            </div>
            <div class="input-group">
                <label>Chave PIX (Aleatória, CPF/CNPJ, E-mail ou Telefone)</label>
                <div class="pix-key-examples">
                    <small><strong>?ož Celular:</strong> Apenas números (ex: +5511999999999)</small>
                    <small><strong>?o§ Email:</strong> seuemail@exemplo.com</small>
                    <small><strong> CPF:</strong> Apenas números (ex: 12345678901)</small>
                    <small><strong>?~ Chave Aleatória:</strong> Copie e cole (ex: 12345678-1234-...)</small>
                </div>
                <input type="text" id="edit-pix-key" value="${de}" placeholder="Ex: +5511999999999 (celular) ou seuemail@exemplo.com">
            </div>
            <div class="input-group">
                <label>Valor (opcional)</label>
                <input type="number" id="edit-pix-amount" value="${e.querySelector(".item-pix-amount-input")?.value||""}" placeholder="Valor em reais" step="0.01">
            </div>
            <div class="input-group">
                <label>Descrição (opcional)</label>
                <input type="text" id="edit-pix-description" value="${e.querySelector(".item-pix-description-input")?.value||""}" placeholder="Descrição do pagamento">
            </div>
        `;break;case"wifi":{const v=_=>String(_??"").replace(/&/g,"&amp;").replace(/"/g,"&quot;"),l=e.querySelector(".wifi-display-format-input:checked")?.value||"button",b=e.querySelector(".wifi-ssid-input")?.value||"",te=e.querySelector(".wifi-password-input")?.value||"",j=e.querySelector(".wifi-security-input")?.value||"WPA",oe=!!e.querySelector(".wifi-hidden-input")?.checked,X=e.querySelector(".wifi-banner-url-input")?.value||"",V=e.querySelector(".wifi-logo-url-input")?.value||"",Z=e.querySelector(".wifi-logo-size-input")?.value||"48";let x={};const B=(window.currentProfileData?.items||[]).find(function(_){return String(_.id)===String(a)});if(B?.destination_url&&String(B.destination_url).trim().startsWith("{"))try{x=JSON.parse(B.destination_url)}catch{x={}}P=`
            <div class="input-group">
                <label>Título no cartão</label>
                <input type="text" id="edit-title" value="${v(L)}" placeholder="Texto do botão (ex: Conectar ao Wi-Fi)">
            </div>
            <div class="input-group">
                <label>Formato</label>
                <div style="display: flex; gap: 15px; margin-top: 10px;">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="radio" class="wifi-display-format-input" name="wifi-modal-df-${a}" value="button" ${l==="button"?"checked":""}>
                        <span>Botão</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="radio" class="wifi-display-format-input" name="wifi-modal-df-${a}" value="banner" ${l==="banner"?"checked":""}>
                        <span>Banner</span>
                    </label>
                </div>
            </div>
            <div class="input-group">
                <label>Nome da rede Wi-Fi (SSID)</label>
                <small style="display:block;color:#a1a1a1;font-size:0.8rem;margin:4px 0 8px;line-height:1.35;">Obrigatório. ? o nome exato que aparece na lista de redes do celular (usado no QR Code).</small>
                <input type="text" id="edit-wifi-ssid" value="${v(b)}" placeholder="Ex: MinhaLoja_WiFi ou Visitantes_5G" maxlength="32">
            </div>
            <div class="input-group">
                <label>Segurança</label>
                <select id="edit-wifi-security" style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--border-color,#2C2C2F);background:var(--card-background-color,#1C1C21);color:var(--text,#ECECEC);">
                    <option value="WPA" ${j==="WPA"||j==="WPA2"||j==="WPA3"?"selected":""}>WPA/WPA2/WPA3</option>
                    <option value="WEP" ${j==="WEP"?"selected":""}>WEP</option>
                    <option value="nopass" ${j==="nopass"||j==="NONE"?"selected":""}>Rede aberta (sem senha)</option>
                </select>
            </div>
            <div class="input-group">
                <label>Senha (opcional)</label>
                <input type="text" id="edit-wifi-password" value="${v(te)}" placeholder="Deixe vazio se for rede aberta" autocomplete="off">
            </div>
            <div class="input-group">
                <label style="display:flex;align-items:center;gap:10px;">
                    <input type="checkbox" id="edit-wifi-hidden" ${oe?"checked":""}>
                    Rede oculta (SSID não transmitido)
                </label>
            </div>
            <div class="wifi-modal-logo-section" style="display: ${l==="banner"?"none":"block"};">
                <div class="input-group">
                    <label>Tamanho da logo (px)</label>
                    <input type="number" id="edit-wifi-logo-size" value="${v(Z)}" min="20" max="600" step="1" style="width: 120px;">
                </div>
                <input type="hidden" id="edit-wifi-logo-url" value="${v(V)}">
                <p style="color:#888;font-size:0.85rem;">Upload de logo/imagem: use a área na lista do módulo ao lado.</p>
            </div>
            <div class="wifi-modal-banner-section" style="display: ${l==="banner"?"block":"none"};">
                ${M.wifiBannerUploadBlockHtml(a,X)}
            </div>
        `;break}case"pdf":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título (ex: Baixar Catálogo)">
            </div>
            <div class="input-group">
                <label>Arquivo PDF</label>
                <div class="image-upload-area pdf-upload-area">
                    <input type="file" class="item-file-input" accept=".pdf">
                    <div class="image-upload-text">
                        <p>${ie&&ie!=="#"?"Trocar Arquivo":"Selecionar Arquivo PDF"}</p>
                        <span>Clique para enviar (max 10MB)</span>
                    </div>
                    <div class="upload-loader"></div>
                </div>
            </div>
            <input type="hidden" id="edit-pdf-url" value="${ie}">
        `;break;case"instagram_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Conteúdo">
            </div>
            <div class="input-group">
                <label>URL do Perfil do Instagram</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://www.instagram.com/p/... ou https://www.instagram.com/seu_usuario/">
            </div>
        `;break;case"youtube_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Conteúdo">
            </div>
            <div class="input-group">
                <label>URL do Vídeo do YouTube</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://www.youtube.com/watch?v=... ou https://youtu.be/...">
            </div>
        `;break;case"tiktok_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Perfil">
            </div>
            <div class="input-group">
                <label>URL do Perfil do TikTok</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://www.tiktok.com/@seu_usuario">
            </div>
        `;break;case"spotify_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Perfil">
            </div>
            <div class="input-group">
                <label>URL do Perfil do Spotify</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://open.spotify.com/user/seu_usuario ou https://open.spotify.com/artist/seu_artista">
            </div>
        `;break;case"linkedin_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Perfil">
            </div>
            <div class="input-group">
                <label>URL do Perfil do LinkedIn</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://www.linkedin.com/in/seu_perfil">
            </div>
        `;break;case"pinterest_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Perfil">
            </div>
            <div class="input-group">
                <label>URL do Perfil do Pinterest</label>
                <input type="text" id="edit-dest-url" value="${c}" placeholder="https://www.pinterest.com/seu_usuario ou https://br.pinterest.com/seu_usuario">
            </div>
        `;break;case"banner":P=`
            <div class="input-group">
                <label>Nome do Banner</label>
                <input type="text" id="edit-banner-name" value="${f||""}" placeholder="Ex: Banner WhatsApp, Banner Instagram">
                <small style="color: #999; display: block; margin-top: 5px;">Este nome aparece na lista.</small>
            </div>
            <!-- Proporção do Banner: ajustada diretamente na tela de corte ao trocar a imagem -->
            <input type="hidden" name="aspect-ratio-selector" id="edit-banner-aspect-ratio" value="${xe}">
            <div class="input-group">
                <label>Imagem do Banner</label>
                <div class="image-upload-area" data-item-type="banner" data-item-id="${a}">
                    <input type="file" class="item-file-input" accept="image/*" data-item-type="banner" data-item-id="${a}">
                    <div class="image-upload-text">
                        <p><i class="fas fa-cloud-upload-alt"></i> Clique para fazer upload</p>
                        <span>ou arraste uma imagem aqui</span>
                    </div>
                    <img id="edit-banner-preview" class="banner-preview" src="${Q||""}" style="max-width: 100%; max-height: 200px; margin-top: 10px; display: ${Q&&!Q.includes("placeholder")?"block":"none"};">
                    <div class="upload-loader"></div>
                </div>
            </div>
            <div class="input-group">
                <label>URL de Destino (opcional)</label>
                <input type="text" id="edit-dest-url" value="${c&&!c.startsWith("[")?c:""}" placeholder="https://link.do.banner">
                <small style="color: #999; display: block; margin-top: 5px;">Para onde o banner leva quando clicado</small>
            </div>
            <div class="input-group">
                <label>Mensagem WhatsApp (opcional)</label>
                <input type="text" id="edit-banner-title" value="${currentBannerTitle||""}" placeholder="Ex: Olá! Gostaria de saber mais sobre seus produtos.">
                <small style="color: #999; display: block; margin-top: 5px;">Usada apenas quando a URL acima for WhatsApp.</small>
            </div>
            ${M.bannerUrlModelsHtml()}
            <input type="hidden" id="edit-image-url" value="${Q||""}">
            <input type="hidden" id="edit-dest-url-hidden" value="">
        `;break;case"pdf_embed":P=`
            <div class="input-group">
                <label>Título</label>
                <input type="text" id="edit-title" value="${L}" placeholder="Título do Documento">
            </div>
            <div class="input-group">
                <label>Arquivo PDF</label>
                <div class="image-upload-area pdf-upload-area">
                    <input type="file" class="item-file-input" accept=".pdf">
                    <div class="image-upload-text">
                        <p>${ie&&ie!=="#"?"Trocar Arquivo":"Selecionar Arquivo PDF"}</p>
                        <span>Clique para enviar (max 10MB)</span>
                    </div>
                    <div class="upload-loader"></div>
                </div>
            </div>
            <input type="hidden" id="edit-pdf-url" value="${ie}">
        `;break;case"location":(function(){var v=window.currentProfileData&&window.currentProfileData.items?window.currentProfileData.items.find(function(d){return String(d.id)===String(a)}):null,l=v&&v.location_data||{},b=(l.address_formatted||l.address||"").replace(/"/g,"&quot;").replace(/</g,"&lt;"),te=l.latitude!=null?String(l.latitude):"",j=l.longitude!=null?String(l.longitude):"",oe=(L||"Localização").replace(/"/g,"&quot;"),X=[{uf:"MA",name:"MA - Maranhão"},{uf:"SP",name:"SP - São Paulo"},{uf:"RJ",name:"RJ - Rio de Janeiro"},{uf:"MG",name:"MG - Minas Gerais"},{uf:"BA",name:"BA - Bahia"},{uf:"CE",name:"CE - Ceará"},{uf:"PE",name:"PE - Pernambuco"},{uf:"PA",name:"PA - Pará"},{uf:"PR",name:"PR - Paraná"},{uf:"RS",name:"RS - Rio Grande do Sul"},{uf:"SC",name:"SC - Santa Catarina"},{uf:"GO",name:"GO - Goiás"},{uf:"DF",name:"DF - Distrito Federal"},{uf:"ES",name:"ES - Espírito Santo"},{uf:"AM",name:"AM - Amazonas"},{uf:"PI",name:"PI - Piauí"},{uf:"RN",name:"RN - Rio Grande do Norte"},{uf:"PB",name:"PB - Paraíba"},{uf:"AL",name:"AL - Alagoas"},{uf:"SE",name:"SE - Sergipe"},{uf:"MT",name:"MT - Mato Grosso"},{uf:"MS",name:"MS - Mato Grosso do Sul"},{uf:"RO",name:"RO - Rondônia"},{uf:"TO",name:"TO - Tocantins"},{uf:"AC",name:"AC - Acre"},{uf:"AP",name:"AP - Amapá"},{uf:"RR",name:"RR - Roraima"}],V="MA",Z="São Luís",x="",B="",_="",w="",T="",z="mapa";if(l.street&&(x=l.street),l.house_number&&(B=l.house_number),l.bairro&&(_=l.bairro),l.city&&(Z=l.city),l.uf&&(V=l.uf),l.cep&&(w=l.cep),l.complement&&(T=l.complement),l.display_format&&(z=l.display_format),!B&&b){var K=b.match(/\b(?:n[ºo°]?\s*)?(\d{1,5}[A-Za-z]?)\b/i);K&&(B=K[1])}if(!x&&b){var O=b.split(",");x=(O[0]||"").replace(/\s*,?\s*(?:n[ºo°]?\s*)?\d{1,5}\s*$/i,"").trim()}if(!w&&b){var ee=b.match(/\b\d{5}-?\d{3}\b/);ee&&(w=ee[0])}for(var t=0;t<X.length;t++)if(X[t].uf&&(b.indexOf(X[t].name)!==-1||b.indexOf(" "+X[t].uf+",")!==-1||b.indexOf(" "+X[t].uf+" ")!==-1||b.indexOf("- "+X[t].uf)!==-1)){V=X[t].uf;break}var n=X.map(function(d){var y=d.uf===V?"selected":"";return`<option value="${d.uf}" ${y}>${d.name}</option>`}).join(""),r=[{v:"mapa",icon:"fas fa-map",label:"Cartão Mapa"},{v:"button",icon:"fas fa-map-marker-alt",label:"Botão"},{v:"banner",icon:"fas fa-image",label:"Banner"}],s=r.map(function(d){var y=d.v===z,q=y?"var(--dourado-principal,#FFC700)":"rgba(255,255,255,0.15)",Y=y?"rgba(255,199,0,0.12)":"transparent",re=y?"var(--dourado-principal,#FFC700)":"#aaa",ne=y?"var(--dourado-principal,#FFC700)":"#aaa";return`<label class="loc-fmt-label" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;padding:8px 4px;border-radius:8px;cursor:pointer;border:2px solid ${q};background:${Y};transition:all 0.2s;">
                        <input type="radio" name="loc-display-fmt-${a}" class="location-display-format-radio" value="${d.v}" ${y?"checked":""} style="display:none;">
                        <i class="${d.icon}" style="font-size:1.3rem;color:${re};"></i>
                        <span style="font-size:0.72rem;font-weight:600;color:${ne};">${d.label}</span>
                    </label>`}).join(""),i=l.banner_url||"";P=`
            <div class="input-group location-edit-panel" data-item-id="${a}">
                <label style="font-weight:600;font-size:0.85rem;margin-bottom:6px;display:block;">Título do botão / cartão</label>
                <input type="text" id="edit-title" class="location-title-input" value="${oe}" placeholder="Ex: Onde me encontrar" style="width:100%;padding:10px 12px;border-radius:8px;background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.15);font-size:0.9rem;">
            </div>

            <!-- Formato de Exibição no Cartão -->
            <div class="input-group" style="margin-bottom:14px;">
                <label style="font-weight:600;font-size:0.85rem;margin-bottom:8px;display:block;">Formato no Cartão Público</label>
                <div style="display:flex;gap:8px;">${s}</div>
                <input type="hidden" id="location-display-format" class="location-display-format" value="${z}">
            </div>

            <!-- Seção Banner (visível só no modo banner) -->
            <div id="location-banner-upload-section" style="display:${z==="banner"?"block":"none"};margin-bottom:14px;">
                <label style="font-weight:600;font-size:0.85rem;margin-bottom:6px;display:block;">Imagem do Banner <span style="font-weight:400;opacity:0.7;font-size:0.78rem;">(exibida no lugar do mapa)</span></label>
                <div class="location-banner-upload-area" style="border:2px dashed rgba(255,199,0,0.4);border-radius:10px;padding:18px;text-align:center;cursor:pointer;background:rgba(18,18,20,0.7);position:relative;">
                    <input type="file" class="location-banner-file-input" accept="image/*" style="display:none;">
                    <img src="${i}" class="location-banner-preview" style="max-width:100%;max-height:140px;border-radius:8px;display:${i?"block":"none"};margin:0 auto 10px;">
                    <div class="location-banner-placeholder" style="${i?"display:none;":""}">
                        <i class="fas fa-cloud-upload-alt" style="font-size:1.8rem;color:var(--dourado-principal,#FFC700);margin-bottom:6px;"></i>
                        <p style="margin:4px 0;color:#eee;font-size:0.85rem;">Clique para enviar imagem do banner</p>
                        <span style="font-size:0.78rem;color:#999;">JPG, PNG (máx 5MB)</span>
                    </div>
                </div>
                <input type="hidden" class="location-banner-url-input" value="${i}">
            </div>

            <!-- Caixa de Localização Estruturada -->
            <div class="location-structured-card" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,199,0,0.35);border-radius:12px;padding:14px;margin-bottom:12px;box-shadow:0 4px 20px rgba(0,0,0,0.25);">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px;">
                    <span style="font-weight:700;font-size:0.85rem;color:var(--dourado-principal,#FFC700);display:flex;align-items:center;gap:6px;">
                        <i class="fas fa-map-marker-alt"></i> Endereço Preciso
                    </span>
                    <button type="button" class="location-gps-btn" style="background:rgba(255,199,0,0.15);border:1px solid rgba(255,199,0,0.5);color:#FFC700;padding:6px 12px;border-radius:6px;font-size:0.8rem;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:all 0.2s;" title="Detectar endereço via GPS">
                        <i class="fas fa-crosshairs"></i> Usar Meu GPS
                    </button>
                </div>

                <!-- CEP e Bairro -->
                <div style="display:grid;grid-template-columns:135px 1fr;gap:8px;margin-bottom:10px;">
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">CEP (opcional)</label>
                        <div style="position:relative;">
                            <input type="text" id="location-cep-input" class="location-cep-input" value="${w}" placeholder="00000-000" maxlength="9" style="width:100%;padding:8px 10px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.2);font-size:0.85rem;">
                            <span class="location-cep-loading" style="display:none;position:absolute;right:8px;top:8px;color:#FFC700;font-size:0.8rem;"><i class="fas fa-spinner fa-spin"></i></span>
                        </div>
                    </div>
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">Bairro</label>
                        <input type="text" id="location-bairro-input" class="location-bairro-input" value="${_}" placeholder="Ex: Centro, Cohab, Calhau..." style="width:100%;padding:8px 10px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.2);font-size:0.85rem;">
                    </div>
                </div>

                <!-- Rua e Número -->
                <div style="display:grid;grid-template-columns:1fr 95px;gap:8px;margin-bottom:8px;">
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">Rua / Avenida / Ponto de Referência</label>
                        <input type="text" id="location-address-input" class="location-address-input" value="${x||b}" placeholder="Ex: Av. Tancredo Neves" style="width:100%;padding:9px 11px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.2);font-size:0.88rem;">
                    </div>
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;color:#FFC700;">Número &#9733;</label>
                        <input type="text" id="location-number-input" class="location-number-input" value="${B}" placeholder="820" style="width:100%;padding:9px 10px;border-radius:6px;background:rgba(18,18,20,0.95);color:#FFC700;border:1px solid rgba(255,199,0,0.55);font-size:0.88rem;font-weight:700;text-align:center;">
                    </div>
                </div>

                <!-- Complemento -->
                <div style="margin-bottom:10px;">
                    <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">Complemento <span style="opacity:0.6;font-weight:400;">(opcional)</span></label>
                    <input type="text" id="location-complement-input" class="location-complement-input" value="${T}" placeholder="Ex: Apto 42, Bloco B, Sala 301" style="width:100%;padding:8px 10px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.15);font-size:0.85rem;">
                </div>

                <!-- Cidade, UF e Botão Localizar -->
                <div style="display:grid;grid-template-columns:1fr 115px auto;gap:8px;align-items:end;">
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">Cidade</label>
                        <input type="text" id="location-city-input" class="location-city-input" value="${Z}" placeholder="Ex: São Luís" style="width:100%;padding:8px 10px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.2);font-size:0.85rem;">
                    </div>
                    <div>
                        <label style="display:block;font-size:0.75rem;opacity:0.85;margin-bottom:4px;font-weight:600;">Estado (UF)</label>
                        <select id="location-uf-select" class="location-uf-select" style="width:100%;padding:8px 8px;border-radius:6px;background:rgba(18,18,20,0.95);color:#fff;border:1px solid rgba(255,255,255,0.2);font-size:0.85rem;cursor:pointer;">
                            ${n}
                        </select>
                    </div>
                    <div>
                        <button type="button" class="location-search-btn" style="padding:9px 14px;border-radius:6px;background:var(--dourado-principal,#FFC700);color:#000;border:none;font-weight:700;font-size:0.85rem;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:6px;transition:all 0.2s;height:35px;">
                            <i class="fas fa-search-location"></i> Localizar
                        </button>
                    </div>
                </div>
            </div>

            <!-- Lista de Sugestões -->
            <div id="location-results-container" class="location-results-container" style="display:none;margin-bottom:12px;background:#18181b;border:1px solid rgba(255,199,0,0.4);border-radius:10px;padding:10px;max-height:230px;overflow-y:auto;box-shadow:0 10px 30px rgba(0,0,0,0.6);">
                <div style="display:flex;align-items:center;justify-content:space-between;padding-bottom:6px;margin-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.1);font-size:0.8rem;color:#FFC700;font-weight:600;">
                    <span class="location-results-count"><i class="fas fa-map-marked-alt"></i> Opções encontradas:</span>
                    <button type="button" class="location-results-close-btn" style="background:none;border:none;color:#aaa;cursor:pointer;font-size:1.1rem;line-height:1;padding:0 6px;" title="Fechar opções">&times;</button>
                </div>
                <div class="location-results-list" style="display:flex;flex-direction:column;gap:6px;"></div>
            </div>

            <!-- Endereço Definido -->
            <div class="location-selected-card" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:10px 12px;margin-bottom:10px;display:flex;align-items:flex-start;gap:10px;">
                <i class="fas fa-map-pin" style="color:var(--dourado-principal,#FFC700);margin-top:3px;font-size:1.1rem;flex-shrink:0;"></i>
                <div style="flex:1;min-width:0;">
                    <span style="font-size:0.72rem;opacity:0.75;display:block;text-transform:uppercase;letter-spacing:0.5px;">Endereço Definido no Mapa</span>
                    <p class="location-formatted-display" style="font-size:0.85rem;line-height:1.4;margin:2px 0 0 0;font-weight:500;word-break:break-word;">${b||"Nenhum endereço definido ainda. Preencha acima e clique em Localizar."}</p>
                </div>
            </div>

            <input type="hidden" id="location-lat-input" class="location-lat-input" value="${te}">
            <input type="hidden" id="location-lng-input" class="location-lng-input" value="${j}">

            <!-- Mapa Interativo Leaflet -->
            <div class="input-group">
                <label style="font-weight:600;font-size:0.85rem;margin-bottom:6px;display:block;">Ponto no Mapa <span style="font-size:0.75rem;opacity:0.7;font-weight:400;">(clique ou arraste o marcador)</span></label>
                <div class="location-map-preview-edit" style="height:250px;border-radius:12px;overflow:hidden;background:rgba(0,0,0,0.3);position:relative;border:1px solid rgba(255,255,255,0.15);">
                    <div id="location-map-container-${a}" class="location-map-container" style="width:100%;height:100%;min-height:250px;"></div>
                </div>
                <p style="font-size:0.72rem;opacity:0.7;margin-top:6px;"><i class="fas fa-info-circle" style="color:#FFC700;"></i> O visitante poderá traçar rota pelo Google Maps ou Waze diretamente do cartão.</p>
            </div>
        `})();break;case"digital_form":let h={};if(window.currentProfileData&&window.currentProfileData.items){const v=window.currentProfileData.items.find(l=>String(l.id)===String(a));v&&v.digital_form_data?h=v.digital_form_data:v&&v.form_data&&(h=v.form_data)}const le=!a||!/^\d+$/.test(String(a).trim())||String(a).startsWith("temp_")||String(a).startsWith("te_");if(needsFormHydrate&&!le)try{typeof I().updateHeaders=="function"&&I().updateHeaders();const v=await ve(`${M.API_URL}/api/profile/items/${a}`,{method:"GET",headers:M.HEADERS});if(v.ok){const l=await v.json().catch(()=>null),b=l&&(l.digital_form_data||l.form_data||l.data)||l;if(b&&typeof b=="object"&&(h=Object.assign({},h,b.digital_form_data||b.form_data||b),window.currentProfileData&&window.currentProfileData.items)){const te=window.currentProfileData.items.findIndex(j=>String(j.id)===String(a));te>=0&&(window.currentProfileData.items[te]=Object.assign({},window.currentProfileData.items[te],l,{digital_form_data:h,form_data:h}))}}}catch{}const ge=h.form_title||L||"Formulário King",ce=h.form_logo_url||"",be=h.form_description||"",N=h.whatsapp_number||"",ae=h.display_format||"button",me=h.banner_image_url||e.querySelector(".item-image-url-input")?.value||"";h.header_image_url,h.background_image_url,h.background_opacity!==void 0&&h.background_opacity,h.theme,h.primary_color,h.text_color;const he=h.form_fields||[];P=`
            <!-- Sistema de Abas -->
            <div class="form-tabs-container" style="margin-bottom: 20px; border-bottom: 2px solid var(--border-color, #2C2C2F);">
                <div class="form-tabs" style="display: flex; gap: 0;">
                    <button type="button" class="form-tab-btn active" data-tab="config" style="flex: 1; padding: 12px 20px; background: transparent; border: none; border-bottom: 3px solid var(--dourado-principal, #FFC700); color: var(--dourado-principal, #FFC700); cursor: pointer; font-weight: 600; transition: all 0.3s;">
                        <i class="fas fa-cog"></i> Configurações
                    </button>
                    <button type="button" class="form-tab-btn" data-tab="questions" style="flex: 1; padding: 12px 20px; background: transparent; border: none; border-bottom: 3px solid transparent; color: var(--text-dark, #A1A1A1); cursor: pointer; font-weight: 600; transition: all 0.3s;">
                        <i class="fas fa-question-circle"></i> Perguntas
                    </button>
                    <button type="button" class="form-tab-btn" data-tab="responses" style="flex: 1; padding: 12px 20px; background: transparent; border: none; border-bottom: 3px solid transparent; color: var(--text-dark, #A1A1A1); cursor: pointer; font-weight: 600; transition: all 0.3s;">
                        <i class="fas fa-chart-bar"></i> Respostas
                    </button>
                </div>
            </div>
            
            <!-- Aba: Configurações -->
            <div class="form-tab-content" data-tab-content="config" style="display: block;">
            <div class="input-group">
                <label>Título do Módulo</label>
                <input type="text" id="edit-digital-form-title" value="${L||"Formulário King"}" placeholder="Formulário King">
            </div>
            <div class="input-group">
                <label>Formato de Exibição</label>
                <div style="display: flex; gap: 15px; margin-top: 10px;">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="radio" name="digital-form-display-format" value="button" ${ae==="button"?"checked":""}>
                        <span>Botão</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="radio" name="digital-form-display-format" value="banner" ${ae==="banner"?"checked":""}>
                        <span>Banner</span>
                    </label>
                </div>
            </div>
            <div id="digital-form-banner-image-container" style="display: ${ae==="banner"?"block":"none"};">
                <div class="input-group">
                    <label>Imagem do Banner</label>
                    <div class="image-upload-area form-banner-upload-area" style="margin-bottom: 15px; position: relative; border: 2px dashed var(--border-color, #2C2C2F); border-radius: 8px; padding: 20px; text-align: center; cursor: pointer; background: var(--card-background-color, #1C1C21);">
                        <input type="file" class="item-file-input form-banner-file-input" accept="image/*" style="display: none;">
                        <img src="${me||""}" id="digital-form-banner-preview" class="banner-preview form-banner-preview" style="max-width: 100%; max-height: 200px; margin-bottom: 10px; ${me?"display: block;":"display: none;"}">
                        <div class="image-upload-text" style="${me?"display: none;":""}">
                            <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: var(--dourado-principal, #FFC700); margin-bottom: 10px;"></i>
                            <p style="margin: 5px 0; color: var(--text, #ECECEC);">Clique para fazer upload do Banner</p>
                            <span style="font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">JPG, PNG (máx. 5MB)</span>
                        </div>
                        <button type="button" class="remove-banner-btn" style="display: ${me?"block":"none"}; margin-top: 10px; padding: 5px 15px; background: #ff4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-trash"></i> Remover Banner
                        </button>
                        <div class="upload-loader"></div>
                    </div>
                </div>
            </div>
            <input type="hidden" id="edit-digital-form-banner-image" class="item-banner-image-url-input" value="${me}">
            <div class="input-group">
                <label>Título do Formulário</label>
                <input type="text" id="edit-form-title" value="${ge}" placeholder="Ex: Formulário de Contato">
            </div>
            <div class="input-group">
                <label>Logo do Formulário</label>
                <div class="logo-upload-area form-logo-upload-area" style="margin-bottom: 15px; position: relative; border: 2px dashed var(--border-color, #2C2C2F); border-radius: 8px; padding: 20px; text-align: center; cursor: pointer; background: var(--card-background-color, #1C1C21);">
                    <input type="file" class="item-logo-file-input form-logo-file-input" accept="image/png,image/jpeg,image/jpg" style="display: none;">
                    <img src="${ce||""}" id="digital-form-logo-preview" class="item-logo-upload-preview form-logo-upload-preview" style="max-width: 150px; max-height: 150px; width: 150px; height: 150px; object-fit: contain; margin-bottom: 10px; border-radius: 8px; ${ce?"display: block;":"display: none;"}">
                    <div class="logo-upload-text" style="${ce?"display: none;":""}">
                        <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: var(--dourado-principal, #FFC700); margin-bottom: 10px;"></i>
                        <p style="margin: 5px 0; color: var(--text, #ECECEC);">Clique para fazer upload</p>
                        <span style="font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">PNG ou JPG (máx. 5MB)</span>
                    </div>
                    <button type="button" class="remove-logo-btn" style="display: ${ce?"block":"none"}; margin-top: 10px; padding: 5px 15px; background: #ff4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-trash"></i> Remover Logo
                    </button>
                    <div class="upload-loader"></div>
                </div>
                <input type="hidden" id="edit-form-logo-url" class="item-form-logo-url-input" value="${ce}">
                <div class="input-group">
                    <label>Descrição do Formulário</label>
                    <textarea id="edit-form-description" rows="3" placeholder="Descreva o propósito do formulário...">${be}</textarea>
                </div>
                
                <div class="input-group">
                    <label>Número do WhatsApp para Receber Respostas</label>
                    <input type="text" id="edit-digital-form-whatsapp" value="${N}" placeholder="5511999999999 (com DDD e código do país)">
                    <small style="color: #999; display: block; margin-top: 5px;">As respostas do formulário serão enviadas para este WhatsApp</small>
                </div>
            </div>
            
            <!-- Aba: Perguntas -->
            <div class="form-tab-content" data-tab-content="questions" style="display: none;">
                <div style="margin-bottom: 20px;">
                    <button type="button" class="btn btn-primary add-question-btn" data-item-id="${a}" style="width: 100%; padding: 12px; background: var(--dourado-principal, #FFC700); color: #000; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        <i class="fas fa-plus"></i> Adicionar Pergunta
                    </button>
                </div>
                <div id="form-questions-container-${a}" class="form-questions-container" data-item-id="${a}">
                    <!-- Perguntas serão renderizadas aqui -->
                </div>
                <input type="hidden" id="edit-digital-form-fields" value='${JSON.stringify(he)}'>
            </div>
            
            <!-- Aba: Respostas -->
            <div class="form-tab-content" data-tab-content="responses" style="display: none;">
                <div id="form-responses-dashboard-${a}" class="form-responses-dashboard" data-item-id="${a}">
                    <div style="text-align: center; padding: 40px; color: var(--text-dark, #A1A1A1);">
                        <i class="fas fa-spinner fa-spin" style="font-size: 2rem; margin-bottom: 15px;"></i>
                        <p>Carregando respostas...</p>
                    </div>
                </div>
            </div>
            
            <!-- Botão para abrir página de edição completa -->
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid var(--border-color, #2C2C2F);">
                <button type="button" class="btn-edit-form-page" data-item-id="${a}" style="width: 100%; padding: 14px; background: var(--dourado-principal, #FFC700); color: #000; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 10px;">
                    <i class="fas fa-external-link-alt"></i>
                    <span>Abrir Página de Edição Completa</span>
                </button>
                <p style="text-align: center; color: var(--text-dark, #A1A1A1); font-size: 0.85rem; margin-top: 10px;">Para editar perguntas e visualizar respostas, abra a página de edição completa</p>
            </div>
        `,setTimeout(()=>{const v=`#edit-item-modal[data-editing-id="${a}"]`,l=document.querySelectorAll(`${v} .form-tab-btn`),b=document.querySelectorAll(`${v} .form-tab-content`);l.forEach(x=>{x.addEventListener("click",()=>{const B=x.dataset.tab;l.forEach(w=>{w.classList.remove("active"),w.style.borderBottomColor="transparent",w.style.color="var(--text-dark, #A1A1A1)"}),x.classList.add("active"),x.style.borderBottomColor="var(--dourado-principal, #FFC700)",x.style.color="var(--dourado-principal, #FFC700)",b.forEach(w=>{w.style.display="none"});const _=document.querySelector(`${v} .form-tab-content[data-tab-content="${B}"]`);_&&(_.style.display="block",B==="responses"&&typeof window.loadFormResponses=="function"&&setTimeout(()=>window.loadFormResponses(a),100),B==="questions"&&typeof window.renderFormQuestions=="function"&&setTimeout(()=>{const w=document.querySelector(`${v} #edit-digital-form-fields`);let T=[];if(w&&w.value)try{T=JSON.parse(w.value)}catch{T=[]}window.renderFormQuestions(a,T)},100))})});const te=document.querySelectorAll(`${v} input[name="digital-form-display-format"]`),j=document.getElementById("digital-form-banner-image-container");te.forEach(x=>{x.addEventListener("change",()=>{j&&(j.style.display=x.value==="banner"?"block":"none")})});const oe=document.querySelector(`#edit-item-modal[data-editing-id="${a}"] .form-logo-upload-area`),X=document.querySelector(`#edit-item-modal[data-editing-id="${a}"] .form-logo-file-input`);if(oe&&X){const x=oe.cloneNode(!0);oe.parentNode.replaceChild(x,oe);const B=x.querySelector(".form-logo-file-input");x.addEventListener("click",w=>{w.stopPropagation(),B.click()}),B.addEventListener("change",async w=>{w.stopPropagation();const T=w.target.files[0];if(!T)return;if(!T.type.match(/^image\/(png|jpeg|jpg)$/)){alert("Apenas imagens PNG ou JPG são permitidas.");return}if(T.size>5*1024*1024){alert("A imagem deve ter no máximo 5MB.");return}const z=document.getElementById("digital-form-logo-preview"),K=document.getElementById("edit-form-logo-url"),O=x.querySelector(".logo-upload-text"),ee=x.querySelector(".remove-logo-btn"),t=x.querySelector(".upload-loader");t&&(t.style.display="block"),O&&(O.style.opacity="0.5");try{const n=await ve(`${M.API_URL}/api/upload/auth`,{method:"POST",headers:M.HEADERS});if(!n.ok)throw new Error("Falha ao obter autorização para upload.");const{uploadURL:r}=await n.json(),s=new FormData;s.append("file",T);const i=await ve(r,{method:"POST",headers:M.getAuthHeaders(),body:s});if(!i.ok)throw new Error("Falha no upload da imagem.");const d=await i.json(),y=d.url||d.imageUrl||(d.result&&d.result.id?`https://imagedelivery.net/MBdqwyqeFtFBvKiQjgzjtQ/${d.result.id}/public`:"");z&&(z.src=y,z.style.display="block"),K&&(K.value=y),O&&(O.style.display="none"),ee&&(ee.style.display="block"),se("Logo do formulário digital enviado:",y)}catch(n){alert(`Erro ao fazer upload: ${n.message}`)}finally{t&&(t.style.display="none"),O&&(O.style.opacity="1")}});const _=x.querySelector(".remove-logo-btn");_&&_.addEventListener("click",w=>{w.stopPropagation();const T=document.getElementById("digital-form-logo-preview"),z=document.getElementById("edit-form-logo-url"),K=x.querySelector(".logo-upload-text");T&&(T.style.display="none"),z&&(z.value=""),K&&(K.style.display="block"),_.style.display="none"})}const V=document.querySelector(".form-banner-upload-area"),Z=document.querySelector(".form-banner-file-input");if(V&&Z){V.addEventListener("click",()=>Z.click()),Z.addEventListener("change",async B=>{const _=B.target.files[0];if(!_)return;if(!_.type.match(/^image\/(png|jpeg|jpg)$/)){alert("Apenas imagens PNG ou JPG são permitidas.");return}if(_.size>5*1024*1024){alert("A imagem deve ter no máximo 5MB.");return}const w=document.getElementById("digital-form-banner-preview"),T=document.getElementById("edit-digital-form-banner-image"),z=V.querySelector(".image-upload-text"),K=V.querySelector(".remove-banner-btn"),O=V.querySelector(".upload-loader");O&&(O.style.display="block"),z&&(z.style.opacity="0.5");try{const ee=await ve(`${M.API_URL}/api/upload/auth`,{method:"POST",headers:M.HEADERS});if(!ee.ok)throw new Error("Falha ao obter autorização para upload.");const{uploadURL:t}=await ee.json(),n=new FormData;n.append("file",_);const r=await ve(t,{method:"POST",headers:M.getAuthHeaders(),body:n});if(!r.ok)throw new Error("Falha no upload da imagem.");const s=await r.json(),i=s.url||s.imageUrl||(s.result&&s.result.id?`https://imagedelivery.net/MBdqwyqeFtFBvKiQjgzjtQ/${s.result.id}/public`:"");w&&(w.src=i,w.style.display="block"),T&&(T.value=i),z&&(z.style.display="none"),K&&(K.style.display="block"),se("Banner do formulário digital enviado:",i)}catch(ee){alert(`Erro ao fazer upload: ${ee.message}`)}finally{O&&(O.style.display="none"),z&&(z.style.opacity="1")}});const x=V.querySelector(".remove-banner-btn");x&&x.addEventListener("click",B=>{B.stopPropagation();const _=document.getElementById("digital-form-banner-preview"),w=document.getElementById("edit-digital-form-banner-image"),T=V.querySelector(".image-upload-text");_&&(_.style.display="none"),w&&(w.value=""),T&&(T.style.display="block"),x.style.display="none"})}},100);break}const ke={link:"Editar Link Personalizado",carousel:"Editar Carrossel",digital_form:"Editar Formulário King",location:"Editar Localização",wifi:"Editar Wi-Fi (QR Code)"};if(u.editModalTitle.textContent=ke[o]||(o==="banner"?"Editar Banner":`Editar ${o.replace("_"," ").charAt(0).toUpperCase()+o.replace("_"," ").slice(1)}`),u.editModalBody.innerHTML=P,u.editItemModal.dataset.editingId=a,u.editItemModal.dataset.itemType=o,u.editItemModal.dataset.isNewItem="false",se("[MODAL] Modal configurado:",{editingId:u.editItemModal.dataset.editingId,itemType:u.editItemModal.dataset.itemType,isNewItem:u.editItemModal.dataset.isNewItem}),u.editItemModal.classList.add("active"),o==="carousel"&&setTimeout(()=>{const g=u.editModalBody.querySelector(`.carousel-images-json-new[data-item-id="${a}"]`);if(g&&g.value)try{const A=JSON.parse(g.value);renderCarouselImagesNew(a,A)}catch{}const k=u.editModalBody.querySelector(`#carousel-file-new-${a}`);if(k){se("[CARROSSEL] Input encontrado no modal:",k.id);const A=k.cloneNode(!0);k.parentNode.replaceChild(A,k),se("[CARROSSEL] Input clonado e substituído para garantir listener")}},150),o==="location"&&(function(){var k=window.currentProfileData&&window.currentProfileData.items?window.currentProfileData.items.find(function(t){return String(t.id)===String(a)}):null,A=k&&k.location_data||{},$=u.editModalBody.querySelector(".location-lat-input"),E=u.editModalBody.querySelector(".location-lng-input"),D=u.editModalBody.querySelector("#location-map-container-"+a),R=u.editModalBody.querySelector(".location-search-btn"),p=u.editModalBody.querySelector("#location-address-input"),m=u.editModalBody.querySelector("#location-number-input"),f=u.editModalBody.querySelector("#location-bairro-input"),C=u.editModalBody.querySelector("#location-city-input"),S=u.editModalBody.querySelector("#location-uf-select"),F=u.editModalBody.querySelector("#location-cep-input"),J=u.editModalBody.querySelector(".location-cep-loading"),U=u.editModalBody.querySelector(".location-formatted-display"),h=u.editModalBody.querySelector(".location-gps-btn"),le=u.editModalBody.querySelector("#location-results-container"),ge=u.editModalBody.querySelector(".location-results-list"),ce=u.editModalBody.querySelector(".location-results-close-btn"),be=u.editModalBody.querySelector(".location-results-count");U&&A&&A.address_formatted&&(U.textContent=A.address_formatted);var N=null,ae=null,me=[-2.5387,-44.2825];function he(){if(window.L&&window.L.Icon&&window.L.Icon.Default)try{delete window.L.Icon.Default.prototype._getIconUrl,window.L.Icon.Default.mergeOptions({iconRetinaUrl:"/images/leaflet/marker-icon-2x.png",iconUrl:"/images/leaflet/marker-icon.png",shadowUrl:"/images/leaflet/marker-shadow.png"})}catch{}}function v(){if(p){var t=p.value||"",n=m?m.value.trim():"";if(!n){var r=t.match(/\s*,?\s*(?:n[ºo°]?\s*)?(\d{1,5})\s*$/i);r&&(m&&(m.value=r[1]),p.value=t.substring(0,r.index).replace(/,\s*$/,"").trim())}}}function l(){if(U){var t=[],n=p?p.value.trim():"",r=m?m.value.trim():"",s=f?f.value.trim():"",i=C?C.value.trim():"",d=S?S.value.trim():"",y=F?F.value.trim():"";n&&t.push(n+(r?", "+r:"")),s&&t.push(s),i?t.push(i+(d?" - "+d:"")):d&&t.push(d),y&&t.push("CEP "+y),t.push("Brasil"),t.length>1&&(U.textContent=t.join(", "))}}function b(t,n,r){$&&($.value=t),E&&(E.value=n);var s=(M.API_URL||"")+"/api/location/reverse-geocode?lat="+encodeURIComponent(t)+"&lon="+encodeURIComponent(n);fe(s,{headers:{Accept:"application/json"},credentials:"omit"}).then(function(i){if(!i.ok)throw new Error("Proxy error");return i.json()}).catch(function(){return fe("https://nominatim.openstreetmap.org/reverse?lat="+encodeURIComponent(t)+"&lon="+encodeURIComponent(n)+"&format=json&addressdetails=1",{headers:{Accept:"application/json"},credentials:"omit"}).then(function(i){return i.json()})}).then(function(i){var d=m?m.value.trim():"";i&&i.street&&p&&!p.value&&(p.value=i.street),i&&i.house_number&&m&&!m.value&&(m.value=i.house_number,d=i.house_number),i&&i.uf&&S&&(S.value=i.uf),i&&i.city&&C&&!C.value&&(C.value=i.city),i&&i.suburb&&f&&!f.value&&(f.value=i.suburb);var y=(p?p.value.trim():"")||i&&i.street||"",q=d||(m?m.value.trim():""),Y=(f?f.value.trim():"")||i&&i.suburb||"",re=(C?C.value.trim():"")||i&&i.city||"",ne=(S?S.value:"")||i&&i.uf||"",W=[];y&&W.push(y+(q?", "+q:"")),Y&&W.push(Y),re&&W.push(re+(ne?" - "+ne:"")),W.push("Brasil");var G=W.length>1?W.join(", "):i&&i.display_name||"Endereço selecionado no mapa.";U&&(U.textContent=G)}).catch(function(){U&&(U.textContent="Endereço não identificado para estas coordenadas (ponto marcado).")})}function te(t){var n=typeof t.lat=="function"?t.lat():t.lat,r=typeof t.lng=="function"?t.lng():t.lng;he(),ae?ae.setLatLng(t):window.L&&N&&(ae=window.L.marker(t,{draggable:!0}).addTo(N),ae.on("dragend",function(){var s=ae.getLatLng();b(s.lat,s.lng)})),$&&($.value=n),E&&(E.value=r),N&&N.setView([n,r],N.getZoom()<16?16:N.getZoom())}function j(t,n){var r=parseFloat(t),s=parseFloat(n);if(!(isNaN(r)||isNaN(s))&&N){var i=window.L&&window.L.latLng(r,s);N.setView(i,16),te(i)}}var oe=function(){if(window.L&&D){if(he(),window._lastLocationLeafletMap){try{window._lastLocationLeafletMap.remove()}catch{}window._lastLocationLeafletMap=null}setTimeout(function(){var t=$&&E&&$.value&&E.value&&!isNaN(parseFloat($.value)),n=t?[parseFloat($.value),parseFloat(E.value)]:me,r=t?16:12;if(N=window.L.map(D,{center:n,zoom:r}),window.L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',maxZoom:19}).addTo(N),t){var s=window.L.latLng(parseFloat($.value),parseFloat(E.value));ae=window.L.marker(s,{draggable:!0}).addTo(N),ae.on("dragend",function(){var i=ae.getLatLng();b(i.lat,i.lng)})}N.on("click",function(i){te(i.latlng),b(i.latlng.lat,i.latlng.lng)}),D._leafletMap=N,window._lastLocationLeafletMap=N,setTimeout(function(){N&&N.invalidateSize()},300)},200)}};typeof window.ckEnsureLeaflet=="function"?window.ckEnsureLeaflet().then(oe).catch(function(){}):oe();function X(t){var n=t.lat,r=t.lon,s=t.display_name||"",i=m?m.value.trim():"";$&&($.value=n),E&&(E.value=r),t.street&&p&&(p.value=t.street),t.house_number&&m&&(m.value=t.house_number);var d=t.suburb||t.bairro||"";if(d&&f&&(f.value=d),t.city&&C&&(C.value=t.city),t.uf&&S&&(S.value=t.uf),t.postcode&&F&&!F.value?F.value=t.postcode:t.cep&&F&&!F.value&&(F.value=t.cep),i&&s&&s.indexOf(i)===-1){var y=s.indexOf(",");y!==-1&&(s=s.substring(0,y)+", "+i+s.substring(y))}U&&(U.textContent=s),j(n,r),le&&(le.style.display="none")}function V(t){if(!(!le||!ge)){if(ge.innerHTML="",!t||!Array.isArray(t)||t.length===0){le.style.display="block",be&&(be.innerHTML='<i class="fas fa-exclamation-circle" style="color:#f39c12;"></i> Nenhum resultado encontrado'),ge.innerHTML='<div style="padding:10px 8px;font-size:0.8rem;color:#bbb;text-align:center;">Não encontramos nenhum local com esses dados. Tente informar o nome da rua, número e confirmar a Cidade/Estado.</div>';return}le.style.display="block",be&&(be.innerHTML='<i class="fas fa-list-ul"></i> '+t.length+" opções encontradas (clique na sua):");var n=t[0];if(n){var r=m?m.value.trim():"";$&&($.value=n.lat),E&&(E.value=n.lon);var s=n.display_name||"";if(r&&s&&s.indexOf(r)===-1){var i=s.indexOf(",");i!==-1&&(s=s.substring(0,i)+", "+r+s.substring(i))}U&&(U.textContent=s),n.uf&&S&&!S.value&&(S.value=n.uf),n.city&&C&&!C.value&&(C.value=n.city),j(n.lat,n.lon)}t.forEach(function(d,y){var q=document.createElement("div");q.className="location-option-item",q.style.cssText="padding:10px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;cursor:pointer;display:flex;align-items:flex-start;gap:10px;transition:all 0.15s ease;";var Y=m?m.value.trim():"",re=d.house_number||Y,ne=d.street?d.street+(re?", "+re:""):d.display_name?d.display_name.split(",")[0]:"Opção "+(y+1),W=d.badge||((d.city||"")+(d.uf?" - "+d.uf:d.state?" - "+d.state:"")).trim();W=W.replace(/^[\s,-]+/,"");var G=y===0;G&&(q.style.border="1px solid rgba(255,199,0,0.45)",q.style.background="rgba(255,199,0,0.08)"),q.innerHTML=`
                        <i class="fas fa-map-pin" style="color:var(--dourado-principal,#FFC700);margin-top:2px;font-size:1rem;flex-shrink:0;"></i>
                        <div style="flex:1;min-width:0;">
                            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:2px;">
                                <strong style="font-size:0.88rem;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ne}</strong>
                                ${W?`<span style="font-size:0.72rem;background:rgba(255,199,0,0.2);color:#FFC700;border:1px solid rgba(255,199,0,0.4);border-radius:4px;padding:2px 6px;white-space:nowrap;font-weight:600;">${W}</span>`:""}
                            </div>
                            <p style="font-size:0.78rem;opacity:0.8;margin:0;line-height:1.3;word-break:break-word;">${d.display_name||""}</p>
                        </div>
                    `,q.addEventListener("mouseenter",function(){q.style.background="rgba(255,199,0,0.18)",q.style.borderColor="rgba(255,199,0,0.6)"}),q.addEventListener("mouseleave",function(){G?(q.style.background="rgba(255,199,0,0.08)",q.style.borderColor="rgba(255,199,0,0.45)"):(q.style.background="rgba(255,255,255,0.05)",q.style.borderColor="rgba(255,255,255,0.1)")}),q.addEventListener("click",function(){X(d)}),ge.appendChild(q)})}}function Z(){v();var t=(p&&p.value||"").trim(),n=(m&&m.value||"").trim(),r=(f&&f.value||"").trim(),s=(S&&S.value||"").trim(),i=(C&&C.value||"").trim(),d=(F&&F.value||"").trim();if(!t&&!i&&!d){U&&(U.textContent="Digite o nome da rua ou CEP para pesquisar.");return}R&&(R.disabled=!0,R.innerHTML='<i class="fas fa-spinner fa-spin"></i> Localizando...');var y=new URLSearchParams;t&&y.set("q",t),n&&y.set("number",n),r&&y.set("bairro",r),i&&y.set("city",i),s&&y.set("uf",s),d&&y.set("cep",d),y.set("limit","12");var q=(M.API_URL||"")+"/api/location/geocode?"+y.toString();fe(q,{headers:{Accept:"application/json"},credentials:"omit"}).then(function(Y){if(!Y.ok)throw new Error("Proxy error "+Y.status);return Y.json()}).catch(function(){var Y=t+(n?", "+n:"")+(r?", "+r:"")+(i?", "+i:"")+(s?", "+s:"")+", Brasil";return fe("https://nominatim.openstreetmap.org/search?q="+encodeURIComponent(Y)+"&format=json&limit=10&countrycodes=br&addressdetails=1",{headers:{Accept:"application/json"},credentials:"omit"}).then(function(re){return re.json().then(function(ne){return Array.isArray(ne)?ne.map(function(W){var G=W.address||{};return{lat:W.lat,lon:W.lon,display_name:W.display_name,street:G.road||G.street||W.name,house_number:G.house_number||n||"",city:G.city||G.town||G.village||i||"",state:G.state||"",uf:s||"",badge:(G.city||G.town||i||"")+(G.state?" - "+G.state:s?" - "+s:"")}}):[]})})}).then(function(Y){V(Y)}).catch(function(){U&&(U.textContent="Erro ao pesquisar. Tente novamente.")}).finally(function(){R&&(R.disabled=!1,R.innerHTML='<i class="fas fa-search-location"></i> Localizar')})}function x(){if(F){var t=(F.value||"").replace(/\D/g,"");if(t.length===8){F.value=t.substring(0,5)+"-"+t.substring(5),J&&(J.style.display="inline-block");var n=(M.API_URL||"")+"/api/location/cep/"+t;fe(n,{headers:{Accept:"application/json"},credentials:"omit"}).then(function(r){return r.json()}).then(function(r){J&&(J.style.display="none"),r&&!r.erro&&!r.error&&(r.logradouro&&p&&(p.value=r.logradouro),r.bairro&&f&&(f.value=r.bairro),r.localidade&&C&&(C.value=r.localidade),r.uf&&S&&(S.value=r.uf),l(),m&&m.focus(),Z())}).catch(function(){J&&(J.style.display="none")})}}}F&&(F.addEventListener("input",function(){var t=F.value.replace(/\D/g,"");t.length>5&&(F.value=t.substring(0,5)+"-"+t.substring(5,8)),t.length===8&&x()}),F.addEventListener("blur",x)),R&&R.addEventListener("click",Z),p&&(p.addEventListener("blur",function(){v(),l()}),p.addEventListener("keydown",function(t){t.key==="Enter"&&(t.preventDefault(),Z())})),m&&(m.addEventListener("input",l),m.addEventListener("keydown",function(t){t.key==="Enter"&&(t.preventDefault(),Z())})),f&&(f.addEventListener("blur",l),f.addEventListener("keydown",function(t){t.key==="Enter"&&(t.preventDefault(),Z())})),C&&(C.addEventListener("blur",l),C.addEventListener("keydown",function(t){t.key==="Enter"&&(t.preventDefault(),Z())})),S&&S.addEventListener("change",l);var B=u.editModalBody.querySelector("#location-display-format"),_=u.editModalBody.querySelectorAll(".location-display-format-radio"),w=u.editModalBody.querySelector("#location-banner-upload-section");_.forEach(function(t){t.closest("label").addEventListener("click",function(){_.forEach(function(n){var r=n.closest("label"),s=r.querySelector("i"),i=r.querySelector("span"),d=n===t;r.style.borderColor=d?"var(--dourado-principal,#FFC700)":"rgba(255,255,255,0.15)",r.style.background=d?"rgba(255,199,0,0.12)":"transparent",s&&(s.style.color=d?"var(--dourado-principal,#FFC700)":"#aaa"),i&&(i.style.color=d?"var(--dourado-principal,#FFC700)":"#aaa")}),t.checked=!0,B&&(B.value=t.value),w&&(w.style.display=t.value==="banner"?"block":"none")})});var T=u.editModalBody.querySelector(".location-banner-upload-area"),z=u.editModalBody.querySelector(".location-banner-file-input"),K=u.editModalBody.querySelector(".location-banner-preview"),O=u.editModalBody.querySelector(".location-banner-placeholder"),ee=u.editModalBody.querySelector(".location-banner-url-input");T&&z&&(T.addEventListener("click",function(){z.click()}),z.addEventListener("change",function(t){var n=t.target.files&&t.target.files[0];if(n){var r=new FileReader;r.onload=function(s){K&&(K.src=s.target.result,K.style.display="block"),O&&(O.style.display="none"),ee&&(ee.value=s.target.result)},r.readAsDataURL(n)}})),ce&&le&&ce.addEventListener("click",function(){le.style.display="none"}),h&&h.addEventListener("click",function(){if(!navigator.geolocation){alert("Geolocalização não é suportada pelo seu navegador.");return}var t=h.innerHTML;h.disabled=!0,h.innerHTML='<i class="fas fa-spinner fa-spin"></i> Localizando...',navigator.geolocation.getCurrentPosition(function(n){var r=n.coords.latitude,s=n.coords.longitude;j(r,s),b(r,s),h.disabled=!1,h.innerHTML='<i class="fas fa-check"></i> Localizado!',setTimeout(function(){h.innerHTML=t},2500)},function(n){h.disabled=!1,h.innerHTML=t,alert("Não foi possível obter a localização do dispositivo. Verifique se o GPS e as permissões de localização estão ativados no navegador.")},{enableHighAccuracy:!0,timeout:12e3,maximumAge:3e4})})})(),o==="link"){const g=document.getElementById(`edit-logo-size-slider-${a}`),k=document.getElementById(`edit-logo-size-input-${a}`),A=document.getElementById(`edit-logo-size-value-${a}`),$=u.editModalBody.querySelector(".item-logo-upload-preview");g&&k&&A&&(g.addEventListener("input",R=>{const p=parseInt(R.target.value);if(k.value=p,A.textContent=p,$){const f=Math.min(p,100);$.style.width=f+"px",$.style.height=f+"px",$.style.maxWidth=f+"px",$.style.maxHeight=f+"px"}const m=document.querySelector(`[data-item-id="${a}"]`);if(m){m.dataset.logoSize=p;const f=m.querySelector(".item-logo-size-input");f&&(f.value=p)}M.updateLivePreviewFromForm()}),k.addEventListener("input",R=>{let p=parseInt(R.target.value);if(isNaN(p)&&(p=24),p<20&&(p=20),p>600&&(p=600),k.value=p,g.value=p,A.textContent=p,$){const f=Math.min(p,100);$.style.width=f+"px",$.style.height=f+"px",$.style.maxWidth=f+"px",$.style.maxHeight=f+"px"}const m=document.querySelector(`[data-item-id="${a}"]`);if(m){m.dataset.logoSize=p;const f=m.querySelector(".item-logo-size-input");f&&(f.value=p)}M.updateLivePreviewFromForm()}));const E=document.querySelectorAll(`input[name="edit-logo-fit-mode-${a}"]`),D=document.getElementById(`edit-logo-fit-mode-input-${a}`);E.length>0&&D&&E.forEach(R=>{R.addEventListener("change",p=>{if(p.target.checked){D.value=p.target.value,E.forEach(f=>{const C=document.querySelector(`label[for="${f.id}"]`);C&&(f.checked?(C.style.background="var(--dourado-principal, #FFC700)",C.style.color="#000"):(C.style.background="transparent",C.style.color="var(--text, #ECECEC)"))});const m=document.querySelector(`[data-item-id="${a}"]`);if(m){const f=m.querySelector(".item-logo-fit-mode-input");f&&(f.value=p.target.value)}M.updateLivePreviewFromForm()}})})}}function Ce(e){const a=e.item_type;let o="";switch(a){case"whatsapp":case"telegram":case"email":case"facebook":case"instagram":case"pinterest":case"reddit":case"tiktok":case"twitch":case"twitter":case"youtube":case"linkedin":case"portfolio":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título (ex: Meu WhatsApp)">
                </div>
                <div class="input-group">
                    <label>URL de Destino</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://wa.me/5511999999999">
                </div>
            `;break;case"instagram_embed":case"youtube_embed":case"tiktok_embed":case"spotify_embed":case"linkedin_embed":case"pinterest_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Conteúdo">
                </div>
                <div class="input-group">
                    <label>URL do Conteúdo</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="Cole a URL do post ou vídeo">
                </div>
            `;break;case"pix":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título (ex: PIX Celular)">
                </div>
                <div class="input-group">
                    <label>Nome do Recebedor</label>
                    <input type="text" id="edit-recipient-name" value="${e.recipient_name||""}" placeholder="Seu nome completo">
                </div>
                <div class="input-group">
                    <label>Chave PIX (Aleatória, CPF/CNPJ, E-mail ou Telefone)</label>
                    <div class="pix-key-examples">
                        <small><strong>?ož Celular:</strong> Apenas números (ex: +5511999999999)</small>
                        <small><strong>?o§ Email:</strong> seuemail@exemplo.com</small>
                        <small><strong> CPF:</strong> Apenas números (ex: 12345678901)</small>
                        <small><strong>?~ Chave Aleatória:</strong> Copie e cole (ex: 12345678-1234-...)</small>
                    </div>
                    <input type="text" id="edit-pix-key" value="${e.pix_key||""}" placeholder="Ex: +5511999999999 (celular) ou seuemail@exemplo.com">
                </div>
                <div class="input-group">
                    <label>Valor (opcional)</label>
                    <input type="number" id="edit-pix-amount" value="${e.pix_amount||""}" placeholder="Valor em reais" step="0.01">
                </div>
                <div class="input-group">
                    <label>Descrição (opcional)</label>
                    <input type="text" id="edit-pix-description" value="${e.pix_description||""}" placeholder="Descrição do pagamento">
                </div>
            `;break;case"pix_qrcode":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título (ex: Faça um PIX)">
                </div>
                <div class="input-group">
                    <label>Nome do Recebedor</label>
                    <input type="text" id="edit-recipient-name" value="${e.recipient_name||""}" placeholder="Seu nome completo">
                </div>
                <div class="input-group">
                    <label>Chave PIX (Aleatória, CPF/CNPJ, E-mail ou Telefone)</label>
                    <div class="pix-key-examples">
                        <small><strong>?ož Celular:</strong> Apenas números (ex: +5511999999999)</small>
                        <small><strong>?o§ Email:</strong> seuemail@exemplo.com</small>
                        <small><strong> CPF:</strong> Apenas números (ex: 12345678901)</small>
                        <small><strong>?~ Chave Aleatória:</strong> Copie e cole (ex: 12345678-1234-...)</small>
                    </div>
                    <input type="text" id="edit-pix-key" value="${e.pix_key||""}" placeholder="Ex: +5511999999999 (celular) ou seuemail@exemplo.com">
                </div>
                <div class="input-group">
                    <label>Valor (opcional)</label>
                    <input type="number" id="edit-pix-amount" value="${e.pix_amount||""}" placeholder="Valor em reais" step="0.01">
                </div>
                <div class="input-group">
                    <label>Descrição (opcional)</label>
                    <input type="text" id="edit-pix-description" value="${e.pix_description||""}" placeholder="Descrição do pagamento">
                </div>
            `;break;case"wifi":{let c={};try{e.destination_url&&String(e.destination_url).trim().startsWith("{")&&(c=JSON.parse(e.destination_url))}catch{c={}}const de=k=>String(k??"").replace(/&/g,"&amp;").replace(/"/g,"&quot;"),ie=c.display_format==="banner"?"banner":"button",xe=(c.ssid||"").trim(),pe=c.password!=null?String(c.password):"",ue=(c.security||"WPA").toString(),we=!!c.hidden,Q=(c.banner_image_url||"").trim(),ke=(c.logo_url||"").trim(),g=String(c.logo_size||48);o=`
                <div class="input-group">
                    <label>Título no cartão</label>
                    <input type="text" id="edit-title" value="${de(e.title||"Wi-Fi")}" placeholder="Texto do botão (ex: Wi-Fi da loja)">
                </div>
                <div class="input-group">
                    <label>Formato</label>
                    <div style="display: flex; gap: 15px; margin-top: 10px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="radio" class="wifi-display-format-input" name="wifi-modal-df-new" value="button" ${ie==="button"?"checked":""}>
                            <span>Botão</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="radio" class="wifi-display-format-input" name="wifi-modal-df-new" value="banner" ${ie==="banner"?"checked":""}>
                            <span>Banner</span>
                        </label>
                    </div>
                </div>
                <div class="input-group">
                    <label>Nome da rede Wi-Fi (SSID)</label>
                    <small style="display:block;color:#a1a1a1;font-size:0.8rem;margin:4px 0 8px;line-height:1.35;">Obrigatório. Nome que aparece na lista de redes do celular.</small>
                    <input type="text" id="edit-wifi-ssid" value="${de(xe)}" placeholder="Ex: MinhaLoja_WiFi ou Visitantes_5G" maxlength="32">
                </div>
                <div class="input-group">
                    <label>Segurança</label>
                    <select id="edit-wifi-security" style="width:100%;padding:10px;border-radius:8px;">
                        <option value="WPA" ${ue==="WPA"||ue==="WPA2"||ue==="WPA3"?"selected":""}>WPA/WPA2/WPA3</option>
                        <option value="WEP" ${ue==="WEP"?"selected":""}>WEP</option>
                        <option value="nopass" ${ue==="nopass"||ue==="NONE"?"selected":""}>Rede aberta (sem senha)</option>
                    </select>
                </div>
                <div class="input-group">
                    <label>Senha (opcional)</label>
                    <input type="text" id="edit-wifi-password" value="${de(pe)}" placeholder="Deixe vazio se for rede aberta" autocomplete="off">
                </div>
                <div class="input-group">
                    <label style="display:flex;align-items:center;gap:10px;">
                        <input type="checkbox" id="edit-wifi-hidden" ${we?"checked":""}>
                        Rede oculta (SSID não transmitido)
                    </label>
                </div>
                <div class="wifi-modal-logo-section" style="display: ${ie==="banner"?"none":"block"};">
                    <div class="input-group">
                        <label>Tamanho da logo (px)</label>
                        <input type="number" id="edit-wifi-logo-size" value="${de(g)}" min="20" max="600" step="1" style="width: 120px;">
                    </div>
                    <input type="hidden" id="edit-wifi-logo-url" value="${de(ke)}">
                </div>
                <div class="wifi-modal-banner-section" style="display: ${ie==="banner"?"block":"none"};">
                    ${M.wifiBannerUploadBlockHtml(e.id,Q)}
                </div>
            `;break}case"banner":o=`
                <!-- Proporção do Banner: ajustada diretamente na tela de corte ao escolher a imagem -->
                <input type="hidden" name="aspect-ratio-selector" id="edit-banner-aspect-ratio" value="${e.aspect_ratio||"tarja"}">
                <div class="input-group">
                    <label>Imagem do Banner (Clique para escolher e enquadrar)</label>
                    <div class="image-upload-area banner-item" data-item-type="banner" data-item-id="${e.id}">
                        <div class="image-preview">
                            <div class="preview-placeholder" style="display: block;">
                                <i class="fas fa-image"></i>
                                <span>Preview</span>
                            </div>
                            <img id="edit-banner-preview" class="banner-preview" src="" style="max-width: 100%; max-height: 200px; margin-top: 10px; display: none; border-radius: 8px;">
                        </div>
                        <div class="upload-info">
                            <span class="upload-text">Alterar Imagem</span>
                            <small>Enquadre na proporção escolhida</small>
                        </div>
                        <input type="file" class="item-file-input" accept="image/*" data-item-type="banner" data-item-id="${e.id}" style="display: none;">
                    </div>
                </div>
                <input type="hidden" id="edit-image-url" value="">
                <div class="input-group">
                    <label>URL de Destino (para onde o banner leva)</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://exemplo.com">
                </div>
            `;break;case"pdf":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título (ex: Manual do Produto)">
                </div>
                <div class="input-group">
                    <label>URL do PDF</label>
                    <input type="text" id="edit-pdf-url" value="${e.pdf_url||""}" placeholder="https://exemplo.com/arquivo.pdf">
                </div>
            `;break;case"banner_carousel":let L=[];try{e.destination_url&&(L=JSON.parse(e.destination_url))}catch{L=[]}o=`
                <div class="input-group">
                    <label>Proporção do Carrossel</label>
                    <div class="aspect-ratio-control">
                        <input type="radio" name="aspect-ratio-selector" id="ratio-16-9-temp" value="16:9" checked>
                        <label for="ratio-16-9-temp">16:9</label>
                        <input type="radio" name="aspect-ratio-selector" id="ratio-4-3-temp" value="4:3">
                        <label for="ratio-4-3-temp">4:3</label>
                        <input type="radio" name="aspect-ratio-selector" id="ratio-1-1-temp" value="1:1">
                        <label for="ratio-1-1-temp">1:1</label>
                    </div>
                </div>
                <div class="input-group">
                    <label>Fotos do Carrossel <small style="color: #999; font-weight: normal;">(Adicione quantas quiser. As imagens passam automaticamente a cada 3 segundos)</small></label>
                    <div id="carousel-images-list-new-${e.id}" class="carousel-images-list-new" style="min-height: 50px; margin-bottom: 10px; display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px;"></div>
                    <div class="image-upload-area banner-upload-modal" style="margin-top: 10px; position: relative; cursor: pointer;" onclick="document.querySelector('#carousel-input-${e.id}').click();">
                        <input type="file" id="carousel-input-${e.id}" class="item-file-input add-carousel-image-input" data-item-id="${e.id}" accept="image/*" style="position: absolute; width: 100%; height: 100%; opacity: 0; cursor: pointer; z-index: 10; top: 0; left: 0;">
                        <div class="image-upload-text">
                            <p><i class="fas fa-plus"></i> Adicionar Foto</p>
                            <span>Clique para adicionar mais fotos ao carrossel</span>
                        </div>
                        <div class="upload-loader"></div>
                    </div>
                </div>
                <input type="hidden" id="edit-dest-url" class="carousel-images-json-new" data-item-id="${e.id}" value='${JSON.stringify(L)}'>
                <input type="hidden" class="carousel-images-json-new" data-item-id="${e.id}" value='${JSON.stringify(L)}'>
            `,setTimeout(()=>renderCarouselImagesNew(e.id,L),100);break;case"digital_form":o=`
                <div class="input-group">
                    <label>Título do Módulo</label>
                    <input type="text" id="edit-digital-form-title" value="${e.title||"Formulário King"}" placeholder="Formulário King">
                </div>
                <p style="color: #999; font-size: 0.9rem; margin-top: 10px;">
                    <i class="fas fa-info-circle"></i> Configure os campos do formulário após salvar.
                </p>
            `;break;case"guest_list":o=`
                <div class="input-group">
                    <label>Título da Lista</label>
                    <input type="text" id="edit-guest-list-title" value="${e.title||"Lista de Convidados"}" placeholder="Lista de Convidados">
                </div>
                <div class="input-group">
                    <label>Nome do Evento</label>
                    <input type="text" id="edit-event-title" value="${e.event_title||"Evento"}" placeholder="Nome do Evento">
                </div>
                <div class="input-group">
                    <label>Descrição do Evento</label>
                    <textarea id="edit-event-description" rows="3" placeholder="Descrição opcional do evento"></textarea>
                </div>
                <p style="color: #999; font-size: 0.9rem; margin-top: 10px;">
                    <i class="fas fa-info-circle"></i> Configure os detalhes completos após salvar.
                </p>
            `;break;case"agenda":case"contract":case"kingbrief":case"king_bolao":case"photographer_site":o=`
                <div class="input-group">
                    <p style="color:#f87171;font-size:0.95rem;margin:0;">
                        <i class="fas fa-ban"></i> Este módulo foi descontinuado e já não está disponível no Conecta King.
                    </p>
                </div>
            `;break;case"convite":o=`
                <div class="input-group">
                    <label>Título do Módulo</label>
                    <input type="text" id="edit-convite-title" value="${e.title||"Convite"}" placeholder="Convite">
                </div>
                <p style="color: #999; font-size: 0.9rem; margin-top: 10px;">
                    <i class="fas fa-info-circle"></i> Personalize o convite (texto, data, local, fotos) após salvar.
                </p>
            `;break;case"instagram_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Conteúdo">
                </div>
                <div class="input-group">
                    <label>URL do Perfil do Instagram</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://www.instagram.com/p/... ou https://www.instagram.com/seu_usuario/">
                </div>
            `;break;case"youtube_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Conteúdo">
                </div>
                <div class="input-group">
                    <label>URL do Vídeo do YouTube</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://www.youtube.com/watch?v=... ou https://youtu.be/...">
                </div>
            `;break;case"tiktok_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Perfil">
                </div>
                <div class="input-group">
                    <label>URL do Perfil do TikTok</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://www.tiktok.com/@seu_usuario">
                </div>
            `;break;case"spotify_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Perfil">
                </div>
                <div class="input-group">
                    <label>URL do Perfil do Spotify</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://open.spotify.com/user/seu_usuario ou https://open.spotify.com/artist/seu_artista">
                </div>
            `;break;case"linkedin_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Perfil">
                </div>
                <div class="input-group">
                    <label>URL do Perfil do LinkedIn</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://www.linkedin.com/in/seu_perfil">
                </div>
            `;break;case"pinterest_embed":o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título do Perfil">
                </div>
                <div class="input-group">
                    <label>URL do Perfil do Pinterest</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://www.pinterest.com/seu_usuario ou https://br.pinterest.com/seu_usuario">
                </div>
            `;break;default:o=`
                <div class="input-group">
                    <label>Título</label>
                    <input type="text" id="edit-title" value="${e.title||""}" placeholder="Título">
                </div>
                <div class="input-group">
                    <label>URL de Destino</label>
                    <input type="text" id="edit-dest-url" value="${e.destination_url||""}" placeholder="https://exemplo.com">
                </div>
            `}u.editItemModal.dataset.editingId=e.id,u.editItemModal.dataset.isNewItem="true",u.editItemModal.dataset.itemType=a;const P=u.editItemModal.querySelector(".modal-header h4"),ye=typeof window.getItemTypeName=="function"?window.getItemTypeName(a):a;P.textContent=`Configurar ${ye}`,u.editModalBody.innerHTML=o,u.editItemModal.classList.add("active")}var Ae={openEditModal:$e,openEditModalForNewItem:Ce};H.DashboardEditModal=Ae,H.openEditModal=$e,H.openEditModalForNewItem=Ce})(typeof window<"u"?window:void 0);
