/* empty css              */import"./ck-auth-gate-Bp-2Xmps.js";import"./ck-csrf-BWOPNFAq.js";import{Q as j}from"./vendor-qrcode-CZJ2nzDA.js";import"./vendor-leaflet-DLsGkNfG.js";(function(){const S=window.location&&window.location.origin||"",f=window.API_BASE||window.API_URL||S||"https://www.conectaking.com.br";typeof window<"u"&&(window.API_URL=f,window.API_BASE=f);let c=[],E="",h="",L="";const I=new URLSearchParams(window.location.search).get("edit");if(I){const t=document.getElementById("kf-editor-view"),e=document.getElementById("kf-list-view"),n=document.getElementById("kf-editor-frame");t&&e&&n&&(t.classList.add("kf-active"),e.classList.add("kf-hidden"),n.src="/formPageEdit?itemId="+encodeURIComponent(I)+"&v="+Date.now())}function U(){try{return window.CkAuth&&typeof window.CkAuth.lsToken=="function"?window.CkAuth.lsToken()||"":localStorage.getItem("conectaKingToken")||localStorage.getItem("token")||sessionStorage.getItem("conectaKingToken")||sessionStorage.getItem("token")||""}catch{return""}}function D(){try{const t=document.cookie.match(/(?:^|;\s*)ck_csrf=([^;]+)/);return t?decodeURIComponent(t[1]):""}catch{return""}}function w(){const t=U(),e={"Content-Type":"application/json",Accept:"application/json"};t&&(e.Authorization="Bearer "+t);const n=D();return n&&(e["X-CK-CSRF"]=n),e}function m(t){if(!t)return"";const e=document.createElement("div");return e.textContent=t,e.innerHTML}function A(){const t=document.getElementById("kf-list");t&&(t.innerHTML=`
                <div class="kf-empty-state">
                    <i class="fas fa-lock kf-empty-icon"></i>
                    <h3 class="kf-empty-title">Acesso Restrito</h3>
                    <p class="kf-empty-desc">Você precisa estar conectado à sua conta Conecta King para gerenciar o King Forms.</p>
                    <a href="/login?redirect=/kingForms" class="kf-btn-hero-create" style="text-decoration: none;">
                        <i class="fas fa-sign-in-alt"></i> Fazer Login
                    </a>
                </div>
            `);const e=document.getElementById("kf-btn-new");e&&(e.style.display="none")}function T(t){const e=document.getElementById("kf-stat-total-forms"),n=document.getElementById("kf-stat-total-leads"),o=document.getElementById("kf-stat-most-active"),i=t.length;let a=0,r=-1,s="-";t.forEach(y=>{const d=y.digital_form_data||{},u=Number(d.responses_count)||(Array.isArray(d.responses)?d.responses.length:0);a+=u,u>r&&u>0&&(r=u,s=y.title||d.form_title||"Formulário")}),e&&(e.textContent=i),n&&(n.textContent=a),o&&(o.textContent=s,o.title=s)}function p(t){const e=document.getElementById("kf-list"),n=document.getElementById("kf-count-indicator");if(e){if(n&&(n.textContent=t.length===1?"1 formulário disponível":`${t.length} formulários disponíveis`),t.length===0){const o=document.getElementById("kf-search-input")?.value.trim()!=="";e.innerHTML=`
                <div class="kf-empty-state">
                    <i class="fas ${o?"fa-search":"fa-file-signature"} kf-empty-icon"></i>
                    <h3 class="kf-empty-title">${o?"Nenhum formulário encontrado":"Nenhum formulário criado ainda"}</h3>
                    <p class="kf-empty-desc">${o?"Tente buscar com outros termos.":"Crie seu primeiro formulário em poucos segundos e comece a capturar leads."}</p>
                    ${o?"":`
                        <button type="button" class="kf-btn-hero-create" onclick="document.getElementById('kf-btn-new').click();">
                            <i class="fas fa-plus-circle"></i> Criar Meu Primeiro Formulário
                        </button>
                    `}
                </div>
            `;return}e.innerHTML="",t.forEach(o=>{const i=o.digital_form_data||{},a=o.title||i.form_title||"Formulário Sem Título",r=o.is_active!==!1&&o.is_active!=="f",s=Number(i.responses_count)||(Array.isArray(i.responses)?i.responses.length:0),y=i.form_fields||i.fields||[],d=Array.isArray(y)?y.length:i.fields_count||0,u=i.primary_color||"#FFC700",N=i.secondary_color||"#FFA500",Q=`linear-gradient(90deg, ${u} 0%, ${N} 100%)`,H=E?`${window.location.origin}/${E}/form/${o.id}`:`${window.location.origin}/form/${o.id}`,C=document.createElement("div");C.className="kf-form-card",C.setAttribute("data-id",o.id),C.innerHTML=`
                <div class="kf-card-accent-bar" style="background: ${Q};"></div>
                <div class="kf-card-content">
                    <div class="kf-card-header">
                        <div class="kf-card-title-group">
                            <h3 class="kf-card-title-text" title="${m(a)}">${m(a)}</h3>
                            <div class="kf-fields-count">
                                <i class="fas fa-list-check"></i>
                                <span>${d} ${d===1?"campo":"campos"} estruturados</span>
                            </div>
                        </div>
                        <span class="kf-status-pill ${r?"kf-status-active":"kf-status-draft"}">
                            <i class="fas fa-circle" style="font-size: 7px;"></i>
                            ${r?"Ativo":"Rascunho"}
                        </span>
                    </div>

                    <div class="kf-card-meta-row">
                        <a href="/responsesList?itemId=${encodeURIComponent(o.id)}" class="kf-leads-badge" title="Visualizar respostas e leads">
                            <i class="fas fa-inbox"></i>
                            <span>${s} ${s===1?"Resposta":"Respostas"}</span>
                        </a>
                    </div>
                </div>

                <div class="kf-card-footer">
                    <div class="kf-action-group-left">
                        <button type="button" class="kf-btn-icon-action kf-btn-copy-link" data-url="${m(H)}" title="Copiar link público para divulgar">
                            <i class="fas fa-link"></i>
                            <span>Copiar Link</span>
                        </button>
                        <button type="button" class="kf-btn-icon-action kf-btn-qr-trigger" data-url="${m(H)}" data-title="${m(a)}" title="Gerar QR Code deste formulário">
                            <i class="fas fa-qrcode"></i>
                            <span>QR Code</span>
                        </button>
                    </div>

                    <div class="kf-action-group-right">
                        <a href="/kingForms?edit=${encodeURIComponent(o.id)}" class="kf-btn-icon-action kf-btn-edit-primary" title="Editar perguntas e tema">
                            <i class="fas fa-pencil-alt"></i>
                            <span>Editar</span>
                        </a>
                        <button type="button" class="kf-btn-icon-action kf-btn-duplicate" data-id="${encodeURIComponent(o.id)}" title="Duplicar este formulário">
                            <i class="fas fa-copy"></i>
                        </button>
                        <button type="button" class="kf-btn-icon-action kf-btn-delete-item" data-id="${encodeURIComponent(o.id)}" title="Excluir formulário">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            `,e.appendChild(C)})}}async function B(){document.getElementById("kf-list");const t=document.getElementById("kf-empty");if(!(window.CkAuth&&typeof window.CkAuth.requireAuth=="function"&&!await window.CkAuth.requireAuth("/login")))try{const e=await fetch(f+"/api/profile",{credentials:"include",headers:w()});if(e.status===401){A();return}const n=await e.json();if(!n||n.success===!1){t&&(t.textContent="Erro ao carregar dados. Faça login novamente.");return}E=n.details&&(n.details.slug||n.details.profile_slug)||"",c=n&&n.items&&Array.isArray(n.items)?n.items.filter(o=>o.item_type==="digital_form"):[],T(c),p(c)}catch{t&&(t.textContent="Falha ao sincronizar formulários. Tente recarregar a página.")}}const k=document.getElementById("kf-search-input"),b=document.getElementById("kf-search-clear");k&&k.addEventListener("input",function(){const t=this.value.toLowerCase().trim();if(b&&(b.style.display=t?"block":"none"),!t){p(c);return}const e=c.filter(n=>{const o=(n.title||n.digital_form_data?.form_title||"").toLowerCase(),i=(n.digital_form_data?.description||"").toLowerCase();return o.includes(t)||i.includes(t)});p(e)}),b&&b.addEventListener("click",function(){k&&(k.value="",k.focus()),this.style.display="none",p(c)});const _=document.getElementById("kf-btn-new");_&&_.addEventListener("click",async function(){if(window.CkAuth&&typeof window.CkAuth.requireAuth=="function"&&!await window.CkAuth.requireAuth("/login"))return;const t=this;t.disabled=!0,t.innerHTML='<i class="fas fa-spinner fa-spin"></i> Criando...';try{const e=await fetch(f+"/api/profile/items",{method:"POST",credentials:"include",headers:w(),body:JSON.stringify({item_type:"digital_form",title:"Formulário Sem Título",is_active:!0,display_order:999})});if(e.status===401){A();return}const n=await e.json();n&&n.id?window.location.href="/kingForms?edit="+encodeURIComponent(n.id):alert(n?.message||"Erro ao criar novo formulário.")}catch{alert("Erro na requisição ao criar formulário.")}finally{t.disabled=!1,t.innerHTML='<i class="fas fa-plus"></i> <span>Criar Novo Formulário</span>'}});const F=document.getElementById("kf-list-view");F&&F.addEventListener("click",async function(t){const e=t.target.closest(".kf-btn-copy-link");if(e){t.preventDefault();const a=e.getAttribute("data-url");if(a)try{await navigator.clipboard.writeText(a);const r=e.innerHTML;e.innerHTML='<i class="fas fa-check" style="color: #10B981;"></i> <span style="color: #10B981;">Copiado!</span>',setTimeout(()=>{e.innerHTML=r},2e3)}catch{alert("Link: "+a)}return}const n=t.target.closest(".kf-btn-qr-trigger");if(n){t.preventDefault();const a=n.getAttribute("data-url")||"",r=n.getAttribute("data-title")||"Formulário";P(a,r);return}const o=t.target.closest(".kf-btn-duplicate");if(o){t.preventDefault();const a=o.getAttribute("data-id");if(!a)return;o.disabled=!0,o.innerHTML='<i class="fas fa-spinner fa-spin"></i>';try{const r=await fetch(f+"/api/profile/items/"+encodeURIComponent(a)+"/duplicate",{method:"POST",credentials:"include",headers:w()});if(r.ok)await B();else{const s=await r.json().catch(()=>({}));alert(s.message||"Erro ao duplicar formulário.")}}catch{alert("Falha na comunicação ao duplicar formulário.")}finally{o.disabled=!1,o.innerHTML='<i class="fas fa-copy"></i>'}return}const i=t.target.closest(".kf-btn-delete-item");if(i){t.preventDefault();const a=i.getAttribute("data-id");if(!a||!confirm("Tem certeza que deseja apagar este formulário? Todas as respostas recebidas serão apagadas."))return;i.disabled=!0,i.innerHTML='<i class="fas fa-spinner fa-spin"></i>';try{const r=await fetch(f+"/api/profile/items/"+encodeURIComponent(a),{method:"DELETE",credentials:"include",headers:w()});if(r.ok)c=c.filter(s=>String(s.id)!==String(a)),T(c),p(c);else{const s=await r.json().catch(()=>({}));alert(s.message||"Erro ao apagar formulário."),i.disabled=!1,i.innerHTML='<i class="fas fa-trash-alt"></i>'}}catch{alert("Erro de conexão ao excluir formulário."),i.disabled=!1,i.innerHTML='<i class="fas fa-trash-alt"></i>'}return}});const l=document.getElementById("kf-qr-modal"),$=document.getElementById("kf-qr-modal-close"),v=document.getElementById("kf-qr-copy-btn"),q=document.getElementById("kf-qr-download-btn"),g=document.getElementById("kf-qr-canvas-box"),R=document.getElementById("kf-qr-form-title"),M=document.getElementById("kf-qr-link-input");function P(t,e){if(!l||!g)return;h=t,L=e,R&&(R.textContent=e),M&&(M.value=t),g.innerHTML="";const n=document.createElement("canvas");g.appendChild(n),j.toCanvas(n,t,{width:240,margin:2,color:{dark:"#000000",light:"#FFFFFF"}},function(o){}),l.style.display="flex"}function x(){l&&(l.style.display="none")}$&&$.addEventListener("click",x),l&&l.addEventListener("click",function(t){t.target===l&&x()}),v&&v.addEventListener("click",async function(){if(h)try{await navigator.clipboard.writeText(h),v.innerHTML='<i class="fas fa-check"></i> Copiado!',setTimeout(()=>{v.innerHTML='<i class="fas fa-copy"></i> <span>Copiar Link</span>'},2e3)}catch{alert("Link: "+h)}}),q&&q.addEventListener("click",function(){const t=g?g.querySelector("canvas"):null;if(!t)return;const e=document.createElement("a");e.download=`qrcode_${(L||"formulario").toLowerCase().replace(/[^a-z0-9]/g,"_")}.png`,e.href=t.toDataURL("image/png"),e.click()}),B()})();
