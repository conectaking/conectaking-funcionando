document.addEventListener("DOMContentLoaded",()=>{const o={appointments:[],services:[],professionals:[],settings:null,currentFilter:"today",profileSlug:""},_=document.querySelectorAll(".tab-btn"),C=document.querySelectorAll(".tab-pane"),T=document.getElementById("badgeCountAppointments"),p=document.getElementById("appointmentsGrid"),I=document.getElementById("servicesGrid"),g=document.getElementById("professionalsGrid"),w=document.getElementById("workingHoursContainer"),B=document.getElementById("formSettings"),$=document.getElementById("btnNewService"),m=document.getElementById("modalService"),b=document.getElementById("formServiceModal"),L=document.getElementById("modalServiceTitle"),S=document.getElementById("btnNewProf"),f=document.getElementById("modalProf"),v=document.getElementById("formProfModal");document.getElementById("modalProfTitle");const x=document.getElementById("btnCopyPublicLink"),D=document.getElementById("btnOpenPublicLink"),k=document.getElementById("copyLinkText"),y=document.querySelectorAll(".filter-btn"),r=document.getElementById("filterSpecificDate");_.forEach(e=>{e.addEventListener("click",()=>{const t=e.getAttribute("data-tab");_.forEach(n=>{n.classList.remove("active","text-white"),n.classList.add("text-slate-400")}),e.classList.add("active","text-white"),e.classList.remove("text-slate-400"),C.forEach(n=>{n.classList.toggle("hidden",n.id!==t)})})}),document.querySelectorAll(".btnCloseModal").forEach(e=>{e.addEventListener("click",()=>{m.classList.add("hidden"),f.classList.add("hidden")})}),y.forEach(e=>{e.addEventListener("click",()=>{y.forEach(t=>{t.classList.remove("active","bg-amber-500","text-slate-950"),t.classList.add("bg-slate-800","text-slate-300")}),e.classList.add("active","bg-amber-500","text-slate-950"),e.classList.remove("bg-slate-800","text-slate-300"),o.currentFilter=e.getAttribute("data-filter"),r.value="",h()})}),r&&r.addEventListener("change",e=>{e.target.value&&(y.forEach(t=>{t.classList.remove("active","bg-amber-500","text-slate-950"),t.classList.add("bg-slate-800","text-slate-300")}),o.currentFilter="specific",h())});async function d(){try{const[e,t,n,a]=await Promise.all([fetch("/api/booking/settings"),fetch("/api/booking/services"),fetch("/api/booking/professionals"),fetch("/api/booking/appointments")]);o.settings=await e.json(),o.services=await t.json(),o.professionals=await n.json(),o.appointments=await a.json(),fetch("/api/user/profile-core").then(s=>s.json()).then(s=>{const i=s.profile?.profile_slug||s.user?.profile_slug||"";if(o.profileSlug=i,i){const l=`/${i}/agendar`;D.href=l,x.classList.remove("hidden")}}).catch(()=>{}),j(),P(),A(),h()}catch{}}x&&x.addEventListener("click",()=>{if(!o.profileSlug)return;const e=`${window.location.origin}/${o.profileSlug}/agendar`;navigator.clipboard.writeText(e).then(()=>{k.textContent="Link Copiado!",setTimeout(()=>{k.textContent="Copiar Link de Agendamento"},2e3)})});function h(){const e=new Date().toISOString().split("T")[0],t=new Date;t.setDate(t.getDate()+1);const n=t.toISOString().split("T")[0];let a=o.appointments;if(o.currentFilter==="today"?a=a.filter(s=>s.appointment_date===e):o.currentFilter==="tomorrow"?a=a.filter(s=>s.appointment_date===n):o.currentFilter==="specific"&&r.value&&(a=a.filter(s=>s.appointment_date===r.value)),T.textContent=a.length,p.innerHTML="",a.length===0){p.innerHTML=`
                <div class="col-span-full text-center py-12 text-slate-500 bg-slate-900/40 border border-slate-800/80 rounded-3xl">
                    <i class="far fa-calendar-check text-4xl mb-2 text-slate-600 block"></i>
                    <p class="text-sm font-semibold">Nenhum agendamento encontrado para este filtro.</p>
                </div>
            `;return}a.forEach(s=>{const i=s.appointment_date.split("-"),l=`${i[2]}/${i[1]}/${i[0]}`,M=s.start_time.substring(0,5),F=s.end_time.substring(0,5);let c="";s.status==="confirmed"?c='<span class="px-2.5 py-1 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-bold">Confirmado</span>':s.status==="pending"?c='<span class="px-2.5 py-1 bg-amber-500/15 text-amber-400 border border-amber-500/30 rounded-lg text-[10px] font-bold">Pendente</span>':s.status==="completed"?c='<span class="px-2.5 py-1 bg-blue-500/15 text-blue-400 border border-blue-500/30 rounded-lg text-[10px] font-bold">Concluído</span>':c='<span class="px-2.5 py-1 bg-red-500/15 text-red-400 border border-red-500/30 rounded-lg text-[10px] font-bold">Cancelado</span>';const u=s.client_phone.replace(/\D/g,""),O=u.length<=11&&!u.startsWith("55")?`55${u}`:u,H=encodeURIComponent(`Olá ${s.client_name}! Confirmando seu horário para ${s.service_name} no dia ${l} às ${M}.`),E=document.createElement("div");E.className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3 relative hover:border-slate-700 transition",E.innerHTML=`
                <div class="flex items-start justify-between gap-2">
                    <div>
                        <div class="text-base font-bold text-white">${s.client_name}</div>
                        <div class="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                            <i class="fas fa-scissors text-amber-400"></i>
                            <span>${s.service_name}</span>
                        </div>
                    </div>
                    ${c}
                </div>

                <div class="bg-slate-950/60 p-2.5 rounded-xl text-xs space-y-1">
                    <div class="flex items-center justify-between text-slate-300">
                        <span><i class="far fa-calendar text-amber-400 mr-1"></i> ${l}</span>
                        <span class="font-bold text-white"><i class="far fa-clock text-amber-400 mr-1"></i> ${M} - ${F}</span>
                    </div>
                    <div class="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-800/80">
                        <span>Valor:</span>
                        <span class="font-bold text-amber-400">R$ ${parseFloat(s.price).toLocaleString("pt-BR",{minimumFractionDigits:2})}</span>
                    </div>
                </div>

                ${s.notes?`<div class="text-[11px] text-slate-400 italic bg-slate-950/30 p-2 rounded-lg">Obs: ${s.notes}</div>`:""}

                <div class="flex items-center gap-1.5 pt-1">
                    <a href="https://wa.me/${O}?text=${H}" target="_blank" class="flex-1 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-600/30 font-bold rounded-xl text-xs text-center transition flex items-center justify-center gap-1">
                        <i class="fab fa-whatsapp"></i>
                        <span>WhatsApp</span>
                    </a>

                    ${s.status!=="completed"&&s.status!=="cancelled"?`
                        <button type="button" class="btnUpdateStatus px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold" data-id="${s.id}" data-status="completed" title="Marcar como Concluído">
                            <i class="fas fa-check text-emerald-400"></i>
                        </button>
                        <button type="button" class="btnUpdateStatus px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold" data-id="${s.id}" data-status="cancelled" title="Cancelar Agendamento">
                            <i class="fas fa-ban text-red-400"></i>
                        </button>
                    `:""}
                </div>
            `,p.appendChild(E)}),document.querySelectorAll(".btnUpdateStatus").forEach(s=>{s.addEventListener("click",async()=>{const i=s.getAttribute("data-id"),l=s.getAttribute("data-status");confirm(`Deseja alterar o status para "${l}"?`)&&(await fetch(`/api/booking/appointments/${i}/status`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:l})}),d())})})}function P(){I.innerHTML="",o.services.forEach(e=>{const t=document.createElement("div");t.className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3 relative hover:border-slate-700 transition",t.innerHTML=`
                <div class="flex items-start justify-between gap-2">
                    <div>
                        <h3 class="font-bold text-white text-base">${e.name}</h3>
                        <p class="text-xs text-slate-400 mt-0.5">${e.description||"Sem descrição"}</p>
                    </div>
                    <span class="text-sm font-extrabold text-amber-400">R$ ${parseFloat(e.price).toLocaleString("pt-BR",{minimumFractionDigits:2})}</span>
                </div>
                <div class="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                    <span class="flex items-center gap-1"><i class="far fa-clock text-amber-400"></i> ${e.duration_minutes} min</span>
                    <div class="flex gap-1.5">
                        <button type="button" class="btnEditService px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs" data-id="${e.id}"><i class="fas fa-pen"></i></button>
                        <button type="button" class="btnDeleteService px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs" data-id="${e.id}"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            `,I.appendChild(t)}),document.querySelectorAll(".btnEditService").forEach(e=>{e.addEventListener("click",()=>{const t=parseInt(e.getAttribute("data-id"),10),n=o.services.find(a=>a.id===t);n&&(L.textContent="Editar Serviço",document.getElementById("serviceModalId").value=n.id,document.getElementById("serviceModalName").value=n.name,document.getElementById("serviceModalDuration").value=n.duration_minutes,document.getElementById("serviceModalPrice").value=n.price,document.getElementById("serviceModalDesc").value=n.description||"",document.getElementById("serviceModalActive").checked=n.is_active,m.classList.remove("hidden"))})}),document.querySelectorAll(".btnDeleteService").forEach(e=>{e.addEventListener("click",async()=>{const t=e.getAttribute("data-id");confirm("Tem certeza que deseja excluir este serviço?")&&(await fetch(`/api/booking/services/${t}`,{method:"DELETE"}),d())})})}$&&$.addEventListener("click",()=>{L.textContent="Novo Serviço",b.reset(),document.getElementById("serviceModalId").value="",m.classList.remove("hidden")}),b&&b.addEventListener("submit",async e=>{e.preventDefault();const t=document.getElementById("serviceModalId").value,n={name:document.getElementById("serviceModalName").value,duration_minutes:parseInt(document.getElementById("serviceModalDuration").value,10),price:parseFloat(document.getElementById("serviceModalPrice").value),description:document.getElementById("serviceModalDesc").value,is_active:document.getElementById("serviceModalActive").checked},a=t?`/api/booking/services/${t}`:"/api/booking/services";await fetch(a,{method:t?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)}),m.classList.add("hidden"),d()});function A(){if(g.innerHTML="",o.professionals.length===0){g.innerHTML=`
                <div class="col-span-full text-center py-8 text-slate-500 bg-slate-900/40 border border-slate-800 rounded-2xl">
                    <p class="text-xs">Nenhum profissional cadastrado. A agenda funcionará no nome principal do estabelecimento.</p>
                </div>
            `;return}o.professionals.forEach(e=>{const t=document.createElement("div");t.className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3",t.innerHTML=`
                <div class="flex items-center gap-3">
                    <img src="${e.avatar_url||"https://i.ibb.co/60sW9k75/logo.png"}" class="w-10 h-10 rounded-full object-cover ring-1 ring-slate-700">
                    <div>
                        <div class="font-bold text-white text-sm">${e.name}</div>
                        <div class="text-xs text-slate-400">${e.phone||"Sem telefone"}</div>
                    </div>
                </div>
                <button type="button" class="btnDeleteProf px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs" data-id="${e.id}"><i class="fas fa-trash"></i></button>
            `,g.appendChild(t)}),document.querySelectorAll(".btnDeleteProf").forEach(e=>{e.addEventListener("click",async()=>{const t=e.getAttribute("data-id");confirm("Excluir este profissional?")&&(await fetch(`/api/booking/professionals/${t}`,{method:"DELETE"}),d())})})}S&&S.addEventListener("click",()=>{v.reset(),document.getElementById("profModalId").value="",f.classList.remove("hidden")}),v&&v.addEventListener("submit",async e=>{e.preventDefault();const t={name:document.getElementById("profModalName").value,phone:document.getElementById("profModalPhone").value,avatar_url:document.getElementById("profModalAvatar").value};await fetch("/api/booking/professionals",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t)}),f.classList.add("hidden"),d()});const N=["Domingo","Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado"];function j(){if(!o.settings)return;document.getElementById("cfgBusinessName").value=o.settings.business_name||"",document.getElementById("cfgBusinessPhone").value=o.settings.business_phone||"",document.getElementById("cfgBusinessAddress").value=o.settings.business_address||"",document.getElementById("cfgSlotInterval").value=o.settings.slot_interval_minutes||30,document.getElementById("cfgMinNotice").value=o.settings.min_notice_hours||1,document.getElementById("cfgMaxDays").value=o.settings.max_days_advance||30;const e=o.settings.working_hours||{};w.innerHTML="";for(let t=0;t<7;t++){const n=e[t]||{enabled:t!==0,start:"09:00",end:"18:00",break_start:"12:00",break_end:"13:00"},a=document.createElement("div");a.className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-center p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs",a.innerHTML=`
                <div class="flex items-center gap-2 sm:col-span-2">
                    <input type="checkbox" id="wh_enabled_${t}" ${n.enabled?"checked":""} class="wh-toggle rounded border-slate-800 text-amber-500 focus:ring-amber-500">
                    <label for="wh_enabled_${t}" class="font-bold text-slate-200">${N[t]}</label>
                </div>
                <div>
                    <label class="block text-[10px] text-slate-400">Início</label>
                    <input type="time" id="wh_start_${t}" value="${n.start||"09:00"}" class="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-white">
                </div>
                <div>
                    <label class="block text-[10px] text-slate-400">Fim</label>
                    <input type="time" id="wh_end_${t}" value="${n.end||"18:00"}" class="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-white">
                </div>
                <div>
                    <label class="block text-[10px] text-slate-400">Almoço (Início/Fim)</label>
                    <div class="flex gap-1">
                        <input type="time" id="wh_bstart_${t}" value="${n.break_start||"12:00"}" class="w-1/2 bg-slate-900 border border-slate-800 rounded-lg px-1 py-1 text-white text-[10px]">
                        <input type="time" id="wh_bend_${t}" value="${n.break_end||"13:00"}" class="w-1/2 bg-slate-900 border border-slate-800 rounded-lg px-1 py-1 text-white text-[10px]">
                    </div>
                </div>
            `,w.appendChild(a)}}B&&B.addEventListener("submit",async e=>{e.preventDefault();const t={};for(let a=0;a<7;a++)t[a]={enabled:document.getElementById(`wh_enabled_${a}`).checked,start:document.getElementById(`wh_start_${a}`).value,end:document.getElementById(`wh_end_${a}`).value,break_start:document.getElementById(`wh_bstart_${a}`).value,break_end:document.getElementById(`wh_bend_${a}`).value};const n={business_name:document.getElementById("cfgBusinessName").value,business_phone:document.getElementById("cfgBusinessPhone").value,business_address:document.getElementById("cfgBusinessAddress").value,slot_interval_minutes:parseInt(document.getElementById("cfgSlotInterval").value,10),min_notice_hours:parseInt(document.getElementById("cfgMinNotice").value,10),max_days_advance:parseInt(document.getElementById("cfgMaxDays").value,10),working_hours:t};await fetch("/api/booking/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)}),alert("Configurações salvas com sucesso!"),d()}),d()});
