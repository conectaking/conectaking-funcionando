import"./planRenderer-nIQO_l40.js";let p=window.location.origin;if(p.includes("127.0.0.1:5500")||p.includes("localhost:5500")){const a=window.location.protocol,o=window.location.hostname;p=`${a}//${o}:8080`}p=String(p||window.location.origin).replace(/\/$/,"");window.API_URL=p;window.CONTACT_WHATSAPP_NUMBER=window.CONTACT_WHATSAPP_NUMBER||"5511988161364";function k(a){const o=a,e=a*1.2,i=e/12,n=a/12*1.25;return{pix:o,card:e,cardPerMonth:i,monthly:n}}async function _(a){try{if(!a)return{available:[],unavailable:[]};const o=await fetch(`${p}/api/modules/plan-availability-public`);if(!o.ok)return{available:[],unavailable:[]};const i=(await o.json()).modules||[],n={carousel:"Carrossel",sales_page:"Loja Virtual",digital_form:"King Forms",portfolio:"Portfólio",banner:"Banner",finance:"Gestão Financeira",contract:"Contratos",agenda:"Agenda Inteligente"},r=[],s=[];return Object.keys(n).forEach(c=>{const d=i.find(f=>f.module_type===c);d&&d.plans&&d.plans[a]?.is_available===!0?r.push(n[c]):s.push(n[c])}),{available:r,unavailable:s}}catch{return{available:[],unavailable:[]}}}async function S(){if(!(document.getElementById("exclusive-packages-container")||document.querySelector('[data-static-packages="true"]')))try{const a=new AbortController,o=setTimeout(()=>a.abort(),5e3),e=await fetch(`${p}/api/subscription/plans-public`,{method:"GET",headers:{"Content-Type":"application/json",Accept:"application/json"},cache:"no-cache",signal:a.signal});if(clearTimeout(o),!e.ok){const n=await e.text();throw new Error(`HTTP ${e.status}: ${n}`)}const i=await e.json();if(i.success&&i.plans&&i.plans.length>0){const n=i.plans.filter(r=>r.plan_code!=="king_base");if(typeof window.renderPlansShared=="function")await window.renderPlansShared(n,"plans-container",!1);else{const r=await Promise.all(n.map(async s=>{const c=await _(s.plan_code);return{...s,modules:c}}));I(r)}w()}else document.getElementById("plans-container").innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: rgba(245, 245, 245, 0.7);">Nenhum plano disponível no momento.</p>'}catch(a){let o="Erro ao carregar planos. ",e="";a.name==="TimeoutError"||a.message.includes("Failed to fetch")||a.message.includes("NetworkError")?(o="Não foi possível conectar ao servidor.",e=`
                        <div style="margin-top: 20px; padding: 20px; background: rgba(255, 199, 0, 0.1); border: 1px solid var(--yellow-primary); border-radius: 8px; text-align: left;">
                            <p style="color: var(--yellow-primary); font-weight: 600; margin-bottom: 12px;">
                                <i class="fas fa-info-circle"></i> Para visualizar os planos:
                            </p>
                            <ol style="color: rgba(245, 245, 245, 0.9); line-height: 1.8; padding-left: 20px;">
                                <li>Abra um terminal na pasta do projeto</li>
                                <li>Execute: <code style="background: rgba(0,0,0,0.3); padding: 4px 8px; border-radius: 4px;">docker compose up</code></li>
                                <li>Aguarde o health em <code style="background: rgba(0,0,0,0.3); padding: 4px 8px; border-radius: 4px;">http://localhost:8080/health</code></li>
                                <li>Recarregue esta página</li>
                            </ol>
                            <p style="color: rgba(245, 245, 245, 0.7); font-size: 0.9rem; margin-top: 12px;">
                                <strong>URL da API tentada:</strong> ${p}/api/subscription/plans-public
                            </p>
                </div>
                    `):a.message.includes("404")?(o="Servidor não encontrado.",e='<p style="color: rgba(245, 245, 245, 0.7); margin-top: 12px;">Certifique-se de que o Laravel está a correr em <code>http://localhost:8080</code>.</p>'):o+="Por favor, recarregue a página.",document.getElementById("plans-container").innerHTML=`
                    <div style="text-align: center; grid-column: 1 / -1; padding: 40px; background: rgba(220, 38, 38, 0.1); border: 2px solid #DC2626; border-radius: 12px;">
                        <p style="color: #DC2626; font-size: 1.1rem; margin-bottom: 12px;">
                            <i class="fas fa-exclamation-triangle"></i> ${o}
                        </p>
                        ${e}
                        <button onclick="loadPlans()" class="btn btn-primary" style="margin-top: 20px; padding: 12px 24px; background: var(--yellow-primary); color: var(--black-absolute); border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                            <i class="fas fa-sync-alt"></i> Tentar Novamente
                        </button>
                    </div>
                `}}async function I(a){if(typeof window.renderPlansShared=="function"){await window.renderPlansShared(a,"plans-container",!1);return}const o=document.getElementById("plans-container");if(a.length===0){o.innerHTML='<p style="text-align: center; grid-column: 1 / -1;">Nenhum plano disponível no momento.</p>';return}o.innerHTML=a.map(e=>{const i=e.features||{},n=e.modules||{available:[],unavailable:[]},r=parseFloat(e.price),s=k(r),c=e.plan_code==="basic",d=e.plan_code==="premium",f=e.plan_code==="king_base",y=e.plan_code==="king_finance",b=e.plan_code==="king_finance_plus",g=e.plan_code==="king_premium_plus",h=e.plan_code==="enterprise"||e.plan_code==="king_corporate",x=d;let t="Começar agora",l=`Olá! Gostaria de adquirir o plano ${e.plan_name} do ConectaKing!`;c?(t="Começar agora",l="Olá! Gostaria de adquirir o plano King Start do ConectaKing!"):d?(t="Quero o Prime",l="Olá! Gostaria de adquirir o plano King Prime do ConectaKing!"):f?(t="Quero o Essential",l="Olá! Gostaria de adquirir o plano King Essential do ConectaKing!"):y?(t="Quero o Finance",l="Olá! Gostaria de adquirir o plano King Finance do ConectaKing!"):b?(t="Quero o Finance Plus",l="Olá! Gostaria de adquirir o plano King Finance Plus do ConectaKing!"):g?(t="Quero o Premium Plus",l="Olá! Gostaria de adquirir o plano King Premium Plus do ConectaKing!"):h?(t="Ativar modo empresa",l="Olá! Gostaria de adquirir o plano King Corporate do ConectaKing!"):(t=`Quero o ${e.plan_name}`,l=`Olá! Gostaria de adquirir o plano ${e.plan_name} do ConectaKing!`);const m=e.whatsapp_message||l,P=e.whatsapp_number||"5511999999999";return`
                    <div class="pricing-card ${x?"featured":""} fade-in">
                        <div class="plan-name">${e.plan_name}</div>
                        <div class="plan-price-section">
                            <div class="plan-price-main">
                                <span class="currency">R$</span>${r.toFixed(2).replace(".",",")}
                            </div>
                            <div class="payment-options">
                                <div class="payment-option">
                                    <span><strong>PIX:</strong> à vista</span>
                                    <span class="value">R$ ${s.pix.toFixed(2).replace(".",",")}</span>
                                </div>
                                <div class="payment-option">
                                    <span><strong>Cartão:</strong> Até 12x</span>
                                    <span class="value">R$ ${s.cardPerMonth.toFixed(2).replace(".",",")}/m</span>
                                </div>
                                <div class="payment-option">
                                    <span><strong>Mensal:</strong> Recorrente</span>
                                    <span class="value">R$ ${s.monthly.toFixed(2).replace(".",",")}/m</span>
                                </div>
                            </div>
                        </div>
                        <p class="plan-description">${e.description||""}</p>
                        <ul class="plan-features">
                            ${i.can_edit_logo?'<li><i class="fas fa-check"></i> Logomarca editável</li>':'<li><i class="fas fa-times" style="color: rgba(245, 245, 245, 0.4);"></i> Logomarca não editável</li>'}
                            ${i.max_profiles?`<li><i class="fas fa-check"></i> ${i.max_profiles} perfil(is)</li>`:""}
                            ${i.is_enterprise?'<li><i class="fas fa-check"></i> Modo Empresarial</li>':""}
                            
                            ${c?`
                            <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255, 199, 0, 0.2);">
                                <strong style="color: var(--yellow-primary); font-size: 0.95rem;">• Você tem acesso a todos os módulos, menos estes que estão abaixo:</strong>
                            </li>
                            <li style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255, 199, 0, 0.1);">
                                <strong style="color: rgba(245, 245, 245, 0.6); font-size: 0.9rem;">• Não Incluído:</strong>
                            </li>
                            ${i.can_edit_logo?"":'<li style="padding-left: 8px; opacity: 0.6;"><i class="fas fa-times" style="color: rgba(245, 245, 245, 0.4); margin-right: 8px;"></i> Logomarca editável</li>'}
                            ${n.unavailable.map(u=>`<li style="padding-left: 8px; opacity: 0.6;"><i class="fas fa-times" style="color: rgba(245, 245, 245, 0.4); margin-right: 8px;"></i> ${u}</li>`).join("")}
                            <li style="padding-left: 8px; opacity: 0.8; margin-top: 8px; color: var(--yellow-primary);">
                                <i class="fas fa-gift" style="color: var(--yellow-primary); margin-right: 8px;"></i> <strong>Bônus:</strong> Link Personalizado
                            </li>
                            `:""}
                            
                            ${d&&n.available.length>0?`
                            <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255, 199, 0, 0.2);">
                                <strong style="color: var(--yellow-primary); font-size: 0.9rem;">• Módulos Incluídos:</strong>
                            </li>
                            ${n.available.map(u=>`<li style="padding-left: 8px;"><i class="fas fa-check" style="color: var(--yellow-primary); margin-right: 8px;"></i> ${u}</li>`).join("")}
                            <li style="padding-left: 8px;"><i class="fas fa-check" style="color: var(--yellow-primary); margin-right: 8px;"></i> Link Personalizado</li>
                            `:""}
                            
                            ${h?`
                            <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255, 199, 0, 0.2);">
                                <strong style="color: var(--yellow-primary); font-size: 0.9rem;">• Todos os Módulos Disponíveis:</strong>
                            </li>
                            ${n.available.length>0?n.available.map(u=>`<li style="padding-left: 8px;"><i class="fas fa-check" style="color: var(--yellow-primary); margin-right: 8px;"></i> ${u}</li>`).join(""):""}
                            <li style="padding-left: 8px;"><i class="fas fa-check" style="color: var(--yellow-primary); margin-right: 8px;"></i> Link Personalizado</li>
                            <li style="padding-left: 8px; margin-top: 4px; font-size: 0.9rem; color: rgba(245, 245, 245, 0.6);">
                                <i class="fas fa-check" style="color: var(--yellow-primary); margin-right: 8px;"></i> E todos os outros módulos
                            </li>
                            `:""}
                    </ul>
                    <a href="https://wa.me/${P.replace(/\D/g,"")}?text=${encodeURIComponent(m)}" target="_blank" class="btn btn-primary" style="width: 100%; margin-top: 20px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        <i class="fab fa-whatsapp"></i> ${t}
                    </a>
                </div>
                `}).join(""),w()}var $=new IntersectionObserver(function(a){a.forEach(function(o){o.isIntersecting&&o.target.classList.add("visible")})},{threshold:.08,rootMargin:"0px 0px -20px 0px"});function w(){document.querySelectorAll(".fade-in").forEach(function(a){$.observe(a)})}w();document.querySelectorAll(".faq-question").forEach(a=>{a.addEventListener("click",()=>{const o=a.closest(".faq-item"),e=o.querySelector(".faq-answer"),i=a.querySelector("i"),n=o.classList.contains("active");document.querySelectorAll(".faq-item").forEach(r=>{r.classList.remove("active"),r.querySelector(".faq-answer").style.maxHeight="0",r.querySelector(".faq-question i").style.transform="rotate(0deg)"}),n||(o.classList.add("active"),e.style.maxHeight=e.scrollHeight+"px",i.style.transform="rotate(180deg)")})});window.addEventListener("beforeinstallprompt",function(a){a.preventDefault();var o=document.getElementById("android-install-label");o&&(o.textContent="Instalar agora (1 toque)")});"serviceWorker"in navigator&&navigator.serviceWorker.getRegistrations().then(function(a){a.forEach(function(o){o.unregister()})}).catch(function(){});S();const v=document.getElementById("cta-fixed-mobile");if(v){let a=0;window.addEventListener("scroll",()=>{const o=window.pageYOffset;window.innerWidth<=768?o>300&&o<a?v.style.display="block":o<100&&(v.style.display="none"):v.style.display="none",a=o})}(function(){const a=document.getElementById("login-btn"),o=document.getElementById("access-panel-btn"),e=document.getElementById("landing-sair-btn"),i=document.getElementById("create-account-btn"),n=document.getElementById("footer-login-item"),r=document.getElementById("footer-access-panel-item");let s=null;try{const t=localStorage.getItem("conectaKingUser");t&&t!=="null"&&t!=="undefined"&&(s=JSON.parse(t))}catch{}const c=localStorage.getItem("conectaKingSession"),d=localStorage.getItem("conectaKingToken")||localStorage.getItem("token"),y=!!(s&&typeof s=="object"&&(s.id||s.email))&&(c==="1"||!!d||!!s.account_type||!!s.accountType);function b(){["conectaKingToken","conectaKingUser","token","refreshToken","user","dashboard_last_pane","conectaKingSession"].forEach(function(t){try{localStorage.removeItem(t)}catch{}try{sessionStorage.removeItem(t)}catch{}})}function g(t){t?(a&&(a.classList.add("ck-hidden"),a.style.setProperty("display","none","important")),i&&(i.classList.add("ck-hidden"),i.style.setProperty("display","none","important")),e&&(e.classList.remove("ck-hidden"),e.classList.remove("ck-ix-9656c9"),e.style.setProperty("display","inline-flex","important")),o&&(o.classList.remove("ck-hidden"),o.style.setProperty("display","inline-flex","important")),n&&(n.classList.add("ck-hidden"),n.style.setProperty("display","none","important")),r&&(r.classList.remove("ck-hidden"),r.style.setProperty("display","block","important"))):(a&&(a.classList.remove("ck-hidden"),a.style.setProperty("display","inline-flex","important")),i&&(i.classList.remove("ck-hidden"),i.style.setProperty("display","inline-flex","important")),e&&(e.classList.add("ck-hidden"),e.style.setProperty("display","none","important")),o&&(o.classList.add("ck-hidden"),o.style.setProperty("display","none","important")),n&&(n.classList.remove("ck-hidden"),n.style.setProperty("display","block","important")),r&&(r.classList.add("ck-hidden"),r.style.setProperty("display","none","important")))}function h(){if(!window.confirm("Sair desta conta? Pode entrar com outro utilizador em seguida."))return;var t=null;try{t=localStorage.getItem("refreshToken")||sessionStorage.getItem("refreshToken")}catch{}var l=String(window.API_URL||window.API_BASE||window.location.origin).replace(/\/$/,"");function m(){b(),window.location.reload()}t?fetch(l+"/api/auth/logout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({refreshToken:t}),credentials:"include"}).catch(function(){}).finally(m):fetch(l+"/api/auth/logout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({}),credentials:"include"}).catch(function(){}).finally(m)}e&&e.addEventListener("click",function(t){t.preventDefault(),h()}),g(y);var x=String(window.API_URL||window.API_BASE||window.location.origin).replace(/\/$/,"");fetch(x+"/api/account/status",{method:"GET",credentials:"include",headers:{Accept:"application/json"}}).then(function(t){if(t.ok)return t.json();throw new Error("Unauthenticated")}).then(function(t){if(t&&(t.user||t.id||t.email)){var l=t.user||t;try{localStorage.setItem("conectaKingUser",JSON.stringify(l)),localStorage.setItem("conectaKingSession","1")}catch{}g(!0)}else g(!1)}).catch(function(){y||g(!1)})})();
