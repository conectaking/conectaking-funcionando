(function(){window.SuggestionModal={show(d={}){const{title:c="Gerar Sugestão",message:u="Digite algumas palavras para gerar a sugesto:",placeholder:g="Ex: minha loja de roupas",defaultValue:m="",onConfirm:i=null,onCancel:e=null}=d,a=document.getElementById("suggestion-modal");a&&a.remove();const o=document.createElement("div");o.id="suggestion-modal",o.className="suggestion-modal-overlay",o.innerHTML=`
                <div class="suggestion-modal-content">
                    <div class="suggestion-modal-header">
                        <h3>${c}</h3>
                        <button type="button" class="suggestion-modal-close" id="suggestion-modal-close">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="suggestion-modal-body">
                        <p class="suggestion-modal-message">${u}</p>
                        <input 
                            type="text" 
                            id="suggestion-modal-input" 
                            class="suggestion-modal-input" 
                            placeholder="${g}"
                            value="${m}"
                            autofocus
                        >
                    </div>
                    <div class="suggestion-modal-footer">
                        <button type="button" class="suggestion-modal-btn-cancel" id="suggestion-modal-cancel">
                            Cancelar
                        </button>
                        <button type="button" class="suggestion-modal-btn-confirm" id="suggestion-modal-confirm">
                            <i class="fas fa-magic"></i> Gerar
                        </button>
                    </div>
                </div>
            `,document.body.appendChild(o);const n=document.getElementById("suggestion-modal-input"),r=document.getElementById("suggestion-modal-confirm"),f=document.getElementById("suggestion-modal-cancel"),p=document.getElementById("suggestion-modal-close"),s=()=>{o.remove()},l=()=>{const t=n.value.trim();t.length>=2?(i&&typeof i=="function"&&i(t),s()):(n.focus(),n.style.borderColor="#ff4444",setTimeout(()=>{n.style.borderColor=""},2e3))};r.addEventListener("click",l),f.addEventListener("click",()=>{e&&typeof e=="function"&&e(),s()}),p.addEventListener("click",()=>{e&&typeof e=="function"&&e(),s()}),o.addEventListener("click",t=>{t.target===o&&(e&&typeof e=="function"&&e(),s())}),n.addEventListener("keydown",t=>{t.key==="Enter"?(t.preventDefault(),l()):t.key==="Escape"&&(t.preventDefault(),s())}),setTimeout(()=>{n.focus(),n.select()},100)}}})();
