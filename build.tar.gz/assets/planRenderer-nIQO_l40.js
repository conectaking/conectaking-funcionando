const A={cartao_virtual:"Cartão Virtual",banner:"Banner",carousel:"Carrossel",digital_form:"King Forms",finance:"Gestão Financeira",portfolio:"Portfólio",sales_page:"Página de Vendas",link:"Link personalizado",instagram_embed:"Instagram incorporado",youtube_embed:"YouTube incorporado",modo_empresa:"Modo Empresa",branding:"Personalização da Marca",bible:"Bíblia",location:"Localização",recibos_orcamentos:"Recibos e Orçamentos"};function E(e){return A[e]||e}function L(e){return e?String(e).replace(/\D/g,""):""}function I(e){return JSON.stringify(String(e??""))}function O(e=null){const a=e?.whatsapp_number?String(e.whatsapp_number):"",s=typeof window<"u"&&(window.CONTACT_WHATSAPP_NUMBER||window.CONECTAKING_WHATSAPP_NUMBER)?String(window.CONTACT_WHATSAPP_NUMBER||window.CONECTAKING_WHATSAPP_NUMBER):"";return L(a)||L(s)||"5511988161364"}function k(e){const a=Number(e);return isFinite(a)?a.toFixed(2).replace(".",","):"0,00"}function T(e){const a=parseFloat(e?.monthly_price);if(!isNaN(a)&&a>0)return a;const s=parseFloat(e?.price);return isNaN(s)||s<=0?0:s>=500?s/12:s}function S(e){const a=parseFloat(e?.annual_price);if(!isNaN(a)&&a>0)return a;const s=T(e);return!s||s<=0?0:s*12*.8}function K(e,a={}){const s=a.isDashboard===!0,l=e||{available:[],unavailable:[]},d=l.available||[],y=l.unavailable||[],u=m=>A[m],p=d.filter(u),o=y.filter(u),c="#4CAF50",i="#ff4444",r=s?"border-top: 1px solid var(--border-color, #2C2C2F);":"border-top: 1px solid rgba(255, 255, 255, 0.08);",f=s?"color: var(--text-secondary, #888888);":"color: rgba(245, 245, 245, 0.45);";let t="";return p.length>0&&(t+=`<li style="margin-top: 12px; padding-top: 12px; ${r}"><strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Incluído neste pacote:</strong></li>`,p.forEach(m=>{t+=`<li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${c}; margin-right: 8px;"></i> ${E(m)}</li>`})),o.length>0&&(t+=`<li style="margin-top: 12px; padding-top: 12px; ${r}"><strong style="${f} font-size: 0.95rem;">Não tem nesse pacote:</strong></li>`,o.forEach(m=>{t+=`<li style="padding-left: 8px; opacity: 0.85;"><i class="fas fa-times" style="color: ${i}; margin-right: 8px;"></i> ${E(m)}</li>`})),t}async function B(e){try{let a=window.API_URL;!a&&typeof API_URL<"u"&&(a=API_URL),a||(window.location.origin.includes("127.0.0.1:5500")||window.location.origin.includes("localhost:5500")?a=`${window.location.protocol}//${window.location.hostname}:8080`:(window.location.hostname.includes("conectaking")||window.location.hostname.includes("cnking"),a=window.location.origin)),a=a.replace(/\/$/,"");const s=`${a}/api/modules/plan-availability-public`;let l;try{l=await fetch(s,{method:"GET",headers:{"Content-Type":"application/json",Accept:"application/json"},cache:"no-cache"})}catch{return{available:[],unavailable:[]}}if(!l.ok)return{available:[],unavailable:[]};let d;try{d=await l.json()}catch{return{available:[],unavailable:[]}}const y=d.modules||[],u=[],p=[],o={carousel:"Carrossel",sales_page:"Loja Virtual",digital_form:"King Forms",portfolio:"Portfólio",banner:"Banner",finance:"Gestão Financeira",contract:"Contratos",agenda:"Agenda Inteligente"};y.forEach(i=>{p.push(i.module_type),i.plans&&i.plans[e]?.is_available===!0&&u.push(i.module_type)});const c=p.filter(i=>!u.includes(i));return{available:u,unavailable:c}}catch{return{available:[],unavailable:[]}}}function N(e,a=null,s="monthly"){if(e.plan_code==="adm_principal"||e.plan_code==="abm")return"";const l=e.features||{},d=e.whatsapp_number||"",y=e.pix_key||"",u=a||{available:[],unavailable:[]},p=e.plan_code==="basic",o=e.plan_code==="premium",c=e.plan_code==="king_base",i=e.plan_code==="king_finance",r=e.plan_code==="king_finance_plus",f=e.plan_code==="king_premium_plus",t=e.plan_code==="king_corporate"||e.plan_code==="enterprise";let m=`Olá! Gostaria de adquirir o plano ${e.plan_name} do ConectaKing!`;p?m="Olá! Gostaria de adquirir o plano King Start do ConectaKing!":o?m="Olá! Gostaria de adquirir o plano King Prime do ConectaKing!":c?m="Olá! Gostaria de adquirir o plano King Essential do ConectaKing!":i?m="Olá! Gostaria de adquirir o plano King Finance do ConectaKing!":r?m="Olá! Gostaria de adquirir o plano King Finance Plus do ConectaKing!":f?m="Olá! Gostaria de adquirir o plano King Premium Plus do ConectaKing!":t&&(m="Olá! Gostaria de adquirir o plano King Corporate do ConectaKing!");const _=e.whatsapp_message||m,v=L(d)||O(e);let h,x,$;return s==="annual"?(h=parseFloat(e.annual_price||e.price),x="/ano",$=h):(h=parseFloat(e.monthly_price||e.price/12),x="/mês",$=h),`
        <div class="subscription-plan-card ${t?"plan-highlighted":""}">
            <h3>${e.plan_name}</h3>
            <div class="plan-price">
                <span class="plan-currency">R$</span>
                <span class="plan-amount">${h.toFixed(2).replace(".",",")}</span>
                <span class="plan-period" style="font-size: 0.9rem; color: var(--text-secondary, #888888);">${x}</span>
            </div>
            ${s==="annual"?`
            <div style="margin-top: 8px; padding: 8px; background: rgba(76, 175, 80, 0.1); border-radius: 6px; font-size: 0.9rem; color: #4CAF50; text-align: center;">
                <strong>No Pix</strong>
            </div>
            `:`
            <div style="margin-top: 8px; padding: 8px; background: rgba(255, 199, 0, 0.1); border-radius: 6px; font-size: 0.9rem; color: var(--dourado-principal, #FFC700); text-align: center;">
                R$ ${$.toFixed(2).replace(".",",")} por mês<br>
                <span style="font-size: 0.8rem; opacity: 0.8; color: var(--text-secondary, #888888);">(no Pix ou no cartão de crédito)</span>
            </div>
            `}
            <p class="plan-description">${e.description||""}</p>
            <ul class="plan-features">
                <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                ${l.can_edit_logo||t?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                ${o||t?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Link personalizado</li>':""}
                ${t?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Modo Empresarial</li><li><i class="fas fa-check" style="color: #4CAF50;"></i> 3 perfis</li>':""}
                ${r?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> 2 perfis de Gestão Financeira</li>':""}
                ${K(u,{isDashboard:!0})}
            </ul>
            <div class="plan-actions">
                <a href="https://wa.me/${v.replace(/\D/g,"")}?text=${encodeURIComponent(_)}" target="_blank" class="btn btn-primary" style="width: 100%; margin-bottom: 10px;">
                    <i class="fab fa-whatsapp"></i> Assinar agora
                </a>
                <button class="btn btn-secondary" style="width: 100%;" onclick="copyPixKey(${I(y||"")})">
                    <i class="fas fa-copy"></i> Copiar Chave PIX
                </button>
            </div>
        </div>
    `}function R(e){return{pix:e*(1-.05),cardPerMonth:e*(1+.0299*12)/12,monthly:e}}function z(e,a=null,s="monthly"){if(!e||e.plan_code==="adm_principal"||e.plan_code==="abm"||!e.plan_name)return"";const l=e.features||{},d=a||{available:[],unavailable:[]},y=T(e),u=S(e);if(!y||y<=0)return`<div class="pricing-card"><p style="color: rgba(245,245,245,0.7);">Erro: preço inválido para ${e.plan_name}</p></div>`;const p=s==="annual",o=p?u:y,c=p?"/ano":"/mês",i=e.plan_code==="basic",r=e.plan_code==="premium",f=e.plan_code==="king_base",t=e.plan_code==="king_finance",m=e.plan_code==="king_finance_plus",_=e.plan_code==="king_premium_plus",v=e.plan_code==="enterprise"||e.plan_code==="king_corporate";let h="Assinar agora",x=`Olá! Gostaria de adquirir o plano ${e.plan_name} do ConectaKing!`;i?(h="Começar agora",x="Olá! Gostaria de adquirir o plano King Start do ConectaKing!"):r?(h="Quero o Prime",x="Olá! Gostaria de adquirir o plano King Prime do ConectaKing!"):f?(h="Quero o Essential",x="Olá! Gostaria de adquirir o plano King Essential do ConectaKing!"):t?(h="Quero o Finance",x="Olá! Gostaria de adquirir o plano King Finance do ConectaKing!"):m?(h="Quero o Finance Plus",x="Olá! Gostaria de adquirir o plano King Finance Plus do ConectaKing!"):_?(h="Quero o Premium Plus",x="Olá! Gostaria de adquirir o plano King Premium Plus do ConectaKing!"):v&&(h="Ativar modo empresa",x="Olá! Gostaria de adquirir o plano King Corporate do ConectaKing!");const $=e.whatsapp_message||x,D=O(e),G=p?`${$}

Forma: Anual (-20%)
Valor: R$ ${k(o)}/ano`:`${$}

Forma: Mensal
Valor: R$ ${k(o)}/mês`,b="border-top: 1px solid rgba(255, 255, 255, 0.08);",P="color: #FFFFFF;",C="color: rgba(245, 245, 245, 0.45);",n="#4CAF50",g="#ff4444";let w="";i?w=`
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        <li><i class="fas fa-check" style="color:${n};"></i> Acesso a todos os módulos, exceto:</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Logomarca editável</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> King Forms</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Contratos</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>`:r?w=`
        ${l.can_edit_logo?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        <li><i class="fas fa-check" style="color:${n};"></i> Link personalizado</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${P} font-size: 0.95rem;">Módulos incluídos:</strong></li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Portfólio</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Banner</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Contratos</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>`:t?w=`
        ${l.can_edit_logo?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${P} font-size: 0.95rem;">Módulos incluídos:</strong></li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Portfólio</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Banner</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> King Forms</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>`:m?w=`
        ${l.can_edit_logo?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil de cartão virtual</li>
        <li><i class="fas fa-check" style="color:${n};"></i> 2 perfis de Gestão Financeira</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${P} font-size: 0.95rem;">Módulos incluídos:</strong></li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Contratos</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> King Forms</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>`:_?w=`
        ${l.can_edit_logo?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${P} font-size: 0.95rem;">Módulos incluídos:</strong></li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Contratos</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Agenda Inteligente</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> King Forms</li>`:v?w=`
        <li><i class="fas fa-check" style="color:${n};"></i> Logomarca editável</li>
        <li><i class="fas fa-check" style="color:${n};"></i> Modo Empresarial</li>
        <li><i class="fas fa-check" style="color:${n};"></i> 3 perfis</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Gestão Financeira</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Contratos</li>`:f?w=`
        ${l.can_edit_logo?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${P} font-size: 0.95rem;">Módulos incluídos:</strong></li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Carrossel</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Loja Virtual</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Portfólio</li>
        <li style="padding-left: 8px;"><i class="fas fa-check" style="color: ${n}; margin-right: 8px;"></i> Banner</li>
        <li style="margin-top: 12px; padding-top: 12px; ${b}"><strong style="${C} font-size: 0.95rem;">Não incluído:</strong></li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> King Forms</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Contratos</li>
        <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: ${g}; margin-right: 8px;"></i> Agenda Inteligente</li>`:w=`
        <li><i class="fas fa-check" style="color:${n};"></i> 1 perfil</li>
        ${l.can_edit_logo||v?'<li><i class="fas fa-check" style="color:'+n+';"></i> Logomarca editável</li>':""}
        ${r||v?'<li><i class="fas fa-check" style="color:'+n+';"></i> Link personalizado</li>':""}
        ${v?'<li><i class="fas fa-check" style="color:'+n+';"></i> Modo Empresarial</li><li><i class="fas fa-check" style="color:'+n+';"></i> 3 perfis</li>':""}
        ${m?'<li><i class="fas fa-check" style="color:'+n+';"></i> 2 perfis de Gestão Financeira</li>':""}
        `+K(d,{isDashboard:!1});const W=(e.pix_key||(typeof window<"u"?window.CONECTAKING_PIX_KEY:"")||"").toString();return`
        <div class="pricing-card fade-in">
            <div class="plan-title">${e.plan_name}</div>
            <div class="plan-price-row">
                <span class="plan-currency">R$</span>
                <span class="plan-price">${k(o)}</span>
                <span class="plan-period">${c}</span>
            </div>
            <div class="plan-pill">
                <span class="plan-pill-amount">R$ ${k(o)} ${p?"por ano":"por mês"}</span>
                <span class="plan-pill-note">(no Pix ou no cartão de crédito)</span>
            </div>
            <p class="plan-desc">${e.description||""}</p>
            <ul class="plan-features">
                ${w}
            </ul>
            <div class="plan-actions">
                <a href="https://wa.me/${L(D)}?text=${encodeURIComponent(G)}" target="_blank" class="plan-btn plan-btn-primary">
                    <i class="fas fa-clock"></i> ${h}
                </a>
                <button class="plan-btn plan-btn-secondary" type="button" onclick="copyPixKey(${I(W)})">
                    <i class="fas fa-copy"></i> Copiar Chave PIX
                </button>
            </div>
        </div>
    `}async function H(e,a,s=!1){let l=document.getElementById(a);if(!l)return;if(e.length===0){l.innerHTML='<p style="text-align: center; grid-column: 1 / -1;">Nenhum plano disponível no momento.</p>';return}const d=e.filter(o=>o.plan_code!=="adm_principal"&&o.plan_code!=="abm"),y=["basic","premium","king_finance","king_finance_plus","king_premium_plus","king_corporate","enterprise"],u=o=>{const c=y.indexOf(o);return c===-1?999:c};if(d.sort((o,c)=>{const i=u(o?.plan_code),r=u(c?.plan_code);return i!==r?i-r:String(o?.plan_name||"").localeCompare(String(c?.plan_name||""))}),d.length===0){l.innerHTML='<p style="text-align: center; grid-column: 1 / -1;">Nenhum plano disponível no momento.</p>';return}const p=await Promise.all(d.map(async o=>{try{const c=await B(o.plan_code);return{...o,modules:c}}catch{return{...o,modules:{available:[],unavailable:[]}}}}));if(window.loadedPlansWithModules=p.map(o=>({...o,modules:o.modules||{available:[],unavailable:[]}})),window.plansContainer=l,window.plansContainerId=a,s){let o=document.getElementById("pricing-toggle-container-dashboard");if(!o){o=document.createElement("div"),o.id="pricing-toggle-container-dashboard",o.style.cssText="display: flex; justify-content: center; align-items: center; gap: 16px; margin-bottom: 30px; padding: 15px 0;";const c=document.createElement("div");c.style.cssText="display: flex; align-items: center; gap: 12px; background: var(--card-bg, #2C2C2F); padding: 8px; border-radius: 50px; border: 2px solid rgba(255, 199, 0, 0.3);";const i=document.createElement("button");i.id="toggle-monthly-dashboard",i.textContent="Mensal",i.style.cssText="padding: 10px 28px; border: none; border-radius: 50px; background: var(--dourado-principal, #FFC700); color: var(--text-primary, #FFFFFF); font-weight: 600; font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease;",i.classList.add("active");const r=document.createElement("button");r.id="toggle-annual-dashboard",r.innerHTML='Anual <span style="color: #4CAF50; font-size: 0.8rem; margin-left: 4px;">-20%</span>',r.style.cssText="padding: 10px 28px; border: none; border-radius: 50px; background: transparent; color: var(--text-secondary, #888888); font-weight: 600; font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease;",i.addEventListener("click",()=>{i.style.background="var(--dourado-principal, #FFC700)",i.style.color="var(--text-primary, #FFFFFF)",r.style.background="transparent",r.style.color="var(--text-secondary, #888888)",i.classList.add("active"),r.classList.remove("active"),window.currentPricingModeDashboard="monthly",window.loadedPlansWithModulesDashboard&&window.plansContainerDashboard&&M(window.loadedPlansWithModulesDashboard,window.plansContainerDashboard,"monthly")}),r.addEventListener("click",()=>{r.style.background="var(--dourado-principal, #FFC700)",r.style.color="var(--text-primary, #FFFFFF)",i.style.background="transparent",i.style.color="var(--text-secondary, #888888)",r.classList.add("active"),i.classList.remove("active"),window.currentPricingModeDashboard="annual",window.loadedPlansWithModulesDashboard&&window.plansContainerDashboard&&M(window.loadedPlansWithModulesDashboard,window.plansContainerDashboard,"annual")}),c.appendChild(i),c.appendChild(r),o.appendChild(c),l.parentNode.insertBefore(o,l)}window.loadedPlansWithModulesDashboard=p,window.plansContainerDashboard=l,window.currentPricingModeDashboard=window.currentPricingModeDashboard||"monthly",M(p,l,window.currentPricingModeDashboard)}else{let o=document.getElementById("pricing-toggle-container");if(!o){o=document.createElement("div"),o.id="pricing-toggle-container",o.style.cssText="display: flex; justify-content: center; align-items: center; gap: 16px; margin-bottom: 40px; padding: 20px 0;";const c=document.createElement("div");c.style.cssText="display: flex; align-items: center; gap: 12px; background: var(--graphite, #1F1F1F); padding: 8px; border-radius: 50px; border: 2px solid rgba(255, 199, 0, 0.3);";const i=document.createElement("button");i.id="toggle-monthly",i.textContent="Mensal",i.style.cssText="padding: 12px 32px; border: none; border-radius: 50px; background: var(--yellow-primary, #FFC700); color: var(--black-absolute, #0B0B0B); font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s ease;",i.classList.add("active");const r=document.createElement("button");r.id="toggle-annual",r.innerHTML='Anual <span style="color: #4CAF50; font-size: 0.85rem; margin-left: 4px;">-20%</span>',r.style.cssText="padding: 12px 32px; border: none; border-radius: 50px; background: transparent; color: var(--white, #F5F5F5); font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s ease;",i.addEventListener("click",()=>{i.style.background="var(--yellow-primary, #FFC700)",i.style.color="var(--black-absolute, #0B0B0B)",r.style.background="transparent",r.style.color="var(--white, #F5F5F5)",i.classList.add("active"),r.classList.remove("active"),window.currentPricingMode="monthly";let f=window.loadedPlansWithModules,t=window.plansContainer;!t&&window.plansContainerId&&(t=document.getElementById(window.plansContainerId),window.plansContainer=t),t||(t=document.getElementById("plans-container"),t&&(window.plansContainer=t)),(!f||f.length===0)&&(f=window.loadedPlansWithModules),f&&f.length>0&&t?F(f,t,"monthly"):t?t.innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: rgba(245, 245, 245, 0.7);">Erro ao carregar planos. Recarregue a página.</p>':typeof loadPlans=="function"&&loadPlans()}),r.addEventListener("click",()=>{r.style.background="var(--yellow-primary, #FFC700)",r.style.color="var(--black-absolute, #0B0B0B)",i.style.background="transparent",i.style.color="var(--white, #F5F5F5)",r.classList.add("active"),i.classList.remove("active"),window.currentPricingMode="annual";let f=window.loadedPlansWithModules,t=window.plansContainer;!t&&window.plansContainerId&&(t=document.getElementById(window.plansContainerId),window.plansContainer=t),t||(t=document.getElementById("plans-container"),t&&(window.plansContainer=t)),(!f||f.length===0)&&(f=window.loadedPlansWithModules),f&&f.length>0&&t?F(f,t,"annual"):t?t.innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: rgba(245, 245, 245, 0.7);">Erro ao carregar planos. Recarregue a página.</p>':typeof loadPlans=="function"&&loadPlans()}),c.appendChild(i),c.appendChild(r),o.appendChild(c),l.parentNode.insertBefore(o,l)}window.currentPricingMode=window.currentPricingMode||"monthly",window.loadedPlansWithModules||(window.loadedPlansWithModules=p),window.plansContainer||(window.plansContainer=l),window.plansContainerId||(window.plansContainerId=a),F(p,l,window.currentPricingMode)}if(!s&&typeof IntersectionObserver<"u"){const o=new IntersectionObserver(c=>{c.forEach(i=>{i.isIntersecting&&i.target.classList.add("visible")})},{threshold:.1});document.querySelectorAll(".pricing-card").forEach(c=>o.observe(c))}}function F(e,a,s="monthly"){try{if(!a)return;if(!e||e.length===0){a.innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: rgba(245, 245, 245, 0.7);">Nenhum plano disponível no momento.</p>';return}const l=e.map((d,y)=>{try{if(!d)return"";const u=d.modules||{available:[],unavailable:[]};if(!d.plan_name||!d.plan_code)return"";const p=z(d,u,s);return!p||p.trim()===""?"":p}catch{return""}}).filter(d=>d!==""&&d!==null&&d!==void 0).join("");if(!l||l.trim()===""){a.innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: rgba(245, 245, 245, 0.7); padding: 20px;">Erro ao renderizar planos. Recarregue a página.</p>';return}if(!a.parentNode){if(a=document.getElementById("plans-container"),!a)return;window.plansContainer=a}if(a.innerHTML=l,typeof IntersectionObserver<"u"){const d=new IntersectionObserver(y=>{y.forEach(u=>{u.isIntersecting&&u.target.classList.add("visible")})},{threshold:.1});a.querySelectorAll(".pricing-card").forEach(y=>d.observe(y))}}catch{a&&(a.innerHTML='<p style="text-align: center; grid-column: 1 / -1; color: #ff4444; padding: 20px;">Erro ao exibir planos. Por favor, recarregue a página.</p>')}}function M(e,a,s="monthly"){if(!e||e.length===0){a.innerHTML="<p>Nenhum plano disponível no momento.</p>";return}a.innerHTML=e.map(l=>N(l,l.modules,s)).join("")}function q(e){if(!e||e.trim()===""){alert("Chave PIX não configurada para este plano. Entre em contato conosco via WhatsApp.");return}navigator.clipboard.writeText(e).then(()=>{alert("Chave PIX copiada!")}).catch(()=>{const a=document.createElement("textarea");a.value=e,document.body.appendChild(a),a.select(),document.execCommand("copy"),document.body.removeChild(a),alert("Chave PIX copiada!")})}typeof window<"u"&&(window.loadPlanModules=B,window.renderPlanCardDashboard=N,window.renderPlanCardPublic=z,window.renderPlansShared=H,window.renderPlansWithMode=F,window.renderPlansWithModeDashboard=M,window.calculatePrices=R,window.copyPixKey=q);
