const e=new URLSearchParams(location.search||""),n=e.get("slug")||"";document.getElementById("ks-home").href=`kingSelection/${encodeURIComponent(n)}`;
