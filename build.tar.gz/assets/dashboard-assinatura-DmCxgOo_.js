(function(M){var i=function(){try{localStorage.getItem("ck_debug")}catch{}};function I(){return M.DashboardCore||{}}var r={get API_URL(){var e=I();return typeof e.getApiUrl=="function"?e.getApiUrl()||"":M.API_URL||M.API_BASE||""},get HEADERS(){var e=I();return typeof e.getHeaders=="function"?e.getHeaders()||{}:{"Content-Type":"application/json"}},get HEADERS_AUTH(){var e=I();return typeof e.getAuthHeaders=="function"?e.getAuthHeaders()||{}:typeof e.getHeadersAuth=="function"?e.getHeadersAuth()||{}:{}},safeFetch:function(e,o){var s=I();return typeof s.safeFetch=="function"?s.safeFetch(e,o):fetch(e,o)}};new Proxy({},{get:function(e,o){var s=I(),n=typeof s.getSelectors=="function"?s.getSelectors():null;return n?n[o]:null}});let L=null,N=!1;async function B(){try{const n=await r.safeFetch(`${r.API_URL}/api/subscription/info`,{method:"GET",headers:r.HEADERS_AUTH});if(!n.ok)throw new Error("Erro ao carregar informações de assinatura");L=await n.json(),N=L.user?.isAdmin||!1,K(),await G();const a=document.getElementById("personalizar-link-link");if(a&&N&&(a.style.display="block"),N){var e=document.getElementById("subscription-admin-section");e&&(e.style.display="block"),R()}}catch{var o=document.getElementById("subscription-info");o&&(o.innerHTML='<p style="color: #ff4444;">Erro ao carregar informações. Tente novamente.</p>');var s=document.getElementById("subscription-plans-list");s&&(s.innerHTML='<p style="color: #ff4444;">Não foi possível carregar os planos. Atualize a página.</p>')}}function K(){const e=document.getElementById("subscription-info"),o=L.user,s=L.currentPlan;if(!o){e.innerHTML="<p>Nenhuma informação disponível.</p>";return}const n={active:"#4CAF50",expired:"#ff4444",expired_trial:"#ff9800",pre_sale_trial:"#2196F3"},a={active:"Ativo",active_onetime:"Ativo",expired:"Expirado",expired_trial:"Expirado",pre_sale_trial:"Ativo"},t=n[o.subscriptionStatus]||"#999",f=a[o.subscriptionStatus]||o.subscriptionStatus,l=o.subscriptionExpiresAt?new Date(o.subscriptionExpiresAt).toLocaleDateString("pt-BR"):"Não definido",m=o.createdAt?new Date(o.createdAt).toLocaleDateString("pt-BR"):"Não definido";e.innerHTML=`
        <div class="subscription-info-item">
            <label>Status:</label>
            <span style="color: ${t}; font-weight: 600;">${f}</span>
        </div>
        <div class="subscription-info-item">
            <label>Plano Atual:</label>
            <span style="font-weight: 600; color: var(--dourado-principal, #FFC700);">
                ${s?s.plan_name:"Nenhum plano ativo"}
            </span>
        </div>
        ${s?`
        <div class="subscription-info-item">
            <label>Preço Mensal:</label>
            <span style="font-size: 1.1rem; font-weight: 600; color: var(--dourado-principal, #FFC700);">
                R$ ${s.monthly_price?parseFloat(s.monthly_price).toFixed(2).replace(".",","):parseFloat(s.price/12).toFixed(2).replace(".",",")}/mês
            </span>
        </div>
        <div class="subscription-info-item">
            <label>Preço Anual:</label>
            <span style="font-size: 1.1rem; font-weight: 600; color: var(--dourado-principal, #FFC700);">
                R$ ${s.annual_price?parseFloat(s.annual_price).toFixed(2).replace(".",","):parseFloat(s.price).toFixed(2).replace(".",",")}/ano
            </span>
        </div>
        `:""}
        <div class="subscription-info-item">
            <label>Data de Assinatura:</label>
            <span>${m}</span>
        </div>
        <div class="subscription-info-item">
            <label>Data de Expiração:</label>
            <span>${l}</span>
        </div>
    `}const U={basic:"individual",premium:"individual_com_logo",enterprise:"business_owner"};let D={};async function X(e){if(D[e])return D[e];try{const o=U[e];if(!o)return{available:[],unavailable:[]};const s=await r.safeFetch(`${r.API_URL}/api/modules/available?plan_code=${o}`,{method:"GET",headers:r.HEADERS_AUTH});if(!s.ok)return await V(o);const a=(await s.json()).available_modules||[],f=["whatsapp","telegram","email","pix","pix_qrcode","wifi","facebook","instagram","tiktok","twitter","youtube","spotify","linkedin","pinterest","link","portfolio","banner","carousel","youtube_embed","sales_page","digital_form"].filter(l=>!a.includes(l));return D[e]={available:a,unavailable:f},D[e]}catch{return await V(U[e]||e)}}async function V(e){try{const o=await r.safeFetch(`${r.API_URL}/api/modules/plan-availability`,{method:"GET",headers:r.HEADERS_AUTH});if(!o.ok)return{available:[],unavailable:[]};const n=(await o.json()).modules||[],a=[],t=[];n.forEach(l=>{t.push(l.module_type),l.plans&&l.plans[e]?.is_available!==!1&&a.push(l.module_type)});const f=t.filter(l=>!a.includes(l));return{available:a,unavailable:f}}catch{return{available:[],unavailable:[]}}}async function G(){const o=(L.availablePlans||[]).filter(a=>a.plan_code!=="king_base");if(i(`Y"< Planos filtrados na assinatura: ${o.length} planos (excluído: King Essential)`),typeof window.renderPlansShared=="function"){await window.renderPlansShared(o,"subscription-plans-list",!0);return}const s=document.getElementById("subscription-plans-list");if(o.length===0){s.innerHTML="<p>Nenhum plano disponível no momento.</p>";return}const n=await Promise.all(o.map(async a=>{const t=await X(a.plan_code);return{...a,modules:t}}));s.innerHTML=n.map(a=>{const t=a.features||{};a.whatsapp_number;const f=a.pix_key||"",l=a.modules||{available:[],unavailable:[]};Object.keys({carousel:"Carrossel",sales_page:"Loja Virtual",digital_form:"King Forms",portfolio:"Portfólio",banner:"Banner"}).forEach(d=>{l.available.includes(d)||l.unavailable.includes(d)}),l.available.length+l.unavailable.length,l.available.length;const v=t.max_finance_profiles||0,g=t.max_profiles||1,b=a.plan_code==="basic",y=a.plan_code==="premium",E=a.plan_code==="king_base",S=a.plan_code==="king_finance",_=a.plan_code==="king_finance_plus",k=a.plan_code==="king_premium_plus",F=a.plan_code==="king_corporate"||a.plan_code==="enterprise";return`
            <div class="subscription-plan-card ${F?"plan-highlighted":""}">
                <h3>${a.plan_name}</h3>
                <div class="plan-price">
                    <span class="plan-currency">R$</span>
                    <span class="plan-amount">${parseFloat(a.price).toFixed(2).replace(".",",")}</span>
                    <span class="plan-period" style="font-size: 0.9rem; color: var(--text-secondary, #888888);">pagamento único</span>
                </div>
                <p class="plan-description">${a.description||""}</p>
                <ul class="plan-features">
                    ${b?`
                    <!-- King Start: 1 perfil + Acesso a todos módulos exceto -->
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> Acesso a todos os módulos, exceto:</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Logomarca editável</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> King Forms</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Contratos</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    `:""}
                    
                    ${y?`
                    <!-- King Prime: 1 perfil + Módulos incluídos (Carrossel, Portfólio, Banner, Loja Virtual) + Não incluído: Gestão Financeira, Contratos, Agenda (King Forms não faz parte deste pacote) -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Módulos incluídos:</strong>
                    </li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Portfólio</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Banner</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Contratos</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    `:""}
                    
                    ${E?`
                    <!-- King Essential (antigo King Base): 1 perfil + Módulos incluídos + Não incluído -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Módulos incluídos:</strong>
                    </li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Portfólio</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Banner</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> King Forms</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Contratos</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    `:""}
                    
                    ${S?`
                    <!-- King Finance: 1 perfil + Módulos incluídos (SEM King Forms) + Não incluído: King Forms, Agenda -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Módulos incluídos:</strong>
                    </li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Portfólio</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Banner</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> King Forms</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    `:""}
                    
                    ${_?`
                    <!-- King Finance Plus: 2 perfis gestão financeira + Módulos incluídos (SEM King Forms) + Não incluído: King Forms, Agenda -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil de cartão virtual</li>
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 2 perfis de Gestão Financeira</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Módulos incluídos:</strong>
                    </li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Contratos</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> King Forms</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    `:""}
                    
                    ${k?`
                    <!-- King Premium Plus: Tudo incluído (incluindo Agenda Inteligente e King Forms a partir de R$ 2.200) -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 1 perfil</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-primary, #FFFFFF); font-size: 0.95rem;">Módulos incluídos:</strong>
                    </li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Contratos</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Agenda Inteligente</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Carrossel</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px;"><i class="fas fa-check" style="color: #4CAF50; margin-right: 8px;"></i> King Forms</li>
                    `:""}
                    
                    ${F?`
                    <!-- King Corporate: Logomarca editável + Modo empresarial + 3 perfis + Não inclui -->
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> Modo Empresarial</li>
                    <li><i class="fas fa-check" style="color: #4CAF50;"></i> 3 perfis</li>
                    <li style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <strong style="color: var(--text-secondary, #888888); font-size: 0.95rem;">Não incluído:</strong>
                    </li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Gestão Financeira</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Loja Virtual</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Agenda Inteligente</li>
                    <li style="padding-left: 8px; opacity: 0.7;"><i class="fas fa-times" style="color: #ff4444; margin-right: 8px;"></i> Contratos</li>
                    `:""}
                    
                    ${!b&&!y&&!E&&!S&&!_&&!k&&!F?`
                    <!-- Planos genéricos -->
                    ${t.can_edit_logo?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Logomarca editável</li>':""}
                    ${g>0?`<li><i class="fas fa-check" style="color: #4CAF50;"></i> ${g} perfil${g>1?"s":""}</li>`:""}
                    ${v>0?`<li><i class="fas fa-check" style="color: #4CAF50;"></i> ${v} perfil${v>1?"s":""} de Gestão Financeira</li>`:""}
                    ${t.is_enterprise?'<li><i class="fas fa-check" style="color: #4CAF50;"></i> Modo Empresarial</li>':""}
                    `:""}
                </ul>
                <div class="plan-actions">
                    <a href="https://wa.me/${whatsappNumber.replace(/\D/g,"")}?text=${encodeURIComponent(finalWhatsappMessage)}" target="_blank" class="btn btn-primary" style="width: 100%; margin-bottom: 10px;">
                        <i class="fab fa-whatsapp"></i> Assinar agora
                    </a>
                    <button class="btn btn-secondary" style="width: 100%;" onclick="copyPixKey('${f||""}')">
                        <i class="fas fa-copy"></i> Copiar Chave PIX
                    </button>
                </div>
            </div>
        `}).join("")}window.copyPixKey=function(e){if(!e||e.trim()===""){alert("Chave PIX não configurada para este plano. Entre em contato conosco via WhatsApp.");return}navigator.clipboard.writeText(e).then(()=>{alert("Chave PIX copiada!")}).catch(()=>{const o=document.createElement("textarea");o.value=e,document.body.appendChild(o),o.select(),document.execCommand("copy"),document.body.removeChild(o),alert("Chave PIX copiada!")})};async function R(){try{i(" Carregando planos para edição...");const e=await r.safeFetch(`${r.API_URL}/api/subscription/plans?t=${Date.now()}`,{method:"GET",headers:{...r.HEADERS_AUTH,"Cache-Control":"no-cache"}});if(!e.ok){const s=await e.text();throw new Error(`Erro ao carregar planos para edição: ${e.status}`)}const o=await e.json();if(i(`${o.plans?.length||0} planos carregados`),!o.plans||o.plans.length===0){document.getElementById("plans-edit-form").innerHTML='<p style="color: #ff4444;">Nenhum plano encontrado.</p>';return}await W(o.plans),i("Formulário de edição renderizado")}catch(e){const o=document.getElementById("plans-edit-form");o&&(o.innerHTML=`<p style="color: #ff4444;">Erro ao carregar planos: ${e.message}</p>`)}}async function W(e){const o=document.getElementById("plans-edit-form");if(!o)return;i(` Renderizando formulário para ${e.length} planos...`);let s=[];try{const a=`t=${Date.now()}&_=${Math.random()}`;i(" Buscando disponibilidade de módulos (sem cache)...");const t=await r.safeFetch(`${r.API_URL}/api/modules/plan-availability?${a}`,{method:"GET",headers:{...r.HEADERS_AUTH,"Cache-Control":"no-cache, no-store, must-revalidate",Pragma:"no-cache",Expires:"0"}});if(t.ok)s=(await t.json()).modules||[],i(`${s.length} módulos carregados`),s.length>0&&(i('Y"S Módulos carregados da API:'),s.forEach(l=>{Object.keys(l.plans||{}).forEach(v=>{const g=l.plans[v];i(`   ${l.module_type} para ${v}: is_available = ${g.is_available} (${typeof g.is_available})`)})}));else{const f=await t.text()}}catch{}const n={cartao_virtual:"Cartão Virtual",carousel:"Carrossel",sales_page:"Loja Virtual",digital_form:"King Forms",portfolio:"Portfólio",banner:"Banner",finance:"Gestão Financeira",modo_empresa:"Modo Empresa",branding:"Personalização da Marca",location:"Localização",king_selection:"King Selection",king_camera:"King Câmera",king_docs:"King Docs",recibos_orcamentos:"Recibos e Orçamentos"};o.innerHTML=e.map(a=>{const f=(a.features||{}).can_edit_logo||!1,l=[],m=[];Object.keys(n).forEach(d=>{const p=s.find(P=>P.module_type===d),h=n[d];if(p&&p.plans&&p.plans[a.plan_code]){const P=p.plans[a.plan_code].is_available===!0,T=p.plans[a.plan_code].is_available;i(`  ${h} (${d}) para ${a.plan_code}: is_available = ${T} (${typeof T})`),P?l.push(h):m.push(h)}else i(`  Módulo ${h} (${d}) não encontrado na API para ${a.plan_code} - adicionando aos não incluídos`),m.push(h)});const v=[...new Set(l)],g=[...new Set(m)],b=v.filter(d=>!g.includes(d)),y=g.filter(d=>!b.includes(d)),E=Object.values(n),S=[...b,...y],_=E.filter(d=>!S.includes(d));_.length>0&&y.push(..._),i(`Y"< Plano ${a.plan_name} (${a.plan_code}): ${b.length} incluídos, ${y.length} não incluídos`),i(`   Incluídos: ${b.join(", ")||"(nenhum)"}`),i(`   Não incluídos: ${y.join(", ")||"(nenhum)"}`);const k=b.join(", "),F=y.join(", ");if(a.plan_code==="king_finance"){const d=k.includes("Contratos"),p=F.includes("Contratos");i(`   [DEBUG King Finance] Contratos - Incluídos: ${d}, Não Incluídos: ${p}`),!d&&!p&&y.push("Contratos")}return`
            <div class="plan-edit-card" style="border: 1px solid var(--border-color, #2C2C2F); border-radius: 8px; padding: 20px; margin-bottom: 20px;">
                <h3>${a.plan_name} (${a.plan_code})</h3>
                <div class="form-group">
                    <label>Nome do Plano:</label>
                    <input type="text" class="form-input" id="plan-name-${a.id}" value="${a.plan_name||""}">
                </div>
                <div class="form-group">
                    <label>Preço (R$):</label>
                    <input type="text" class="form-input" id="plan-price-${a.id}" value="${a.price?parseFloat(a.price).toFixed(2).replace(".",","):"0,00"}" placeholder="700,00">
                </div>
                <div class="form-group">
                    <label>Descrição:</label>
                    <textarea class="form-input" id="plan-description-${a.id}" rows="3">${a.description||""}</textarea>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" id="plan-can-edit-logo-${a.id}" ${f?"checked":""}>
                        <span>Logomarca editável (em Módulos Incluídos)</span>
                    </label>
                </div>
                <div class="form-group">
                    <label>Módulos Incluídos (separados por vírgula):</label>
                    <textarea class="form-input" id="plan-included-modules-${a.id}" rows="4" placeholder="Ex: Carrossel, Portfólio, Banner, Loja Virtual">${k}</textarea>
                    <small style="color: var(--text-secondary, #888888); display: block; margin-top: 5px;">
                        Módulos disponíveis: Carrossel, Loja Virtual, King Forms, Portfólio, Banner, Gestão Financeira
                    </small>
                </div>
                <div class="form-group">
                    <label>Módulos Não Incluídos (separados por vírgula):</label>
                    <textarea class="form-input" id="plan-excluded-modules-${a.id}" rows="4" placeholder="Ex: King Forms, Gestão Financeira">${F}</textarea>
                    <small style="color: var(--text-secondary, #888888); display: block; margin-top: 5px;">
                        Lista os módulos que NÃO estão incluídos neste plano
                    </small>
                </div>
                <div class="form-group">
                    <label>WhatsApp (apenas números):</label>
                    <input type="text" class="form-input" id="plan-whatsapp-${a.id}" value="${a.whatsapp_number||""}" placeholder="5511999999999">
                </div>
                <div class="form-group">
                    <label>Mensagem Personalizada do WhatsApp:</label>
                    <textarea class="form-input" id="plan-whatsapp-message-${a.id}" rows="3" placeholder="Mensagem que será enviada automaticamente ao clicar em 'Assinar agora'">${a.whatsapp_message||""}</textarea>
                    <small style="color: var(--text-secondary, #888888); display: block; margin-top: 5px;">
                        Esta mensagem será enviada automaticamente quando o usuário clicar em "Assinar agora"
                    </small>
                </div>
                <div class="form-group">
                    <label>Chave PIX:</label>
                    <input type="text" class="form-input" id="plan-pix-${a.id}" value="${a.pix_key||""}" placeholder="Chave PIX para pagamento">
                </div>
                <button class="btn btn-primary" onclick="savePlan(${a.id})">
                    <i class="fas fa-save"></i> Salvar Alterações
                </button>
            </div>
        `}).join("")}window.savePlan=async function(e){try{i(` Iniciando salvamento do plano ID: ${e}`);const o=document.getElementById(`plan-name-${e}`).value.trim(),n=document.getElementById(`plan-price-${e}`).value.trim().replace(/\./g,"").replace(",","."),a=parseFloat(n),t=document.getElementById(`plan-description-${e}`).value.trim(),f=document.getElementById(`plan-can-edit-logo-${e}`).checked,l=document.getElementById(`plan-included-modules-${e}`).value.trim(),m=document.getElementById(`plan-excluded-modules-${e}`).value.trim(),v=document.getElementById(`plan-whatsapp-${e}`).value.trim(),g=document.getElementById(`plan-whatsapp-message-${e}`).value.trim(),b=document.getElementById(`plan-pix-${e}`).value.trim();if(!o){alert("Nome do plano é obrigatório!");return}if(isNaN(a)||a<=0){alert("Preço inválido! Use formato brasileiro: 700,00 (vírgula para decimais)");return}i('Y"< Dados coletados:',{planName:o,price:a,description:t.substring(0,50)+"...",canEditLogo:f,includedModules:l.substring(0,50)+"...",excludedModules:m.substring(0,50)+"...",whatsapp:v,whatsappMessage:g.substring(0,50)+"...",pix:b?"***":null});const y={"Cartão Virtual":"cartao_virtual",Carrossel:"carousel","Loja Virtual":"sales_page","King Forms":"digital_form",Portfólio:"portfolio",Banner:"banner","Gestão Financeira":"finance","King Selection":"king_selection","King Câmera":"king_camera","King Docs":"king_docs","Recibos e Orçamentos":"recibos_orcamentos","Personalização da Marca":"branding","Modo Empresa":"modo_empresa",Localização:"location"},E=await r.safeFetch(`${r.API_URL}/api/subscription/plans?t=${Date.now()}`,{method:"GET",headers:{...r.HEADERS_AUTH,"Cache-Control":"no-cache"}});if(!E.ok)throw new Error("Erro ao buscar dados do plano atual");const _=(await E.json()).plans.find(x=>x.id===e);if(!_)throw new Error(`Plano com ID ${e} não encontrado!`);const k=_.features||{},F=_.plan_code;i(`Y"< Plano encontrado: ${_.plan_name} (${F})`);const d={...k,can_edit_logo:f},p={plan_name:o,price:a,description:t,features:d,whatsapp_number:v||null,whatsapp_message:g||null,pix_key:b||null,included_modules:l||"",excluded_modules:m||""};i("Enviando dados do plano (com módulos):",{plan_name:p.plan_name,price:p.price,description:p.description?.substring(0,50)+"...",included_modules:p.included_modules||"(vazio)",excluded_modules:p.excluded_modules||"(vazio)",included_modules_length:p.included_modules?.length||0,excluded_modules_length:p.excluded_modules?.length||0}),i('Y"< Módulos incluídos (completo):',l),i('Y"< Módulos não incluídos (completo):',m);const h=await r.safeFetch(`${r.API_URL}/api/subscription/plans/${e}`,{method:"PUT",headers:{...r.HEADERS_AUTH,"Content-Type":"application/json"},body:JSON.stringify(p)});if(i("Resposta recebida:",h.status,h.statusText),!h.ok){const x=await h.text();throw new Error(`Erro ao salvar plano: ${h.status} - ${x}`)}const P=await h.json();if(i("Plano salvo com sucesso:",P),P.modulesUpdated)i("Módulos incluídos e não incluídos foram salvos junto com o plano!");else if((l||m)&&(i("Módulos foram enviados, mas não foram processados. Verificando se precisa de atualização separada..."),F))try{const x=l.split(",").map(u=>u.trim()).filter(u=>u),A=m.split(",").map(u=>u.trim()).filter(u=>u),$=new Set(x),w=new Set(A),C=[];Object.keys(y).forEach(u=>{const c=y[u];c&&($.has(u)?C.push({module_type:c,plan_code:F,is_available:!0}):w.has(u)&&C.push({module_type:c,plan_code:F,is_available:!1}))}),C.length>0&&(i(" Tentando atualizar módulos via endpoint separado (fallback)..."),(await r.safeFetch(`${r.API_URL}/api/modules/plan-availability`,{method:"PUT",headers:{...r.HEADERS_AUTH,"Content-Type":"application/json"},body:JSON.stringify({updates:C})})).ok&&i("Módulos atualizados via fallback"))}catch{}i("⏳ Aguardando processamento do banco (3 segundos)..."),await new Promise(x=>setTimeout(x,3e3)),i("Aguardamento concluído. Dados devem estar disponíveis no banco."),alert("Plano atualizado com sucesso!"),i(" Recarregando formulário de edição...");const T=document.getElementById(`plan-included-modules-${e}`),Y=document.getElementById(`plan-excluded-modules-${e}`),H=T?T.value.trim():"",z=Y?Y.value.trim():"";i("Valores preservados antes de recarregar:"),i(`   Incluídos: "${H}"`),i(`   Não incluídos: "${z}"`);try{const x=Date.now();i(` Forçando recarregamento sem cache (timestamp: ${x})...`),window.moduleAvailabilityCache&&delete window.moduleAvailabilityCache,await R(),await new Promise(w=>setTimeout(w,500));const A=document.getElementById(`plan-included-modules-${e}`),$=document.getElementById(`plan-excluded-modules-${e}`);if(A&&H){const w=A.value.trim(),C=H.split(",").map(c=>c.trim()).filter(c=>c),j=w.split(",").map(c=>c.trim()).filter(c=>c),u=[...new Set([...C,...j])];A.value=u.join(", "),i(`Valor restaurado em módulos incluídos: "${A.value}"`)}if($&&z){const w=$.value.trim(),C=z.split(",").map(c=>c.trim()).filter(c=>c),j=w.split(",").map(c=>c.trim()).filter(c=>c),u=[...new Set([...C,...j])];$.value=u.join(", "),i(`Valor restaurado em módulos não incluídos: "${$.value}"`)}i("Formulário recarregado. Verifique os campos acima."),A&&$&&(i('Y"< Valores finais nos campos:'),i(`   Incluídos: "${A.value}"`),i(`   Não incluídos: "${$.value}"`))}catch{alert("Plano salvo, mas houve erro ao recarregar. Atualize a página manualmente (F5).")}i(" Recarregando informações de assinatura...");try{await B()}catch{}i("Processo de salvamento concluído!")}catch(o){alert(`Erro ao salvar plano: ${o.message}

Verifique o console para mais detalhes.`)}};const O=document.getElementById("edit-plans-btn");O&&O.addEventListener("click",()=>{const e=document.getElementById("plans-edit-form");e.style.display==="none"?(e.style.display="block",R()):e.style.display="none"});const q=document.getElementById("assinatura-link");q&&q.addEventListener("click",()=>{setTimeout(()=>{B()},100)});var J={loadSubscriptionInfo:B,renderSubscriptionInfo:K,renderSubscriptionPlans:G,loadPlansForEdit:R};M.DashboardAssinatura=J,M.loadSubscriptionInfo=B})(typeof window<"u"?window:void 0);
