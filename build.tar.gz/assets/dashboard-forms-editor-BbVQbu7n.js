(function(u){function v(){return u.DashboardCore||{}}var l={get API_URL(){var r=v();return typeof r.getApiUrl=="function"?r.getApiUrl()||"":u.API_URL||u.API_BASE||""},get HEADERS(){var r=v();return typeof r.getHeaders=="function"?r.getHeaders()||{}:{"Content-Type":"application/json"}},get HEADERS_AUTH(){var r=v();return typeof r.getHeadersAuth=="function"?r.getHeadersAuth()||{}:{}},safeFetch:function(r,i){var t=v();return typeof t.safeFetch=="function"?t.safeFetch(r,i):fetch(r,i)}};window.renderFormQuestions=function(i,t){const o=document.getElementById(`form-questions-container-${i}`);if(o){if(!t||t.length===0){o.innerHTML=`
            <div style="text-align: center; padding: 40px; color: var(--text-dark, #A1A1A1);">
                <i class="fas fa-question-circle" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <p>Nenhuma pergunta adicionada ainda.</p>
                <p style="font-size: 0.9rem; margin-top: 10px;">Clique em "Adicionar Pergunta" para começar.</p>
            </div>
        `;return}o.innerHTML=t.map((a,n)=>{const e={short_text:"Resposta Curta",paragraph:"Parágrafo",multiple_choice:"Escolha Múltipla",checkbox:"Caixa de Verificação",dropdown:"Lista Suspensa",file_upload:"Carregar Ficheiro",linear_scale:"Escala Linear",rating:"Classificação",multiple_choice_grid:"Grelha de Escolhas Múltiplas",checkbox_grid:"Grelha de Caixa de Verificação",date:"Data",time:"Hora",datetime:"Data e Hora",yes_no:"Sim/Não"};return`
            <div class="form-question-item" data-question-index="${n}" style="margin-bottom: 20px; padding: 20px; background: var(--card-background-color, #1C1C21); border-radius: 8px; border: 1px solid var(--border-color, #2C2C2F);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <div>
                        <strong style="color: var(--text, #ECECEC);">${a.label||"Pergunta sem título"}</strong>
                        <span style="margin-left: 10px; font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">(${e[a.type]||a.type})</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" class="edit-question-btn" data-index="${n}" style="padding: 5px 10px; background: var(--dourado-principal, #FFC700); color: #000; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="delete-question-btn" data-index="${n}" style="padding: 5px 10px; background: #ff4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                ${a.required?'<span style="color: #ff4444; font-size: 0.85rem;">* Obrigatório</span>':""}
            </div>
        `}).join(""),o.querySelectorAll(".edit-question-btn").forEach(a=>{a.addEventListener("click",()=>{const n=parseInt(a.dataset.index);t[n]})}),o.querySelectorAll(".delete-question-btn").forEach(a=>{a.addEventListener("click",()=>{const n=parseInt(a.dataset.index);h(i,n)})})}};function f(r){const i=[{value:"short_text",label:"Resposta Curta"},{value:"paragraph",label:"Parágrafo"},{value:"multiple_choice",label:"Escolha Múltipla"},{value:"checkbox",label:"Caixa de Verificação"},{value:"dropdown",label:"Lista Suspensa"},{value:"file_upload",label:"Carregar Ficheiro"},{value:"linear_scale",label:"Escala Linear"},{value:"rating",label:"Classificação"},{value:"multiple_choice_grid",label:"Grelha de Escolhas Múltiplas"},{value:"checkbox_grid",label:"Grelha de Caixa de Verificação"},{value:"date",label:"Data"},{value:"time",label:"Hora"},{value:"datetime",label:"Data e Hora"},{value:"yes_no",label:"Sim/Não"}],t=document.createElement("div");t.className="question-modal",t.style.cssText="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 10000; display: flex; align-items: center; justify-content: center;",t.innerHTML=`
        <div style="background: var(--card-background-color, #1C1C21); padding: 30px; border-radius: 12px; max-width: 600px; width: 90%; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin-bottom: 20px; color: var(--text, #ECECEC);">Adicionar Pergunta</h3>
            <div class="input-group" style="margin-bottom: 15px;">
                <label>Tipo de Campo</label>
                <select id="new-question-type" style="width: 100%; padding: 10px; border-radius: 8px; background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); color: var(--text, #ECECEC);">
                    ${i.map(e=>`<option value="${e.value}">${e.label}</option>`).join("")}
                </select>
            </div>
            <div class="input-group" style="margin-bottom: 15px;">
                <label>Pergunta/Label</label>
                <input type="text" id="new-question-label" placeholder="Digite a pergunta..." style="width: 100%; padding: 10px; border-radius: 8px; background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); color: var(--text, #ECECEC);">
            </div>
            <div class="input-group" style="margin-bottom: 15px;">
                <label>
                    <input type="checkbox" id="new-question-required"> Obrigatório
                </label>
            </div>
            <div id="new-question-options-container" style="display: none; margin-bottom: 15px;">
                <label>Opções (uma por linha)</label>
                <textarea id="new-question-options" rows="5" placeholder="Opção 1&#10;Opção 2&#10;Opção 3" style="width: 100%; padding: 10px; border-radius: 8px; background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); color: var(--text, #ECECEC);"></textarea>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" class="cancel-question-btn" style="padding: 10px 20px; background: #666; color: white; border: none; border-radius: 8px; cursor: pointer;">Cancelar</button>
                <button type="button" class="save-question-btn" style="padding: 10px 20px; background: var(--dourado-principal, #FFC700); color: #000; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Salvar</button>
            </div>
        </div>
    `,document.body.appendChild(t);const o=t.querySelector("#new-question-type"),a=t.querySelector("#new-question-options-container"),n=["multiple_choice","checkbox","dropdown","multiple_choice_grid","checkbox_grid"];o.addEventListener("change",()=>{a.style.display=n.includes(o.value)?"block":"none"}),t.querySelector(".save-question-btn").addEventListener("click",()=>{const e=o.value,s=t.querySelector("#new-question-label").value.trim(),d=t.querySelector("#new-question-required").checked,g=t.querySelector("#new-question-options").value.trim();if(!s){alert("Por favor, digite a pergunta.");return}const c={type:e,label:s,required:d,id:"field_"+Date.now()};n.includes(e)&&g&&(c.options=g.split(`
`).filter(m=>m.trim()).map(m=>m.trim()));const x=document.querySelector(`#edit-item-modal[data-editing-id="${r}"] #edit-digital-form-fields`);let p=[];if(x&&x.value)try{p=JSON.parse(x.value)}catch{p=[]}p.push(c),x.value=JSON.stringify(p),renderFormQuestions(r,p),document.body.removeChild(t)}),t.querySelector(".cancel-question-btn").addEventListener("click",()=>{document.body.removeChild(t)}),t.addEventListener("click",e=>{e.target===t&&document.body.removeChild(t)})}function A(r,i,t){}function h(r,i){if(!confirm("Tem certeza que deseja remover esta pergunta?"))return;const t=document.querySelector(`#edit-item-modal[data-editing-id="${r}"] #edit-digital-form-fields`);let o=[];if(t&&t.value)try{o=JSON.parse(t.value)}catch{o=[]}o.splice(i,1),t.value=JSON.stringify(o),renderFormQuestions(r,o)}window.loadFormResponses=async function(i){const t=document.getElementById(`form-responses-dashboard-${i}`);if(t)try{l.HEADERS=getHeaders();const o=await fetch(`${l.API_URL}/api/profile/digital-forms/${i}/responses`,{headers:l.HEADERS});if(!o.ok)throw new Error("Erro ao carregar respostas");const a=await o.json();if(!a.success||!a.responses||a.responses.length===0){t.innerHTML=`
                <div style="text-align: center; padding: 40px; color: var(--text-dark, #A1A1A1);">
                    <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                    <p>Nenhuma resposta ainda.</p>
                </div>
            `;return}const n=a.statistics||{};t.innerHTML=`
            <div style="margin-bottom: 30px;">
                <h3 style="color: var(--text, #ECECEC); margin-bottom: 20px;">Estatísticas</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;">
                    <div style="padding: 20px; background: var(--card-background-color, #1C1C21); border-radius: 8px; border: 1px solid var(--border-color, #2C2C2F);">
                        <div style="font-size: 2rem; font-weight: 600; color: var(--dourado-principal, #FFC700);">${n.total_responses||0}</div>
                        <div style="color: var(--text-dark, #A1A1A1); margin-top: 5px;">Total de Respostas</div>
                    </div>
                    <div style="padding: 20px; background: var(--card-background-color, #1C1C21); border-radius: 8px; border: 1px solid var(--border-color, #2C2C2F);">
                        <div style="font-size: 2rem; font-weight: 600; color: var(--dourado-principal, #FFC700);">${n.unique_responders||0}</div>
                        <div style="color: var(--text-dark, #A1A1A1); margin-top: 5px;">Respondentes nicos</div>
                    </div>
                </div>
            </div>
            <div>
                <h3 style="color: var(--text, #ECECEC); margin-bottom: 20px;">Respostas Recebidas</h3>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    ${a.responses.map((e,s)=>{const d=typeof e.response_data=="string"?JSON.parse(e.response_data):e.response_data;return`
                            <div style="padding: 20px; background: var(--card-background-color, #1C1C21); border-radius: 8px; border: 1px solid var(--border-color, #2C2C2F);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                    <strong style="color: var(--text, #ECECEC);">Resposta #${s+1}</strong>
                                    <span style="font-size: 0.85rem; color: var(--text-dark, #A1A1A1);">${new Date(e.submitted_at).toLocaleString("pt-BR")}</span>
                                </div>
                                ${e.responder_name?`<div style="margin-bottom: 5px;"><strong>Nome:</strong> ${e.responder_name}</div>`:""}
                                ${e.responder_phone?`<div style="margin-bottom: 5px;"><strong>Telefone:</strong> ${e.responder_phone}</div>`:""}
                                ${e.responder_email?`<div style="margin-bottom: 5px;"><strong>Email:</strong> ${e.responder_email}</div>`:""}
                                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color, #2C2C2F);">
                                    <strong style="color: var(--text, #ECECEC); display: block; margin-bottom: 10px;">Respostas:</strong>
                                    ${Object.entries(d).map(([g,c])=>`
                                        <div style="margin-bottom: 8px;">
                                            <strong style="color: var(--text-dark, #A1A1A1);">${g}:</strong>
                                            <span style="color: var(--text, #ECECEC); margin-left: 10px;">${Array.isArray(c)?c.join(", "):c}</span>
                                        </div>
                                    `).join("")}
                                </div>
                            </div>
                        `}).join("")}
                </div>
            </div>
        `}catch(o){t.innerHTML=`
            <div style="text-align: center; padding: 40px; color: #ff4444;">
                <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 15px;"></i>
                <p>Erro ao carregar respostas: ${o.message}</p>
            </div>
        `}},document.addEventListener("click",r=>{if(r.target.closest(".add-question-btn")){const t=r.target.closest(".add-question-btn").dataset.itemId;t&&f(parseInt(t))}if(r.target.closest(".btn-edit-form-page")){const i=r.target.closest(".btn-edit-form-page"),t=i.dataset.itemId||i.dataset.id;t?window.location.href=`/formPageEdit?itemId=${t}`:alert("Erro: ID do formulário não encontrado. Por favor, recarregue a página e tente novamente.")}});async function b(){const r=document.getElementById("guest-lists-container"),i=document.getElementById("guest-list-stats");if(r)try{const t=await l.safeFetch(`${l.API_URL}/api/guest-lists`,{method:"GET",headers:l.HEADERS_AUTH});if(!t.ok)throw new Error("Erro ao carregar listas de convidados");const o=await t.json(),a=o.map(e=>{const s=parseInt(e.registered_count||0)+parseInt(e.confirmed_count||0)+parseInt(e.checked_in_count||0);return e.stats={total:s,registered:parseInt(e.registered_count||0),confirmed:parseInt(e.confirmed_count||0),checked_in:parseInt(e.checked_in_count||0)},e.profile_item_id=e.id,e}),n=a.reduce((e,s)=>{const d=s.stats||{total:0,registered:0,confirmed:0,checked_in:0};return e.total+=d.total||0,e.registered+=d.registered||0,e.confirmed+=d.confirmed||0,e.checked_in+=d.checked_in||0,e},{total:0,registered:0,confirmed:0,checked_in:0});if(i&&(i.innerHTML=`
                <div class="stat-card" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 20px; text-align: center;">
                    <div class="stat-value" style="font-size: 32px; font-weight: 800; color: var(--dourado-principal, #FFC700); margin: 8px 0;">${o.length}</div>
                    <div class="stat-label" style="color: var(--text-dark, #A1A1A1); font-size: 14px;">Listas Criadas</div>
                </div>
                <div class="stat-card" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 20px; text-align: center;">
                    <div class="stat-value" style="font-size: 32px; font-weight: 800; color: var(--dourado-principal, #FFC700); margin: 8px 0;">${n.total}</div>
                    <div class="stat-label" style="color: var(--text-dark, #A1A1A1); font-size: 14px;">Total de Convidados</div>
                </div>
                <div class="stat-card" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 20px; text-align: center;">
                    <div class="stat-value" style="font-size: 32px; font-weight: 800; color: #4CAF50; margin: 8px 0;">${n.confirmed}</div>
                    <div class="stat-label" style="color: var(--text-dark, #A1A1A1); font-size: 14px;">Confirmados</div>
                </div>
                <div class="stat-card" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 20px; text-align: center;">
                    <div class="stat-value" style="font-size: 32px; font-weight: 800; color: #2196F3; margin: 8px 0;">${n.checked_in}</div>
                    <div class="stat-label" style="color: var(--text-dark, #A1A1A1); font-size: 14px;">Conferidos</div>
                </div>
            `),a.length===0){r.innerHTML=`
                <div class="empty-state" style="text-align: center; padding: 60px 20px; color: var(--text-dark, #A1A1A1);">
                    <i class="fas fa-users" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
                    <p style="font-size: 16px; margin-bottom: 8px;">Nenhuma lista de convidados criada ainda</p>
                    <p style="font-size: 14px; opacity: 0.7;">Clique em "Nova Lista" para começar</p>
                </div>
            `;return}r.innerHTML=a.map(e=>{const s=e.stats||{total:0,registered:0,confirmed:0,checked_in:0},d=e.event_date?new Date(e.event_date).toLocaleDateString("pt-BR"):"Não definido";return`
                <div class="module-item" data-id="${e.profile_item_id||e.id}" data-item-type="guest_list" style="background: var(--card-background-color, #1C1C21); border: 1px solid var(--border-color, #2C2C2F); border-radius: 12px; padding: 20px; margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px;">
                        <div style="flex: 1;">
                            <h4 style="color: var(--text, #ECECEC); margin: 0 0 8px 0; font-size: 18px;">
                                <i class="fas fa-users" style="color: var(--dourado-principal, #FFC700); margin-right: 8px;"></i>
                                ${e.event_title||e.title||"Lista de Convidados"}
                            </h4>
                            <p style="color: var(--text-dark, #A1A1A1); margin: 0; font-size: 14px;">
                                <i class="fas fa-calendar" style="margin-right: 6px;"></i>
                                ${d}
                            </p>
                            ${e.event_location?`
                                <p style="color: var(--text-dark, #A1A1A1); margin: 4px 0 0 0; font-size: 14px;">
                                    <i class="fas fa-map-marker-alt" style="margin-right: 6px;"></i>
                                    ${e.event_location}
                                </p>
                            `:""}
                        </div>
                        <button class="btn-icon" onclick="openGuestListEditor(${e.profile_item_id||e.id})" style="background: var(--dourado-principal, #FFC700); color: #000; border: none; padding: 10px 16px; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            <i class="fas fa-edit"></i> Gerenciar
                        </button>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--border-color, #2C2C2F);">
                        <div style="text-align: center;">
                            <div style="font-size: 24px; font-weight: 800; color: var(--dourado-principal, #FFC700);">${s.total}</div>
                            <div style="font-size: 12px; color: var(--text-dark, #A1A1A1);">Total</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 24px; font-weight: 800; color: #4CAF50;">${s.confirmed}</div>
                            <div style="font-size: 12px; color: var(--text-dark, #A1A1A1);">Confirmados</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 24px; font-weight: 800; color: #2196F3;">${s.checked_in}</div>
                            <div style="font-size: 12px; color: var(--text-dark, #A1A1A1);">Conferidos</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 24px; font-weight: 800; color: #FF9800;">${s.registered-s.confirmed}</div>
                            <div style="font-size: 12px; color: var(--text-dark, #A1A1A1);">Pendentes</div>
                        </div>
                    </div>
                </div>
            `}).join("")}catch{r&&(r.innerHTML=`
                <div class="empty-state" style="text-align: center; padding: 60px 20px; color: var(--text-dark, #A1A1A1);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 16px; color: #FF9800;"></i>
                    <p style="font-size: 16px; margin-bottom: 8px;">Erro ao carregar listas de convidados</p>
                    <p style="font-size: 14px; opacity: 0.7;">Tente recarregar a página</p>
                </div>
            `)}}function y(r){window.location.href=`/guestListEdit?itemId=${r}`}const C=document.getElementById("add-guest-list-btn");C&&C.addEventListener("click",async()=>{SELECTORS.addItemModal.classList.add("active"),await filterModulesByPlan(),setTimeout(()=>{const r=document.querySelector('[data-item-type="guest_list"]');r&&(r.scrollIntoView({behavior:"smooth",block:"center"}),r.style.border="2px solid var(--dourado-principal, #FFC700)",setTimeout(()=>{r.style.border=""},2e3))},300)});var E={renderFormQuestions:typeof renderFormQuestions=="function"?renderFormQuestions:null,addQuestion:typeof f=="function"?f:null,loadGuestLists:typeof b=="function"?b:null,openGuestListEditor:typeof y=="function"?y:null};u.DashboardFormsEditor=E})(typeof window<"u"?window:void 0);
