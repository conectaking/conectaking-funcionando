<?php

namespace App\Http\Middleware;

use App\Support\AuthCookieDomain;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Response;

/**
 * CSRF double-submit para sessões cookie-first (token / ks_client_token).
 * Clientes com Authorization Bearer real ficam isentos.
 */
class RequireCookieCsrf
{
    public const COOKIE = 'ck_csrf';

    public const HEADER = 'X-CK-CSRF';

    public function handle(Request $request, Closure $next): Response
    {
        if (! in_array(strtoupper($request->method()), ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            return $next($request);
        }

        // Cookie de sessão presente → exigir CSRF (mesmo com Bearer no LS — evita bypass com JWT stale).
        if (! $this->hasAuthCookie($request)) {
            return $next($request);
        }

        // Endpoints públicos de auth (ainda sem cookie válido de CSRF no login)
        $path = ltrim($request->path(), '/');
        if ($this->isAuthBootstrapPath($path)) {
            return $next($request);
        }

        $cookie = (string) $request->cookie(self::COOKIE, '');
        $ckHeader = (string) $request->header(self::HEADER, '');

        // Double-submit ck_csrf
        if ($cookie !== '' && $ckHeader !== '' && hash_equals($cookie, $ckHeader)) {
            return $next($request);
        }

        // Laravel nativo (X-XSRF-TOKEN / _token) — NÃO comparar com ck_csrf.
        // Deixa o VerifyCsrfToken validar.
        if ($request->headers->has('X-XSRF-TOKEN')
            || $request->headers->has('X-CSRF-TOKEN')
            || $request->input('_token')) {
            return $next($request);
        }

        if ($cookie === '') {
            return response()->json([
                'success' => false,
                'message' => 'CSRF ausente. Recarregue a página e tente novamente.',
            ], 419)
                ->header('X-Conecta-Engine', 'laravel')
                ->withCookie(self::makeCookie($request));
        }

        return response()->json([
            'success' => false,
            'message' => 'CSRF inválido. Recarregue a página e tente novamente.',
        ], 419)->header('X-Conecta-Engine', 'laravel');
    }

    public static function makeCookie(Request $request, ?string $value = null, int $minutes = 60 * 24): Cookie
    {
        $token = $value !== null && $value !== '' ? $value : Str::random(40);

        return Cookie::create(
            self::COOKIE,
            $token,
            time() + ($minutes * 60),
            '/',
            AuthCookieDomain::forRequest($request),
            $request->isSecure(),
            false, // legível pelo JS (double-submit)
            false,
            Cookie::SAMESITE_LAX
        );
    }

    public static function forgetCookie(Request $request): Cookie
    {
        return Cookie::create(
            self::COOKIE,
            '',
            1,
            '/',
            AuthCookieDomain::forRequest($request),
            $request->isSecure(),
            false,
            false,
            Cookie::SAMESITE_LAX
        );
    }

    private function hasAuthCookie(Request $request): bool
    {
        $token = $request->cookie('token');
        $ks = $request->cookie('ks_client_token');

        return (is_string($token) && $token !== '') || (is_string($ks) && $ks !== '');
    }

    private function isAuthBootstrapPath(string $path): bool
    {
        $exact = [
            'api/auth/login',
            'api/auth/refresh',
            'api/auth/logout',
            'api/auth/register',
            'api/auth/sync-session-cookie',
            'api/password/forgot',
            'api/password/reset',
            'api/king-selection/client/login',
            'api/king-selection/client/login-by-details',
            'api/king-selection/client/register',
            'api/king-selection/client/public-enter',
            'api/king-selection/client/signup-enter',
            'api/king-selection/client/clear-session-cookie',
            'api/king-selection/client/redeem-access',
            'api/king-selection/public/enroll-face-anonymous',
            // Beacons públicos (visitante pode ter cookie de sessão do painel)
            'api/bible/prosperidade/mark-read',
            'api/bible/devotional/mark-read',
            'api/bible/mark-read',
            'api/bible/reset-progress',
            'guest-list/confirm/cpf',
            'api/inquiry/submit',
            'api/cameras/telegram-webhook',
        ];
        if (in_array($path, $exact, true)) {
            return true;
        }

        $prefixes = [
            'log/',
            'api/guest-lists/public/register/',
            'api/guest-lists/public/confirm/',
            'portaria/',
            'guest-list/view-full/',
            'guest-list/confirm/qr/',
            // Formulários públicos via token de acesso direto
            'form/',
        ];
        foreach ($prefixes as $prefix) {
            if (str_starts_with($path, $prefix)) {
                return true;
            }
        }

        // Formulário público: /{slug}/form/{itemId}/submit
        // Visitante pode ter cookie de auth do painel no mesmo dispositivo.
        if (preg_match('#(^|/)form/\d+/submit/?$#i', $path) === 1 || (str_contains($path, '/form/') && str_ends_with($path, '/submit'))) {
            return true;
        }

        return false;
    }
}
