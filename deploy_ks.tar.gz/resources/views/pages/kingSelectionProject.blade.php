<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />
  <title>KingSelection - Projeto</title>
  <link rel="icon" type="image/png" href="https://i.ibb.co/60sW9k75/logo.png">
  <link rel="apple-touch-icon" href="https://i.ibb.co/60sW9k75/logo.png">
  <script src="/config.js?v=2026-09-10-apex1"></script>
  @vite(['resources/css/fontawesome.css', 'resources/css/app.css', 'resources/js/pages/kingSelectionProject.js'])
  <style>
    :root {
      --ks-primary: #f59e0b;
      --ks-primary-dark: #d97706;
      --ks-accent: #f59e0b;
      --ks-bg: #f1f5f9;
      --ks-card: #ffffff;
      --ks-card-subtle: #f8fafc;
      --ks-line: #e2e8f0;
      --ks-line-subtle: #f1f5f9;
      --ks-muted: #64748b;
      --ks-text: #0f172a;
      --ks-text-muted: #64748b;
    }

    html, body {
      background-color: #f1f5f9 !important;
      color: #0f172a !important;
      font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, sans-serif;
      margin: 0;
    }

    body:before, body:after {
      display: none !important;
    }

    .hidden, [hidden] {
      display: none !important;
    }

    #ks-preloader {
      position: fixed;
      inset: 0;
      background: #f1f5f9;
      z-index: 99999999;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 18px;
      transition: opacity 0.25s ease-out, visibility 0.25s ease-out;
    }
    #ks-preloader.ks-loaded {
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
    }
    .ks-spinner {
      width: 42px;
      height: 42px;
      border: 3px solid rgba(245, 158, 11, 0.2);
      border-top-color: #f59e0b;
      border-radius: 50%;
      animation: ks-spin 0.8s linear infinite;
    }
    @keyframes ks-spin {
      to { transform: rotate(360deg); }
    }

    /* Conecta King Luxury Dark & Gold Header */
    .ks-top {
      background: linear-gradient(135deg, #060709 0%, #0e0f14 50%, #15120c 100%) !important;
      border-bottom: 1px solid rgba(245, 158, 11, 0.28) !important;
      box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.85), 0 1px 0 0 rgba(245, 158, 11, 0.18) !important;
      color: #f8fafc !important;
    }
    .ks-nav a {
      color: #94a3b8 !important;
      font-weight: 700;
      border-radius: 8px;
      padding: 6px 12px;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      font-size: 11px;
      transition: all 0.15s ease;
    }
    .ks-nav a:hover {
      color: #ffffff !important;
      background: rgba(255, 255, 255, 0.08) !important;
    }
    .ks-nav a.active {
      color: #fbbf24 !important;
      background: rgba(245, 158, 11, 0.14) !important;
      border-color: rgba(245, 158, 11, 0.3) !important;
      box-shadow: none !important;
    }

    .ks-card {
      background: #ffffff !important;
      border: 1px solid #e2e8f0 !important;
      border-radius: 16px !important;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05) !important;
      color: #0f172a !important;
      backdrop-filter: none !important;
      -webkit-backdrop-filter: none !important;
    }
    .ks-card:before {
      display: none !important;
    }

    .ks-side a {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 12px;
      font-weight: 600;
      font-size: 13px;
      color: #475569 !important;
      border: 1px solid transparent;
      transition: all .15s ease;
    }
    .ks-side a:hover {
      background: #f8fafc !important;
      color: #0f172a !important;
      border-color: #e2e8f0 !important;
    }
    .ks-side a.active {
      background: #fffbeb !important;
      color: #b45309 !important;
      border-color: #fde68a !important;
      font-weight: 700 !important;
      box-shadow: 0 1px 2px rgba(245, 158, 11, 0.08) !important;
    }

    /* Action Buttons Seja Fit */
    .ks-btn {
      border: 1px solid #cbd5e1 !important;
      border-radius: 12px !important;
      padding: 9px 16px !important;
      font-weight: 700 !important;
      background: #ffffff !important;
      color: #334155 !important;
      transition: all .18s ease;
      text-transform: uppercase;
      letter-spacing: .05em;
      font-size: 11px !important;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
    }
    .ks-btn:hover {
      background: #f8fafc !important;
      color: #0f172a !important;
      border-color: #94a3b8 !important;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
    }
    .ks-btn:active {
      transform: translateY(0);
    }
    .ks-btn-primary {
      background: linear-gradient(135deg, #f59e0b, #d97706) !important;
      color: #ffffff !important;
      border: none !important;
      box-shadow: 0 4px 12px rgba(245, 158, 11, 0.28) !important;
    }
    .ks-btn-primary:hover {
      filter: brightness(1.05) !important;
      box-shadow: 0 6px 16px rgba(245, 158, 11, 0.38) !important;
    }
    #ks-delete-project {
      background: #fef2f2 !important;
      border: 1px solid #fecaca !important;
      color: #dc2626 !important;
    }
    #ks-delete-project:hover {
      background: #fee2e2 !important;
      border-color: #fca5a5 !important;
      color: #b91c1c !important;
    }

    /* Restore native Tailwind light text */
    .text-slate-900 { color: #0f172a !important; }
    .text-slate-800 { color: #1e293b !important; }
    .text-slate-700 { color: #334155 !important; }
    .text-slate-600 { color: #475569 !important; }
    .text-slate-500 { color: #64748b !important; }
    .text-slate-400 { color: #94a3b8 !important; }
    .ks-muted { color: #64748b !important; }

    .bg-white { background-color: #ffffff !important; }
    .bg-slate-50 { background-color: #f8fafc !important; }
    .border-slate-200 { border-color: #e2e8f0 !important; }
    .border-slate-100 { border-color: #f1f5f9 !important; }

    /* Inputs */
    .ks-input {
      background: #ffffff !important;
      border: 1px solid #cbd5e1 !important;
      color: #0f172a !important;
      border-radius: 12px !important;
    }
    .ks-input::placeholder {
      color: #94a3b8 !important;
    }
    .ks-input:focus {
      border-color: #f59e0b !important;
      box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15) !important;
    }
    .ks-field label {
      color: #475569 !important;
      font-weight: 700;
      letter-spacing: .12em;
    }

    /* Activity (Atividades do cliente) Seja Fit */
    .ks-abo-card {
      background: #ffffff !important;
      border: 1px solid #e2e8f0 !important;
      border-radius: 16px !important;
      box-shadow: 0 1px 3px rgba(0,0,0,0.04) !important;
    }
    .ks-abo-head {
      background: #ffffff !important;
      border-bottom: 1px solid #f1f5f9 !important;
    }
    .ks-abo-title {
      color: #0f172a !important;
      font-weight: 800;
      letter-spacing: .08em;
    }
    .ks-abo-search {
      background: #ffffff !important;
      border-bottom: 1px solid #f1f5f9 !important;
    }
    .ks-abo-search input {
      background: #f8fafc !important;
      border: 1px solid #e2e8f0 !important;
      color: #0f172a !important;
      border-radius: 12px !important;
    }
    .ks-abo-search i {
      color: #94a3b8 !important;
    }
    .ks-abo-item {
      background: #ffffff !important;
      border: 1px solid #e2e8f0 !important;
      color: #0f172a !important;
      border-radius: 14px !important;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03) !important;
      transition: all 0.15s ease;
    }
    .ks-abo-item:hover {
      background: #f8fafc !important;
      border-color: #cbd5e1 !important;
    }
    .ks-abo-item.active {
      background: #fffdf5 !important;
      border-color: #f59e0b !important;
      box-shadow: 0 2px 8px rgba(245, 158, 11, 0.12) !important;
    }
    .ks-abo-item-name {
      color: #0f172a !important;
      font-weight: 800;
    }
    .ks-abo-item-email {
      color: #64748b !important;
    }
    .ks-abo-badge {
      background: #fef3c7 !important;
      color: #92400e !important;
      border: 1px solid #fde68a !important;
      font-weight: 800 !important;
      border-radius: 999px !important;
    }

    /* Buttons inside Activity */
    #ks-activity-finish {
      background: #10b981 !important;
      color: #ffffff !important;
      border: none !important;
      font-weight: 800 !important;
      border-radius: 12px !important;
      box-shadow: 0 2px 6px rgba(16, 185, 129, 0.25) !important;
    }
    #ks-activity-finish:hover {
      background: #059669 !important;
    }
    #ks-activity-new {
      background: #f59e0b !important;
      color: #ffffff !important;
      border: none !important;
      font-weight: 800 !important;
      border-radius: 12px !important;
      box-shadow: 0 2px 6px rgba(245, 158, 11, 0.25) !important;
    }
    #ks-activity-new:hover {
      background: #d97706 !important;
    }
    #ks-open-export {
      background: #ffffff !important;
      border: 1px solid #cbd5e1 !important;
      color: #334155 !important;
      border-radius: 12px !important;
    }
    #ks-open-export:hover {
      background: #f8fafc !important;
      color: #0f172a !important;
    }
    #ks-act-whatsapp-lead {
      background: #ecfdf5 !important;
      border: 1px solid #a7f3d0 !important;
      color: #047857 !important;
      border-radius: 999px !important;
      font-weight: 700 !important;
    }

    /* Hamburger & Retractable Sidebar */
    #ks-sidebar {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    #ks-main-content {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    #ks-main-container.ks-sidebar-collapsed #ks-sidebar {
      margin-left: -19rem;
      margin-right: -1.5rem;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    #ks-main-container.ks-sidebar-collapsed #ks-main-content {
      width: 100%;
      max-width: 100%;
    }
    @media (max-width: 1024px) {
      #ks-main-container {
        flex-direction: column;
      }
      #ks-sidebar {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
      }
      #ks-main-container.ks-sidebar-collapsed #ks-sidebar {
        display: none;
      }
    }
  </style>
</head>

<body>
  <div id="ks-preloader" aria-label="Carregando...">
    <img src="https://i.ibb.co/60sW9k75/logo.png" alt="Conecta King" style="width: 54px; height: 54px; object-fit: contain;">
    <div class="ks-spinner"></div>
  </div>
  <div class="ks-top">
    <div class="ks-wrap flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-2.5">
      <div class="flex items-center gap-3">
        <!-- Botão Hambúrguer Conecta King (Preto com Dourado) -->
        <button id="ks-btn-hamburger" type="button"
          class="p-2 rounded-xl text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition flex items-center justify-center cursor-pointer shadow-xs"
          title="Alternar Menu Lateral (Hambúrguer)" aria-label="Menu Lateral">
          <svg class="w-6 h-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </button>

        <a href="/kingSelection" class="flex items-center gap-2.5 text-white no-underline group">
          <div class="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center p-1 shadow-xs group-hover:border-amber-400/50 transition">
            <img src="https://i.ibb.co/60sW9k75/logo.png" alt="Conecta King" class="w-full h-full object-contain" />
          </div>
          <span class="font-black text-lg tracking-tight bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500 bg-clip-text text-transparent drop-shadow-xs">KingSelection</span>
        </a>
      </div>
      <!-- Lado Direito: Storage Meter Widget e Avatar do Usuário -->
      <div class="flex items-center gap-3 text-sm">
        <!-- Storage Meter Badge do Fotógrafo -->
        <div id="ks-storage-pill" class="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 border border-amber-500/35 text-xs shadow-xs" title="Consumo de Armazenamento do seu Plano">
          <i class="fas fa-database text-amber-400 text-xs"></i>
          <div class="flex flex-col text-[11px] leading-tight">
            <span class="font-bold text-amber-100 flex items-center gap-1.5" id="ks-storage-label">
              <span id="ks-storage-used">0.0 GB</span> / <span id="ks-storage-limit">20 GB</span>
              <span class="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-extrabold" id="ks-storage-plan-tag">20 GB</span>
            </span>
            <div class="w-24 sm:w-28 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-0.5 border border-white/5">
              <div id="ks-storage-progress" class="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-300 rounded-full transition-all duration-500" style="width: 0%;"></div>
            </div>
          </div>
        </div>

        <div class="relative" id="ks-user-menu-container" style="position: relative;">
          <button id="ks-user-avatar-btn" type="button"
            style="display: flex; align-items: center; gap: 8px; padding: 4px 12px 4px 5px; border-radius: 9999px; background: rgba(0, 0, 0, 0.75); border: 1px solid rgba(245, 158, 11, 0.35); cursor: pointer; transition: all 0.2s;"
            title="Meu Perfil e Configurações">
            <div style="width: 28px; height: 28px; border-radius: 9999px; overflow: hidden; background: rgba(245, 158, 11, 0.2); border: 1px solid rgba(245, 158, 11, 0.5); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
              <img id="ks-user-avatar-img" src="" alt="Avatar" style="width: 100%; height: 100%; object-fit: cover; display: none;" />
              <span id="ks-user-avatar-initials" style="font-weight: 900; color: #fbbf24; font-size: 11px;">CK</span>
            </div>
            <span id="ks-user-name-display" style="font-weight: 800; font-size: 11px; color: rgba(253, 230, 138, 0.95); letter-spacing: 0.05em; max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Perfil</span>
            <i class="fas fa-chevron-down" style="font-size: 10px; color: rgba(245, 158, 11, 0.8);"></i>
          </button>

          <!-- Dropdown do Avatar -->
          <div id="ks-user-dropdown" style="display: none; position: absolute; right: 0; top: calc(100% + 8px); width: 230px; border-radius: 16px; background: #0f1016; border: 1px solid rgba(245, 158, 11, 0.3); box-shadow: 0 10px 30px rgba(0,0,0,0.7); padding: 8px; z-index: 99999;">
            <div style="padding: 10px 12px; border-bottom: 1px solid rgba(255, 255, 255, 0.08); margin-bottom: 6px; display: flex; align-items: center; gap: 10px;">
              <div style="width: 34px; height: 34px; border-radius: 9999px; overflow: hidden; background: rgba(245, 158, 11, 0.2); border: 1px solid rgba(245, 158, 11, 0.5); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <img id="ks-user-dropdown-img" src="" alt="Avatar" style="width: 100%; height: 100%; object-fit: cover; display: none;" />
                <span id="ks-user-dropdown-initials" style="font-weight: 900; color: #fbbf24; font-size: 12px;">CK</span>
              </div>
              <div style="min-width: 0;">
                <div id="ks-user-dropdown-name" style="font-weight: 800; font-size: 13px; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Conecta King</div>
                <div style="font-size: 10.5px; color: #94a3b8;">Gerenciar Conta</div>
              </div>
            </div>

            <a href="/conta" style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border-radius: 10px; color: #e2e8f0; font-size: 12px; font-weight: 700; text-decoration: none; transition: all 0.15s;" onmouseover="this.style.background='rgba(245,158,11,0.15)';this.style.color='#fbbf24';" onmouseout="this.style.background='transparent';this.style.color='#e2e8f0';">
              <i class="fas fa-user-gear" style="color: #fbbf24; width: 16px; text-align: center;"></i>
              <span>Configurar Perfil & Foto</span>
            </a>

            <a href="/dashboard" style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border-radius: 10px; color: #e2e8f0; font-size: 12px; font-weight: 700; text-decoration: none; transition: all 0.15s;" onmouseover="this.style.background='rgba(245,158,11,0.15)';this.style.color='#fbbf24';" onmouseout="this.style.background='transparent';this.style.color='#e2e8f0';">
              <i class="fas fa-house" style="color: #fbbf24; width: 16px; text-align: center;"></i>
              <span>Painel Geral</span>
            </a>

            <div style="height: 1px; background: rgba(255, 255, 255, 0.08); margin: 6px 0;"></div>

            <button type="button" id="ks-user-logout-btn" style="width: 100%; display: flex; align-items: center; gap: 10px; padding: 8px 12px; border-radius: 10px; color: #f87171; font-size: 12px; font-weight: 700; background: transparent; border: none; cursor: pointer; text-align: left; transition: all 0.15s;" onmouseover="this.style.background='rgba(239,68,68,0.15)';" onmouseout="this.style.background='transparent';">
              <i class="fas fa-sign-out-alt" style="width: 16px; text-align: center;"></i>
              <span>Sair</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="ks-wrap">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div class="min-w-0">
        <div class="text-xl font-extrabold text-slate-900 tracking-tight" id="ks-project-title">Projeto</div>
        <div class="text-xs font-semibold text-slate-500 mt-0.5" id="ks-project-sub">KingSelection</div>
      </div>
      <div class="flex items-center gap-2 flex-wrap sm:flex-nowrap">
        <button class="ks-btn" id="ks-back" title="Voltar"><i class="fas fa-arrow-left"></i> Voltar</button>
        <button class="ks-btn" id="ks-panel" title="Ir para o painel"><i class="fas fa-house"></i> Painel</button>
        <button class="ks-btn" id="ks-share"><i class="fas fa-share"></i> Compartilhar</button>
        <button class="ks-btn ks-btn-primary" id="ks-publish"><i class="fas fa-bullhorn"></i> Publicar</button>
        <button class="ks-btn" id="ks-delete-project" title="Excluir projeto inteiro"><i class="fas fa-trash"></i> Excluir projeto</button>
      </div>
    </div>

    <!-- Layout Flex com Sidebar Retrátil (Seja Fit) -->
    <div id="ks-main-container" class="mt-6 flex gap-6 items-start transition-all duration-300">
      <!-- Sidebar Retrátil -->
      <aside id="ks-sidebar" class="w-72 shrink-0 transition-all duration-300 ease-in-out">
        <div class="ks-card ks-card--side-nav p-3">
          <!-- Botão Meus Projetos -->
          <a href="/kingSelection" id="ks-side-back-projects"
            class="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-amber-300 hover:text-amber-200 hover:bg-amber-500/10 font-extrabold text-xs transition mb-2.5 border border-amber-500/30 bg-gradient-to-r from-amber-500/10 to-amber-600/5 no-underline shadow-xs cursor-pointer group"
            title="Voltar para a lista de todas as galerias">
            <span class="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs group-hover:-translate-x-0.5 transition-transform">
              <i class="fas fa-arrow-left"></i>
            </span>
            <span class="font-extrabold tracking-tight">Meus Projetos</span>
          </a>

          <div class="ks-side flex flex-col gap-1 max-h-none overflow-y-visible">
            <a href="#" data-tab="activity" class="active"><i class="fas fa-wave-square"></i> Atividades do cliente</a>
            <a href="#" data-tab="photos"><i class="fas fa-images"></i> Fotos</a>
            <a href="#" data-tab="clients"><i class="fas fa-users"></i> Clientes</a>
            <a href="#" data-tab="details"><i class="fas fa-gear"></i> Configurações da galeria</a>
            <a href="#" data-tab="facial"><i class="fas fa-face-smile"></i> Reconhecimento Facial</a>
            <a href="#" data-tab="watermark"><i class="fas fa-droplet"></i> Marca d'água</a>
            <a href="#" id="ks-link-config-finalizacao" title="Configurar título, mensagem e imagem da tela de obrigado"><i class="fas fa-hand-holding-heart"></i> Página de finalização</a>
            <a href="#" data-tab="privacy"><i class="fas fa-lock"></i> Acesso e privacidade</a>
            <a href="#" data-tab="sales"><i class="fas fa-receipt"></i> Fotos vendidas</a>
            <a href="#" data-tab="promo"><i class="fas fa-ticket"></i> Cupom e redes</a>
            <a href="#" data-tab="links"><i class="fas fa-link"></i> Link e compartilhamento</a>
            <a href="#" data-tab="support"><i class="fab fa-whatsapp"></i> Suporte WhatsApp</a>
            <a href="#" data-tab="download"><i class="fas fa-download"></i> Download</a>
          </div>
        </div>
      </aside>

      <!-- Conteúdo Principal -->
      <main id="ks-main-content" class="flex-1 min-w-0 transition-all duration-300">
        <div id="ks-error" class="hidden mb-4 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700"></div>

        <!-- Activity (igual Alboom: lista + painel + tabs + fotos) -->
        <div class="ks-card p-5" data-pane="activity">
          <div class="ks-abo">
            <!-- Lista de clientes -->
            <div class="ks-abo-card">
              <div class="ks-abo-head">
                <div class="ks-abo-title">Atividades do cliente</div>
              </div>
              <div class="ks-abo-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input id="ks-activity-search" placeholder="Buscar cliente..." autocomplete="off" />
              </div>
              <div class="ks-abo-filters flex flex-col gap-2 mt-2 mb-1 px-0.5">
                <div class="flex flex-wrap gap-2 items-center">
                  <label for="ks-activity-sort" class="text-[10px] uppercase tracking-widest font-extrabold text-slate-500 whitespace-nowrap">Ordenar</label>
                  <select id="ks-activity-sort" class="ks-input text-xs py-1.5 px-2 rounded-lg flex-1 min-w-[min(100%,200px)] max-w-[260px]" title="Ordem da lista em cada grupo">
                    <option value="name_asc">Nome A–Z</option>
                    <option value="name_desc">Nome Z–A</option>
                    <option value="order_asc">Pedido: mais antigo primeiro</option>
                    <option value="order_desc">Pedido: mais recente primeiro</option>
                  </select>
                </div>
                <div class="flex flex-wrap gap-2 items-center">
                  <label for="ks-activity-pay-filter" class="text-[10px] uppercase tracking-widest font-extrabold text-slate-500 whitespace-nowrap">Pagamento</label>
                  <select id="ks-activity-pay-filter" class="ks-input text-xs py-1.5 px-2 rounded-lg flex-1 min-w-[min(100%,200px)] max-w-[280px]" title="Filtrar por situação de pagamento (modo Fotos vendidas)">
                    <option value="all">Todos</option>
                    <option value="paid">Já pagou (confirmado)</option>
                    <option value="unpaid">Ainda não pagou / pendente</option>
                    <option value="courtesy">Cortesia</option>
                  </select>
                </div>
              </div>
              <div class="ks-abo-group">
                <div class="ks-abo-ghead"><span>Em andamento</span><span class="ks-abo-count"
                    id="ks-activity-count-andamento">0</span></div>
                <div id="ks-activity-list-andamento"></div>
              </div>
              <div class="ks-abo-group">
                <div class="ks-abo-ghead"><span>Em revisão</span><span class="ks-abo-count"
                    id="ks-activity-count-revisao">0</span></div>
                <div id="ks-activity-list-revisao"></div>
              </div>
              <div class="ks-abo-group" style="border-bottom:0">
                <div class="ks-abo-ghead"><span>Finalizado</span><span class="ks-abo-count"
                    id="ks-activity-count-finalizado">0</span></div>
                <div id="ks-activity-list-finalizado"></div>
              </div>
            </div>

            <!-- Painel -->
            <div class="ks-abo-main">
              <div class="ks-abo-box ks-abo-client">
                <div class="ks-abo-client-top">
                  <div>
                    <div class="ks-abo-client-name" id="ks-activity-client-name">-</div>
                    <div class="ks-abo-client-sub" id="ks-activity-contact-line">
                      <span id="ks-activity-email">-</span>
                      <span class="opacity-40 ks-activity-contact-sep"> • </span>
                      <span id="ks-activity-phone">-</span>
                      <button type="button" class="ks-btn ks-btn-sm" id="ks-activity-open-whatsapp" style="margin-left:8px;padding:4px 9px">
                        <i class="fab fa-whatsapp"></i> Chamar no WhatsApp
                      </button>
                      <button type="button" class="ks-btn ks-btn-sm hidden" id="ks-activity-whatsapp-pix" style="margin-left:6px;padding:4px 9px;background:#059669;color:#fff;border-color:#047857" title="Enviar resumo de cobrança e chave PIX para o cliente no WhatsApp">
                        <i class="fab fa-whatsapp"></i> Lembrar PIX
                      </button>
                      <button type="button" class="ks-btn ks-btn-sm hidden" id="ks-activity-whatsapp-download" style="margin-left:6px;padding:4px 9px;background:#2563eb;color:#fff;border-color:#1d4ed8" title="Avisar no WhatsApp que as fotos foram aprovadas e estão prontas para download">
                        <i class="fab fa-whatsapp"></i> Avisar Download Liberado
                      </button>
                    </div>
                    <div class="ks-abo-client-sub mt-2 flex flex-wrap items-center gap-2 ck-hidden" id="ks-activity-pass-row">
                      <span class="text-xs text-slate-500">Senha de acesso (login do cliente):</span>
                      <span class="ks-pass-mask font-mono text-sm text-yellow-400 font-bold" id="ks-activity-pass" data-cid="0">••••••</span>
                      <button type="button" class="ks-btn ks-btn-sm" id="ks-activity-reveal-pass" data-ks-reveal-pass="0" title="Ver ou ocultar senha"><i class="fas fa-eye"></i> Ver senha</button>
                      <button type="button" class="ks-btn ks-btn-sm" id="ks-activity-change-pass" data-ks-change-pass="0" title="Alterar senha do cliente"><i class="fas fa-key"></i> Alterar senha</button>
                    </div>
                    <div class="ks-abo-client-sub ck-mt-8">
                      <span class="ks-abo-badge" id="ks-activity-badge">-</span>
                    </div>
                    <div class="ks-abo-client-sub" id="ks-activity-sales-mini" style="margin-top:6px;display:none">
                      <span class="ks-abo-badge ck-hidden" id="ks-activity-sales-pending-mini"></span>
                      <span class="ks-abo-badge ck-hidden" id="ks-activity-sales-approved-mini"></span>
                    </div>
                  </div>
                  <div class="ks-abo-actions">
                    <div class="ks-act-wrap">
                      <div class="ks-act-split">
                        <button class="ks-btn ks-btn-primary" id="ks-act-main"><i class="fas fa-flag-checkered"></i>
                          Finalizar</button>
                        <button class="ks-btn" id="ks-act-more" title="Mais ações"><i
                            class="fas fa-chevron-down"></i></button>
                      </div>
                      <button type="button" class="ks-btn" id="ks-act-open-round" data-ks-open-round
                        title="Com o cliente em revisão: abre nova seleção para ele escolher mais fotos sem perder as já enviadas.">
                        <i class="fas fa-layer-group"></i> Nova seleção
                      </button>
                      <button class="ks-btn" id="ks-open-export"><i class="fas fa-file-export"></i> Exportar</button>
                      <div class="ks-menu ks-act-menu" id="ks-act-menu">
                        <button type="button" id="ks-act-open-round-dd" data-ks-open-round><i class="fas fa-layer-group"></i> Nova seleção</button>
                        <button id="ks-act-finalize"><i class="fas fa-flag-checkered"></i> Finalizar galeria</button>
                        <button id="ks-act-reactivate"><i class="fas fa-rotate-left"></i> Reativar seleção</button>
                        <button id="ks-act-share"><i class="fas fa-share"></i> Compartilhar link</button>
                        <div class="border-t border-slate-200/20 my-1"></div>
                        <button type="button" id="ks-act-clear-review-dd" data-ks-clear-review class="text-amber-500" title="Apaga as fotos em revisão do cliente selecionado"><i class="fas fa-eraser"></i> Excluir revisão</button>
                        <button type="button" id="ks-act-delete-current-round" class="text-amber-500" title="Apaga apenas a rodada atual"><i class="fas fa-layer-group"></i> Excluir só rodada atual</button>
                        <button type="button" id="ks-act-delete-round-client" class="danger" title="Apaga a rodada atual e exclui o cadastro do cliente"><i class="fas fa-user-times"></i> Excluir rodada + cadastro</button>
                        <button type="button" id="ks-act-delete-client" class="danger" title="Exclui o cadastro do cliente nesta galeria"><i class="fas fa-user-slash"></i> Excluir cliente inteiro</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="ks-abo-grid2">
                <div class="ks-abo-box">
                  <h4>Resumo das atividades</h4>
                  <div class="ks-abo-kpi">
                    <div class="k">
                      <div class="l">Início</div>
                      <div class="v" id="ks-updated-at">-</div>
                    </div>
                    <div class="k">
                      <div class="l">Selecionadas</div>
                      <div class="v"><span id="ks-selected-count">0</span></div>
                      <div class="text-xs ks-muted mt-1 leading-snug min-h-[1rem]" id="ks-selected-count-sub"></div>
                    </div>
                    <div class="k">
                      <div class="l">Status</div>
                      <div class="v" id="ks-status">-</div>
                    </div>
                  </div>
                  <div class="text-xs ks-muted mt-3 leading-relaxed hidden" id="ks-activity-rounds-detail"></div>
                </div>
                <div class="ks-abo-box">
                  <h4>Mensagem do cliente</h4>
                  <div id="ks-feedback" class="ks-abo-empty">Nenhuma mensagem enviada</div>
                </div>
              </div>

              <div class="ks-abo-box ks-abo-tabsbox" style="padding:0">
                <div class="ks-abo-tabs">
                  <div class="ks-abo-tab active" data-abo-tab="photos">Fotos selecionadas</div>
                  <div class="ks-abo-tab" data-abo-tab="comments">Comentários</div>
                </div>
                <div class="ks-abo-pane" data-abo-pane="photos">
                  <div class="hidden flex-wrap items-center gap-3 mb-3 px-3 pt-3 border-b border-slate-200/80 pb-3"
                    id="ks-activity-batch-toolbar">
                    <label for="ks-activity-batch-filter" class="text-sm font-extrabold text-slate-800 shrink-0">Ver seleção</label>
                    <select id="ks-activity-batch-filter" class="ks-input max-w-md min-w-[200px]"
                      title="Mostrar só as fotos desta rodada ou todas">
                      <option value="all">Todas as rodadas</option>
                    </select>
                    <button type="button" class="ks-btn hidden border-red-400/60 text-red-600" id="ks-activity-delete-batch"
                      title="Apaga todas as fotos desta rodada só para o cliente selecionado (testes ou envio errado)">Excluir esta rodada</button>
                    <button type="button" class="ks-btn hidden" id="ks-activity-reactivate-batch"
                      title="Reativa esta rodada para o cliente voltar a selecionar nela">Reativar esta rodada</button>
                    <button type="button" class="ks-btn hidden" id="ks-activity-open-next-round"
                      title="Abre uma nova seleção sem mexer nas fotos desta rodada">Nova seleção</button>
                    <button type="button" class="ks-btn hidden" id="ks-activity-sales-approve-all"
                      title="Aprova todas as fotos desta seleção para download original (modo Fotos vendidas por evento)."><i class="fas fa-check-double"></i> Aprovar todas</button>
                    <span class="text-xs ks-muted leading-snug">A contagem em “Selecionadas” segue este filtro. Exportar usa o mesmo critério ao abrir o modal.</span>
                  </div>
                  <div class="ks-abo-photos" id="ks-activity-selected-photos"></div>
                  <div class="ks-abo-empty hidden" id="ks-activity-selected-empty">Nenhuma foto selecionada ainda</div>
                </div>
                <div class="ks-abo-pane hidden" data-abo-pane="comments">
                  <div class="ks-abo-empty" id="ks-activity-comments-box">Nenhum comentário</div>
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- Details -->
        <div class="ks-card p-5 hidden" data-pane="details">
          <div class="font-extrabold text-slate-900">Dados da galeria de fotos</div>
          <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="ks-field">
              <label>Nome da galeria de fotos</label>
              <input class="ks-input mt-2" id="f-nome" />
            </div>
            <div class="ks-field">
              <label>Categoria</label>
              <select class="ks-input mt-2" id="f-categoria">
                <option value="">— Selecione (opcional) —</option>
                <option value="Casamento">Casamento</option>
                <option value="Corporativo">Corporativo</option>
                <option value="Ensaio">Ensaio</option>
                <option value="Eventos">Eventos</option>
                <option value="Newborn">Newborn</option>
                <option value="Gestante">Gestante</option>
                <option value="Família">Família</option>
                <option value="Formatura">Formatura</option>
                <option value="Batizado">Batizado</option>
                <option value="Moda / Editorial">Moda / Editorial</option>
                <option value="Produto / Still">Produto / Still</option>
                <option value="Esportes">Esportes</option>
                <option value="Arquitetura / Imóveis">Arquitetura / Imóveis</option>
                <option value="_outro">Outra (digitar abaixo)</option>
              </select>
              <input class="ks-input mt-2 hidden ck-mt-8" id="f-categoria-outro" placeholder="Digite a categoria"
                />
            </div>
            <div class="ks-field">
              <label>Limite de seleção (0 = livre)</label>
              <input class="ks-input mt-2" id="f-max-selections" type="number" min="0" placeholder="0 = livre" title="Igual ao campo ao criar a galeria (máx. de fotos selecionáveis)" />
            </div>
            <div class="ks-field">
              <label>Seleção mínima (0 = livre)</label>
              <input class="ks-input mt-2" id="f-min-selections" type="number" min="0" placeholder="0 = livre" />
            </div>
            <div class="ks-field">
              <label>Tamanho do card no cliente</label>
              <input class="ks-input mt-2" id="f-client-card-height" type="range" min="160" max="420" step="10" value="220" />
              <div class="text-xs ks-muted mt-1">Altura do quadro da foto no cliente: <b id="f-client-card-height-val">220px</b></div>
            </div>
            <div class="ks-field">
              <label>Data do trabalho</label>
              <input class="ks-input mt-2" id="f-data" type="date" />
            </div>
            <div class="ks-field">
              <label>Idioma</label>
              <select class="ks-input mt-2" id="f-idioma">
                <option value="pt-BR">Português (BR)</option>
                <option value="en">English</option>
                <option value="es">Español</option>
              </select>
            </div>
            <div class="ks-field md:col-span-2">
              <label>Mensagem de acesso</label>
              <textarea class="ks-input mt-2" id="f-mensagem" style="min-height:120px"></textarea>
            </div>
            <div class="md:col-span-2 rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div class="text-xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">Cliente(s) e acesso</div>
              <p class="text-xs text-slate-500 mb-3 leading-relaxed">
                Cadastre quem pode entrar na galeria. No modo <b>Privado</b>, cada cliente usa <b>e-mail e senha</b> na tela de login.
                Nos modos <b>público</b>, <b>visitante</b> ou <b>fotos vendidas</b>, o cadastro também serve para identificar quem selecionou ou comprou.
                Você pode criar a galeria vazia e adicionar clientes depois.
              </p>
              <div class="flex flex-wrap items-center gap-2 mb-4">
                <button type="button" class="ks-btn ks-btn-primary" id="ks-details-client-add"><i class="fas fa-user-plus"></i> Adicionar novo cliente</button>
                <button type="button" class="ks-btn" id="ks-details-goto-clients-tab"><i class="fas fa-users"></i> Abrir aba Clientes</button>
              </div>
              <div id="ks-details-client-summary" class="text-sm text-slate-800 space-y-2"></div>
            </div>
            <div class="md:col-span-2">
              <button class="ks-btn ks-btn-primary" id="btn-save-details"><i class="fas fa-save"></i> Salvar</button>
            </div>
          </div>
        </div>

        <!-- Privacy -->
        <div class="ks-card p-5 hidden" data-pane="privacy">
          <div class="font-extrabold text-slate-900">Acesso e privacidade</div>
          <div class="mt-4 space-y-3">
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="radio" name="access_mode" value="private" class="mt-1" />
              <div>
                <div class="font-extrabold">Privado</div>
                <div class="text-sm ks-muted">Apenas clientes cadastrados podem acessar a galeria.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="radio" name="access_mode" value="signup" class="mt-1" />
              <div>
                <div class="font-extrabold">Visitantes podem se cadastrar</div>
                <div class="text-sm ks-muted">Qualquer pessoa com o link pode se cadastrar na tela de login e acessar a
                  galeria como cliente.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="radio" name="access_mode" value="paid_event_photos" class="mt-1" />
              <div>
                <div class="font-extrabold">Fotos vendidas</div>
                <div class="text-sm ks-muted">Ativa fluxo comercial: pacotes, comprovante PIX, aprovação por foto e aba de downloads liberados.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="radio" name="access_mode" value="public" class="mt-1" />
              <div>
                <div class="font-extrabold">Público</div>
                <div class="text-sm ks-muted">Qualquer pessoa com o link pode acessar a galeria.</div>
              </div>
            </label>
            <div class="mt-3">
              <button class="ks-btn ks-btn-primary" id="btn-save-privacy"><i class="fas fa-save"></i> Salvar</button>
            </div>
          </div>
        </div>

        <!-- Sales / pagamento por evento -->
        <div class="ks-card p-5 hidden" data-pane="sales">
          <div class="font-extrabold text-slate-900">Fotos vendidas</div>
          <div class="text-sm ks-muted mt-2">Configure PIX, pacotes e aprove os downloads por cliente/rodada. Este fluxo funciona apenas no modo de acesso <b>Fotos vendidas</b>.</div>
          <div class="text-xs mt-2 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-900 px-3 py-2">
            No modo <b>Fotos vendidas</b>, o download pago/aprovado em alta qualidade <b>não depende</b> da opção geral <b>Permissão de download</b>.
          </div>

          <div id="ks-sales-disabled-note" class="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-amber-900 hidden">
            <div class="font-bold flex items-center gap-2"><i class="fas fa-info-circle text-amber-600"></i> Modo Fotos Vendidas não está ativo</div>
            <div class="text-xs text-amber-800 mt-1">Para configurar pacotes e PIX para seus clientes, ative o modo <b>Fotos vendidas por evento</b>.</div>
            <button type="button" class="ks-btn ks-btn-primary mt-3" id="ks-sales-activate-btn">
              <i class="fas fa-bolt"></i> Ativar modo Fotos Vendidas agora
            </button>
          </div>

          <div id="ks-sales-wrap" class="mt-4 space-y-4">
            <div class="rounded-2xl border border-slate-700 bg-slate-900/85 p-4 text-slate-100">
              <div class="font-extrabold text-slate-100">Dashboard de vendas</div>
              <div class="mt-3 grid grid-cols-1 min-[480px]:grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 min-w-0">
                <div class="rounded-xl border border-emerald-500/45 bg-emerald-500/10 p-3 min-w-0">
                  <div class="text-xs text-emerald-200 uppercase tracking-widest font-extrabold">Recebido (dinheiro)</div>
                  <button type="button" class="mt-1 w-full min-w-0 text-left rounded-lg border border-transparent hover:border-emerald-400/50 hover:bg-emerald-500/15 transition px-1 py-0.5" id="ks-sales-dash-received-btn" data-sales-dash-detail="received" title="Ver quem pagou e quanto">
                    <div class="text-xl min-[480px]:text-2xl font-black text-emerald-100 leading-tight break-words" id="ks-sales-dash-received">R$ 0,00</div>
                    <div class="text-[10px] text-emerald-300/90 mt-0.5">Clique para ver o detalhe</div>
                  </button>
                </div>
                <div class="rounded-xl border border-amber-400/45 bg-amber-400/10 p-3 min-w-0">
                  <div class="text-xs text-amber-200 uppercase tracking-widest font-extrabold">Falta receber (estimado)</div>
                  <button type="button" class="mt-1 w-full min-w-0 text-left rounded-lg border border-transparent hover:border-amber-400/50 hover:bg-amber-500/15 transition px-1 py-0.5" id="ks-sales-dash-missing-btn" data-sales-dash-detail="missing" title="Ver onde ainda falta">
                    <div class="text-xl min-[480px]:text-2xl font-black text-amber-100 leading-tight break-words" id="ks-sales-dash-missing">R$ 0,00</div>
                    <div class="text-[10px] text-amber-200/90 mt-0.5" id="ks-sales-dash-missing-period">No período: semana</div>
                  </button>
                </div>
                <div class="rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/10 p-3 min-w-0">
                  <div class="text-xs text-fuchsia-200 uppercase tracking-widest font-extrabold">Cortesias (abonos)</div>
                  <button type="button" class="mt-1 w-full min-w-0 text-left rounded-lg border border-transparent hover:border-fuchsia-400/50 hover:bg-fuchsia-500/15 transition px-1 py-0.5" id="ks-sales-dash-courtesy-btn" data-sales-dash-detail="courtesy" title="Ver cortesias por cliente">
                    <div class="text-xl min-[480px]:text-2xl font-black text-fuchsia-100 leading-tight break-words" id="ks-sales-dash-courtesy">R$ 0,00</div>
                    <div class="text-[10px] text-fuchsia-300/90 mt-0.5">Clique para ver o detalhe</div>
                  </button>
                </div>
                <div class="rounded-xl border border-sky-400/45 bg-sky-400/10 p-3 min-w-0">
                  <div class="text-xs text-sky-200 uppercase tracking-widest font-extrabold">Clientes com pendência</div>
                  <div class="text-xl min-[480px]:text-2xl font-black text-sky-100 break-words" id="ks-sales-dash-clients-pending">0</div>
                </div>
                <div class="rounded-xl border border-violet-400/45 bg-violet-400/10 p-3 min-w-0">
                  <div class="text-xs text-violet-200 uppercase tracking-widest font-extrabold">Sessões pendentes</div>
                  <div class="text-xl min-[480px]:text-2xl font-black text-violet-100 break-words" id="ks-sales-dash-rounds-pending">0</div>
                </div>
              </div>
              <div class="mt-3 rounded-xl border border-amber-300/35 bg-amber-400/10 p-3">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <div class="text-xs text-amber-100 uppercase tracking-widest font-extrabold">Top pendências</div>
                  <div class="flex items-center gap-2">
                    <select id="ks-sales-top-pending-period" class="ks-input" style="min-width:120px;padding:4px 8px;font-size:12px;line-height:1.2">
                      <option value="today">Hoje</option>
                      <option value="week" selected>Semana</option>
                      <option value="month">Mês</option>
                    </select>
                    <div class="text-[11px] text-amber-200">Quem mais falta receber</div>
                  </div>
                </div>
                <div id="ks-sales-top-pending" class="mt-2 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 text-sm text-slate-100">
                  <div class="text-xs text-slate-300">Nenhuma pendência no momento.</div>
                </div>
              </div>
            </div>

            <div class="rounded-2xl border border-slate-200 bg-white p-4">
              <div class="font-extrabold text-slate-900">Configuração PIX</div>
              <div class="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                <label class="flex items-center gap-2">
                  <input type="checkbox" id="ks-sales-pix-enabled" />
                  <span class="text-sm">Ativar pagamento por PIX nesta galeria</span>
                </label>
                <div></div>
                <div class="ks-field">
                  <label>Chave PIX</label>
                  <input class="ks-input mt-2" id="ks-sales-pix-key" placeholder="CPF, e-mail, telefone ou chave aleatória" />
                </div>
                <div class="ks-field">
                  <label>Favorecido</label>
                  <input class="ks-input mt-2" id="ks-sales-pix-holder" placeholder="Nome do favorecido" />
                </div>
                <div class="ks-field md:col-span-2">
                  <label>Instruções para pagamento</label>
                  <textarea class="ks-input mt-2" id="ks-sales-pix-instructions" style="min-height:90px" placeholder="Ex.: Envie o comprovante logo após o pagamento para liberar o download."></textarea>
                  <div class="mt-2">
                    <button class="ks-btn" id="ks-sales-pix-generate" type="button"><i class="fas fa-wand-magic-sparkles"></i> Gerar instrução automática</button>
                  </div>
                </div>
              </div>
            </div>

            <div class="rounded-2xl border border-slate-700 bg-slate-900/85 p-4 text-slate-100">
              <div class="font-extrabold text-slate-100">Pacotes e precificação</div>
              <div class="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3">
                <div class="ks-field">
                  <label class="text-slate-300">Regra acima do pacote</label>
                  <select class="ks-input mt-2" id="ks-sales-over-limit">
                    <option value="allow_and_warn">Permitir e avisar negociação</option>
                    <option value="block_selection">Bloquear acima do limite</option>
                    <option value="allow_extra_per_photo">Permitir com foto extra automática</option>
                  </select>
                </div>
                <div class="ks-field">
                  <label class="text-slate-300">Modo de preço</label>
                  <select class="ks-input mt-2" id="ks-sales-price-mode">
                    <option value="best_price_auto">Melhor preço automático (pacotes + desconto)</option>
                    <option value="packages_only">Somente pacotes</option>
                    <option value="packages_plus_unit">Pacotes + valor por foto extra</option>
                  </select>
                </div>
                <div class="ks-field">
                  <label class="text-slate-300">Valor unitário (R$)</label>
                  <input class="ks-input mt-2" id="ks-sales-unit-price" type="text" inputmode="decimal" placeholder="Ex.: 400,00" />
                </div>
              </div>
              <div class="mt-3 flex items-center gap-2 flex-wrap">
                <button class="ks-btn" id="ks-sales-add-package" type="button"><i class="fas fa-plus"></i> Novo pacote</button>
                <span class="text-xs ks-muted">Ex.: 3 fotos = R$ 200,00</span>
              </div>
              <div id="ks-sales-packages" class="mt-3 space-y-2"></div>
            </div>

            <div class="rounded-2xl border border-slate-700 bg-slate-900/85 p-4 text-slate-100">
              <div class="font-extrabold text-slate-100">Comprovantes e aprovação</div>
              <div class="mt-3 hidden">
                <div class="ks-field">
                  <label>Cliente</label>
                  <select class="ks-input mt-2" id="ks-sales-client"></select>
                </div>
              </div>
              <div class="mt-3">
                <label class="text-slate-300 text-xs font-extrabold tracking-widest uppercase">Clientes</label>
                <div class="mt-2 flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-2">
                  <input class="ks-input flex-1 min-w-[200px]" id="ks-sales-client-search" placeholder="Buscar cliente por nome ou e-mail..." />
                  <div class="flex items-center gap-2 shrink-0">
                    <label for="ks-sales-clients-filter" class="text-[11px] text-slate-400 whitespace-nowrap">Filtrar:</label>
                    <select id="ks-sales-clients-filter" class="ks-input" style="min-width:200px;padding:8px 10px;font-size:13px">
                      <option value="all">Tudo</option>
                      <option value="received">Com valor recebido</option>
                      <option value="missing">Com falta a receber</option>
                      <option value="courtesy">Cortesias / abençoados</option>
                    </select>
                  </div>
                </div>
                <div id="ks-sales-clients-list" class="mt-2 grid grid-cols-1 gap-2"></div>
              </div>
              <div class="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                <div class="ks-field">
                  <label class="text-slate-300">Rodada</label>
                  <select class="ks-input mt-2" id="ks-sales-round"></select>
                </div>
                <div class="ks-field">
                  <label class="text-slate-300">Status pagamento</label>
                  <div id="ks-sales-payment-status" class="ks-input mt-2 flex flex-col justify-center gap-0.5 py-2 min-h-[44px] text-left leading-snug">—</div>
                </div>
              </div>
              <div id="ks-sales-terms-panel" class="mt-3 rounded-xl border border-slate-600 bg-slate-950/60 p-3">
                <div class="font-extrabold text-slate-100 text-sm">Valores combinados (esta rodada)</div>
                <p class="text-[11px] text-slate-400 mt-1 leading-relaxed">
                  A <b>soma pelos pacotes</b> segue a mesma regra do pagamento no app do cliente. O <b>total acordado</b> substitui essa soma no saldo. Preencha <b>valor restante</b>, <b>parcelas</b> e <b>dias</b> para exibir o plano no status acima; o recebido em dinheiro continua em <b>Pagamento confirmado</b> e nos demais botões.
                </p>
                <div class="mt-2 rounded-lg border border-emerald-900/50 bg-emerald-950/30 px-3 py-2">
                  <div class="text-[10px] text-emerald-300/90 uppercase font-extrabold tracking-wide">Referência (soma pelas fotos)</div>
                  <div id="ks-sales-terms-photo-ref" class="text-emerald-100 font-bold text-sm mt-1">—</div>
                  <div id="ks-sales-terms-cupom-note" class="text-[10px] text-slate-500 mt-1 hidden"></div>
                </div>
                <div class="mt-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  <div class="ks-field">
                    <label class="text-slate-400 text-xs">Total acordado (R$)</label>
                    <input class="ks-input mt-1" id="ks-sales-terms-negotiated" type="text" inputmode="decimal" placeholder="Vazio = soma pelas fotos" />
                  </div>
                  <div class="ks-field">
                    <label class="text-slate-400 text-xs">Entrada declarada (R$)</label>
                    <input class="ks-input mt-1" id="ks-sales-terms-down" type="text" inputmode="decimal" placeholder="Opcional" />
                  </div>
                  <div class="ks-field">
                    <label class="text-slate-400 text-xs">Valor restante a parcelar (R$)</label>
                    <input class="ks-input mt-1" id="ks-sales-terms-remaining" type="text" inputmode="decimal" placeholder="Ex.: 1.000,00" />
                  </div>
                  <div class="ks-field">
                    <label class="text-slate-400 text-xs">Parcelas do restante</label>
                    <input class="ks-input mt-1" id="ks-sales-terms-installments" type="number" min="1" max="240" step="1" placeholder="Ex.: 1" />
                  </div>
                  <div class="ks-field">
                    <label class="text-slate-400 text-xs">Dias para pagar (cada parcela)</label>
                    <input class="ks-input mt-1" id="ks-sales-terms-interval-days" type="number" min="1" max="730" step="1" placeholder="Ex.: 30" />
                  </div>
                </div>
                <div id="ks-sales-terms-hint" class="text-[11px] text-slate-400 mt-2"></div>
                <div class="mt-2">
                  <button type="button" class="ks-btn ks-btn-primary" id="ks-sales-terms-save"><i class="fas fa-save"></i> Salvar valores combinados</button>
                </div>
              </div>
              <div class="mt-3 flex items-center gap-2 flex-wrap">
                <button class="ks-btn" id="ks-sales-payment-confirm" type="button"><i class="fas fa-check"></i> Pagamento confirmado</button>
                <button class="ks-btn" id="ks-sales-payment-adiantamento" type="button" style="border-color:rgba(45,212,191,.7);background:rgba(13,148,136,.16);color:#ccfbf1;font-weight:800" title="Registra um pagamento parcial: soma ao recebido nesta rodada até quitar o combinado (sem substituir o acumulado)."><i class="fas fa-coins"></i> Registrar adiantamento</button>
                <button class="ks-btn" id="ks-sales-payment-courtesy-rest" type="button" style="border-color:rgba(167,139,250,.75);background:rgba(139,92,246,.18);color:#ede9fe;font-weight:800" title="Abonar o que falta como cortesia e encerrar o pacote"><i class="fas fa-hand-holding-heart"></i> Cortesia no restante</button>
                <button class="ks-btn" id="ks-sales-payment-fix-amount" type="button"><i class="fas fa-pen"></i> Corrigir valor pago</button>
                <button class="ks-btn" id="ks-sales-payment-reject" type="button"><i class="fas fa-xmark"></i> Recusar comprovante</button>
                <button class="ks-btn" id="ks-sales-payment-pending" type="button"><i class="fas fa-rotate-left"></i> Comprovante em espera</button>
                <button class="ks-btn" id="ks-sales-payment-undo-confirm" type="button" style="border-color:rgba(251,191,36,.75);background:rgba(245,158,11,.14);color:#fef3c7;font-weight:800" title="Zera recebido/cortesia e volta a aguardar comprovante (desfaz confirmação por engano)"><i class="fas fa-undo"></i> Desfazer confirmação</button>
                <button class="ks-btn" id="ks-sales-payment-bless" type="button" style="background:rgba(139,92,246,.22);border-color:rgba(167,139,250,.85);color:#ede9fe;font-weight:900"><i class="fas fa-gift"></i> Abençoado (sem pagamento)</button>
                <button class="ks-btn" id="ks-sales-open-proof" type="button"><i class="fas fa-image"></i> Ver comprovante</button>
                <button class="ks-btn" id="ks-sales-open-client-whats" type="button" style="background:rgba(16,185,129,.20);border-color:rgba(16,185,129,.68);color:#d1fae5;font-weight:900"><i class="fab fa-whatsapp"></i> WhatsApp do cliente</button>
                <button class="ks-btn" id="ks-sales-photos-all-pending" type="button" style="border-color:rgba(245,158,11,.65);background:rgba(234,179,8,.14);color:#fde68a;font-weight:800"><i class="fas fa-hourglass-half"></i> Aguardando liberação (todas)</button>
                <button class="ks-btn" id="ks-sales-approve-all" type="button"><i class="fas fa-check-double"></i> Aprovar todas (original)</button>
                <p class="text-xs text-slate-400 mt-2 max-w-3xl leading-relaxed" id="ks-sales-payment-extra-hint"><b>Pagamento confirmado:</b> pergunta se soma ou substitui o acumulado. <b>Registrar adiantamento:</b> só soma ao recebido (pagamento parcial até quitar). Entrada e parcelas do restante ficam em <b>Valores combinados</b>. <b>Cortesia no restante:</b> abona o saldo. <b>Comprovante em espera / Desfazer:</b> como antes.</p>
              </div>
              <div id="ks-sales-proof-panel" class="mt-3 rounded-xl border border-slate-700 bg-slate-900/70 p-3 hidden">
                <div id="ks-sales-proof-meta" class="text-xs ks-muted"></div>
                <div id="ks-sales-proof-empty" class="text-xs ks-muted mt-2">Nenhum comprovante anexado nesta rodada.</div>
                <div class="mt-2 rounded-lg overflow-hidden border border-slate-700 hidden" id="ks-sales-proof-img-wrap">
                  <img id="ks-sales-proof-img" alt="Comprovante do cliente" style="width:100%;max-height:360px;object-fit:contain;background:#0b0b0b;display:block" />
                </div>
              </div>
              <input type="file" id="ks-sales-edited-file" accept="image/*" class="hidden" />
              <div id="ks-sales-approvals" class="mt-3 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3"></div>
            </div>

            <div>
              <button class="ks-btn ks-btn-primary" id="ks-sales-save"><i class="fas fa-save"></i> Salvar configuração comercial</button>
            </div>
          </div>
        </div>

        <!-- Cupom (vendas ou público + download) -->
        <div class="ks-card p-5 hidden" data-pane="promo">
          <div class="font-extrabold text-slate-900">Cupom e redes sociais</div>
          <p class="text-sm ks-muted mt-2 max-w-3xl">Ative para o cliente seguir seus perfis, validar um código e liberar downloads (marcados). Disponível no modo <b>Fotos vendidas</b> ou em <b>Acesso público</b> quando <b>Download</b> está permitido.</p>
          <div id="ks-promo-disabled-note" class="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-amber-900 hidden">
            Use em <b>Fotos vendidas</b> ou em <b>Acesso público</b> com <b>Download</b> ativo (aba Download).
          </div>
          <div id="ks-promo-wrap" class="mt-4 space-y-4">
            <label class="inline-flex items-center gap-2">
              <input type="checkbox" id="ks-promo-enabled" />
              <span class="text-sm font-semibold">Ativar cupom nesta galeria</span>
            </label>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div class="ks-field">
                <label>Código do cupom</label>
                <input type="text" class="ks-input mt-2" id="ks-promo-code" placeholder="Ex.: VERAO2026" maxlength="80" autocomplete="off" />
              </div>
              <div class="ks-field">
                <label>Validade (dias a partir de agora)</label>
                <input type="number" min="1" max="3650" class="ks-input mt-2" id="ks-promo-valid-days" placeholder="Vazio = sem prazo" />
                <p class="text-xs ks-muted mt-1" id="ks-promo-valid-hint"></p>
              </div>
              <div class="ks-field">
                <label id="ks-promo-free-label">Fotos isentas pelo cupom (no valor estimado)</label>
                <input type="number" min="1" max="50" class="ks-input mt-2" id="ks-promo-free-photos" value="1" />
                <p id="ks-promo-free-hint-sales" class="text-xs ks-muted mt-1 max-w-xl">Quantas fotos entram <strong>de graça</strong> no cálculo do total (pacotes/preço unitário). Ex.: 12 escolhidas com isenção 1 → o cliente vê o preço como se fossem 11 cobradas. A <strong>aprovação</strong> de cada foto (cortesia, pago, PIX) continua normal no seu painel.</p>
                <p id="ks-promo-free-hint-public" class="text-xs ks-muted mt-1 max-w-xl hidden">Limite de <strong>fotos para baixar</strong> após validar o cupom e seguir as redes (entre 1 e todas as selecionadas, até o número que definir aqui).</p>
              </div>
            </div>
            <div class="ks-field">
              <label>Instruções (opcional)</label>
              <textarea class="ks-input mt-2" id="ks-promo-instructions" rows="3" placeholder="Texto exibido ao cliente acima dos botões de rede social."></textarea>
              <button type="button" class="ks-btn mt-2" id="ks-promo-gen-instructions" title="Gera um texto padrão com código, isenção e redes">
                <i class="fas fa-wand-magic-sparkles"></i> Gerar texto sugerido
              </button>
            </div>
            <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div class="text-xs font-extrabold ks-muted tracking-widest uppercase mb-2">Perfis (arroba + link)</div>
              <div id="ks-promo-social-rows" class="space-y-2"></div>
              <button type="button" class="ks-btn mt-2" id="ks-promo-add-social"><i class="fas fa-plus"></i> Adicionar perfil</button>
            </div>
            <div>
              <button type="button" class="ks-btn ks-btn-primary" id="ks-promo-save"><i class="fas fa-save"></i> Salvar cupom</button>
            </div>
          </div>
        </div>

        <!-- Link do cliente / compartilhar -->
        <div class="ks-card p-5 hidden" data-pane="links">
          <div class="font-extrabold text-slate-900">Link e compartilhamento</div>
          <p class="text-sm ks-muted mt-2 max-w-3xl">Use o link de produção para o cliente. Abra numa nova aba para testar com o e-mail e a senha. Copie só o link ou a mensagem completa — o que clicar em <b>Compartilhar</b> no topo abre esta aba.</p>

          <div class="mt-5 ks-field">
            <label>Link da galeria (cliente — URL de partilha)</label>
            <div class="flex gap-2 mt-2 flex-wrap items-stretch">
              <input type="text" readonly id="ks-links-prod-url" class="ks-input flex-1 min-w-[min(100%,280px)]" />
              <button type="button" class="ks-btn ks-btn-primary" id="ks-links-copy-prod"><i class="fas fa-copy"></i> Copiar link</button>
              <button type="button" class="ks-btn" id="ks-links-open-prod" title="Abrir galeria do cliente"><i class="fas fa-external-link-alt"></i> Abrir</button>
            </div>
          </div>

          <div id="ks-links-local-wrap" class="mt-4 ks-field hidden">
            <label>URL neste ambiente (teste em localhost)</label>
            <p class="text-xs ks-muted mt-1 mb-0">Só aparece quando é diferente do link de produção acima.</p>
            <div class="flex gap-2 mt-2 flex-wrap items-stretch">
              <input type="text" readonly id="ks-links-local-url" class="ks-input flex-1 min-w-[min(100%,280px)]" />
              <button type="button" class="ks-btn" id="ks-links-copy-local"><i class="fas fa-copy"></i> Copiar</button>
              <button type="button" class="ks-btn" id="ks-links-open-local"><i class="fas fa-external-link-alt"></i> Abrir</button>
            </div>
          </div>

          <!-- Capa do link e do evento -->
          <div id="ks-link-cover-card-wrap" class="mt-6 rounded-2xl border border-amber-300 bg-amber-50/60 p-5 shadow-sm">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div class="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <i class="fas fa-image text-amber-500 text-lg"></i> Capa do link e do evento
                <span class="bg-amber-400 text-slate-950 text-[11px] font-black px-2 py-0.5 rounded tracking-wide uppercase">Capa</span>
              </div>
            </div>
            <p class="text-sm text-slate-700 mt-1 max-w-3xl leading-relaxed">Você pode escolher uma foto da galeria ou enviar uma imagem externa (JPG/PNG) do seu dispositivo para a <b>capa principal do evento</b> (aparece em destaque ao abrir o link e na prévia do WhatsApp).</p>

            <div class="flex flex-wrap gap-2 items-center mt-4">
              <input type="file" id="ks-link-cover-upload-file" class="hidden" accept="image/*" />
              <button type="button" class="ks-btn" id="ks-link-cover-upload-btn"><i class="fas fa-upload"></i> Selecionar foto no dispositivo</button>
              <button type="button" class="ks-btn ks-btn-primary" id="ks-link-cover-open-gallery-btn"><i class="fas fa-image"></i> Escolher foto da galeria atual</button>
              <button type="button" class="ks-btn" id="ks-link-cover-save-btn"><i class="fas fa-save"></i> Salvar capa do link</button>
            </div>

            <div class="mt-4">
              <div class="ks-field">
                <label class="text-slate-700 font-bold text-xs uppercase tracking-wider">Pré-visualização da capa atual</label>
                <div class="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 mt-2 max-w-md shadow-inner">
                  <img id="ks-link-cover-preview" alt="Prévia da capa do link" style="width:100%;height:230px;object-fit:contain;background:#f8fafc;display:block" />
                </div>
                <div id="ks-link-cover-current-source" class="text-xs text-amber-800 font-semibold mt-2">Origem atual: foto da galeria</div>
              </div>
            </div>

            <select id="ks-link-cover-photo" class="ks-input mt-2 hidden"></select>
            <div id="ks-link-cover-picker" class="hidden mt-4 rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
              <div class="ks-link-cover-picker-card">
                <div class="ks-link-cover-picker-head flex items-center justify-between gap-2 mb-3 border-b border-slate-100 pb-2">
                  <div class="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <i class="fas fa-images text-amber-500"></i> Escolher foto da galeria atual
                  </div>
                  <button type="button" class="ks-btn ks-btn-sm" id="ks-link-cover-picker-close"><i class="fas fa-times"></i> Fechar</button>
                </div>
                <div class="mb-3">
                  <input type="text" id="ks-link-cover-search" class="ks-input w-full" placeholder="Buscar foto pelo nome..." />
                </div>
                <div id="ks-link-cover-grid" class="ks-link-cover-picker-grid grid grid-cols-2 md:grid-cols-3 gap-2 max-h-[360px] overflow-y-auto p-1"></div>
                <div class="mt-4 flex flex-wrap gap-2 items-center border-t border-slate-100 pt-3">
                  <button type="button" class="ks-btn ks-btn-primary" id="ks-link-cover-picker-apply"><i class="fas fa-check"></i> Usar foto selecionada</button>
                  <span class="text-xs text-slate-500">Essa capa será usada na tela cheia ao abrir o link e na miniatura do WhatsApp.</span>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div class="text-xs font-extrabold ks-muted tracking-widest uppercase mb-3">Mensagem personalizada para compartilhar (opcional)</div>
            <textarea id="ks-links-custom-message" class="ks-input mt-2" rows="4"
              placeholder="Ex.: Olá! Segue o link da sua galeria. Qualquer dúvida, me chame no WhatsApp."></textarea>
            <p class="text-xs ks-muted mt-2 mb-0">Se preencher, essa mensagem aparece no final do texto quando a mensagem completa está no <b>modo automático</b> (ver abaixo). As alterações são salvas automaticamente.</p>
            <div class="mt-3 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn" id="ks-links-ai-custom" title="Usar a IA do sistema (OpenAI) para sugerir um texto curto"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
            </div>
          </div>

          <div class="mt-5 ks-field">
            <label>Mensagem completa (edite livremente — WhatsApp ou e-mail)</label>
            <p class="text-xs ks-muted mt-1 mb-0">Com <b>acesso privado</b> e <b>um</b> cliente na lista, o modelo automático inclui <b>e-mail e senha</b>. Em <b>autocadastro</b> ou <b>fotos vendidas</b>, a mensagem automática leva só o link. Pode editar à vontade. <b>Restaurar modelo</b> recalcula a partir das configurações atuais.</p>
            <textarea id="ks-links-full-msg" class="ks-input mt-2" rows="11"
              style="font-size:13px;line-height:1.45;resize:vertical"></textarea>
            <div class="flex gap-2 mt-3 flex-wrap items-center">
              <button type="button" class="ks-btn" id="ks-links-ai-full" title="Usar a IA do sistema (OpenAI) para gerar a mensagem completa"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
              <button type="button" class="ks-btn" id="ks-links-full-reset" title="Substituir pelo modelo automático (nome do projeto + link + opcional)"><i class="fas fa-rotate-left"></i> Restaurar modelo</button>
              <button type="button" class="ks-btn ks-btn-primary" id="ks-links-copy-full"><i class="fas fa-copy"></i> Copiar mensagem completa</button>
              <button type="button" class="ks-btn" id="ks-links-whats"><i class="fab fa-whatsapp"></i> Abrir WhatsApp Web</button>
            </div>
          </div>

          <div class="mt-6 rounded-xl border border-amber-500/35 bg-amber-950/20 p-4">
            @verbatim
            <div class="text-xs font-extrabold text-amber-100/90 tracking-widest uppercase mb-2">Mensagens WhatsApp · Fotos e vendas</div>
            <p class="text-sm text-amber-50/90 mt-1 max-w-3xl">Textos usados no botão <b>WhatsApp do cliente</b> (aba <b>Fotos e vendas</b>), conforme a situação. Ao abrir o WhatsApp, o sistema preenche com o modelo correspondente e os códigos abaixo.</p>
            <p class="text-xs text-amber-100/75 mt-2 max-w-3xl"><code class="text-amber-200/95">{{nome}}</code> nome do cliente · <code class="text-amber-200/95">{{link}}</code> link público da galeria · <code class="text-amber-200/95">{{galeria}}</code> nome do evento ou projeto. No texto você pode usar <span class="whitespace-nowrap">*asteriscos*</span> para negrito no WhatsApp.</p>
            <label class="mt-4 block font-semibold text-sm text-slate-100">1 · Falta pagamento (PIX pendente ou saldo em aberto)</label>
            <textarea id="ks-sales-wa-tpl-pending" class="ks-input mt-2 font-mono text-sm" rows="5" placeholder="Ex.: Olá, {{nome}}! … {{link}} … {{galeria}}"></textarea>
            <div class="mt-2 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn" id="ks-sales-wa-tpl-ai-pending" title="Gera texto com a IA do servidor (OpenAI), mantendo {{nome}}, {{link}} e {{galeria}}"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
            </div>
            <label class="mt-4 block font-semibold text-sm text-slate-100">2 · Comprovante recusado — pedir novo envio</label>
            <textarea id="ks-sales-wa-tpl-rejected" class="ks-input mt-2 font-mono text-sm" rows="5" placeholder="Ex.: Olá, {{nome}}! … {{link}} … {{galeria}}"></textarea>
            <div class="mt-2 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn" id="ks-sales-wa-tpl-ai-rejected" title="Gera texto com a IA do servidor (OpenAI), mantendo {{nome}}, {{link}} e {{galeria}}"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
            </div>
            <label class="mt-4 block font-semibold text-sm text-slate-100">3 · Pagamento ok — aguardando <i>sua</i> aprovação das fotos</label>
            <textarea id="ks-sales-wa-tpl-awaiting" class="ks-input mt-2 font-mono text-sm" rows="5" placeholder="Ex.: Olá, {{nome}}! … {{link}} … {{galeria}}"></textarea>
            <div class="mt-2 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn" id="ks-sales-wa-tpl-ai-awaiting" title="Gera texto com a IA do servidor (OpenAI), mantendo {{nome}}, {{link}} e {{galeria}}"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
            </div>
            <label class="mt-4 block font-semibold text-sm text-slate-100">4 · Tudo certo — fotos aprovadas (liberar download)</label>
            <textarea id="ks-sales-wa-tpl-approved" class="ks-input mt-2 font-mono text-sm" rows="6" placeholder="Ex.: Olá, {{nome}}! … {{link}} … {{galeria}}"></textarea>
            <div class="mt-2 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn" id="ks-sales-wa-tpl-ai-approved" title="Gera texto com a IA do servidor (OpenAI), mantendo {{nome}}, {{link}} e {{galeria}}"><i class="fas fa-wand-magic-sparkles"></i> Gerar com IA</button>
            </div>
            @endverbatim
            <div class="mt-4 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn ks-btn-primary" id="ks-sales-wa-tpl-save"><i class="fas fa-save"></i> Salvar textos de vendas</button>
              <button type="button" class="ks-btn" id="ks-sales-wa-tpl-reset" title="Apaga os textos personalizados e volta aos modelos padrão do sistema (grava no servidor)."><i class="fas fa-rotate-left"></i> Usar padrões do sistema</button>
            </div>
            <p class="text-xs ks-muted mt-2 max-w-3xl"><b>Por caixa:</b> apague o texto, salve e aquele campo volta ao padrão. <b>Tudo de uma vez:</b> use o botão &quot;Usar padrões do sistema&quot;.</p>
          </div>
        </div>

        <!-- Capa do link (alias) -->
        <div class="hidden" data-pane="link-cover"></div>

        <!-- Suporte WhatsApp -->
        <div class="ks-card p-5 hidden" data-pane="support">
          <div class="font-extrabold text-slate-900">Suporte WhatsApp</div>
          <p class="text-sm ks-muted mt-2 max-w-3xl">Configure aqui o botão de suporte que aparece para o cliente dentro da galeria. Assim fica fácil para ele te chamar para confirmar pagamento, pedir liberação ou tirar dúvidas.</p>

          <div class="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div class="text-xs font-extrabold ks-muted tracking-widest uppercase mb-3">Botão flutuante no cliente</div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label>WhatsApp de suporte (com DDD / país)
                <input type="text" id="ks-support-whatsapp" class="ks-input mt-2" placeholder="Ex.: 5511999999999" />
              </label>
              <label>Texto do botão (opcional)
                <input type="text" id="ks-support-label" class="ks-input mt-2" placeholder="Ex.: Suporte no WhatsApp" />
              </label>
            </div>
            <div class="mt-3">
              <div class="flex flex-wrap items-end justify-between gap-2">
                <label class="block flex-1 min-w-0">Mensagem padrão (opcional)</label>
                <button type="button" class="ks-btn shrink-0" id="ks-support-ai" title="Gera um texto cordial com IA (OpenAI). Configure OPENAI_API_KEY no servidor.">
                  <i class="fas fa-wand-magic-sparkles"></i> Gerar com a IA
                </button>
              </div>
              <textarea id="ks-support-message" class="ks-input mt-2 w-full" rows="3"
                placeholder="Ex.: Olá! Preciso de ajuda com minha seleção de fotos."></textarea>
              <p class="text-xs ks-muted mt-1 max-w-3xl">A mensagem pré-preenche o WhatsApp quando o cliente toca em suporte. A IA usa o mesmo serviço OpenAI do resto do King Selection (chave no servidor).</p>
            </div>
            <div class="mt-3 flex flex-wrap gap-2 items-center">
              <button type="button" class="ks-btn ks-btn-primary" id="ks-support-save"><i class="fas fa-save"></i> Salvar suporte WhatsApp</button>
              <span class="text-xs ks-muted">Esse número será usado no botão de suporte exibido ao cliente.</span>
            </div>
          </div>

          <p class="text-sm ks-muted mt-4 max-w-3xl">As mensagens do botão <b>WhatsApp do cliente</b> na aba <b>Fotos e vendas</b> são editáveis na aba <b>Capa do link</b>, junto com a capa da prévia do link.</p>
        </div>

        <!-- Clients -->
        <div class="ks-card p-6 hidden" data-pane="clients">
          <!-- Topo da Aba de Clientes: Título e Botões de Ação -->
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200">
            <div>
              <div class="flex items-center gap-2.5">
                <div class="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-700 flex items-center justify-center text-base font-bold shadow-xs">
                  <i class="fas fa-users"></i>
                </div>
                <div>
                  <div class="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
                    <span>Clientes da Galeria</span>
                    <span id="ks-client-count-badge" class="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-xs">
                      <span id="ks-client-count">0</span> cadastrado(s)
                    </span>
                  </div>
                  <div class="text-xs font-semibold text-slate-500 mt-0.5">
                    Cadastre e gerencie os acessos, senhas e informações de contato dos clientes desta galeria.
                  </div>
                </div>
              </div>
            </div>

            <!-- Botão Adicionar Novo Cliente -->
            <button type="button" class="ks-btn ks-btn-primary" id="ks-client-add" style="padding: 10px 22px; font-size: 13px; font-weight: 800; border-radius: 12px; box-shadow: 0 4px 14px rgba(245, 158, 11, 0.25);" title="Cadastrar Novo Cliente">
              <i class="fas fa-user-plus"></i> Novo Cliente
            </button>
          </div>

          <!-- Grid Principal: Lista de Clientes e Configurações -->
          <div class="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <!-- Coluna Principal (2 colunas): Busca e Lista de Clientes -->
            <div class="lg:col-span-2 space-y-5">
              
              <!-- Barra de Busca de Clientes -->
              <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
                <div class="relative">
                  <i class="fas fa-search" aria-hidden="true" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #f59e0b; font-size: 14px;"></i>
                  <input id="ks-client-search" class="ks-input" placeholder="Buscar cliente por nome, e-mail ou WhatsApp..." style="padding-left: 42px; font-size: 13px; font-weight: 500;" autocomplete="off" />
                </div>
              </div>

              <!-- Lista de Clientes -->
              <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
                <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div class="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
                    <i class="fas fa-address-book text-amber-500"></i>
                    <span>Clientes Cadastrados</span>
                  </div>
                  <div class="text-xs font-semibold text-slate-500">
                    Acesso exclusivo por e-mail e senha
                  </div>
                </div>

                <!-- Estado Vazio (Sem clientes) -->
                <div id="ks-client-empty" class="mt-4 rounded-2xl border border-dashed border-amber-300/80 bg-amber-50/40 p-8 text-center hidden">
                  <div class="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-xl shadow-xs">
                    <i class="fas fa-user-plus"></i>
                  </div>
                  <div class="font-extrabold text-slate-800 text-base mt-3">Nenhum cliente cadastrado ainda</div>
                  <p class="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
                    Cadastre o cliente para gerar o login (e-mail e senha) e enviar o link de seleção diretamente pelo WhatsApp.
                  </p>
                  <button type="button" class="ks-btn ks-btn-primary mt-4 inline-flex items-center gap-2" onclick="document.getElementById('ks-client-add').click();">
                    <i class="fas fa-plus"></i> Cadastrar Primeiro Cliente
                  </button>
                </div>

                <!-- Container onde o JS renderiza os cards -->
                <div id="ks-client-list" class="mt-4 space-y-4"></div>
              </div>

              <!-- Autocadastro de Visitantes -->
              <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
                <div class="flex items-start justify-between gap-4">
                  <div class="min-w-0">
                    <div class="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                      <i class="fas fa-user-check text-emerald-600"></i>
                      <span>Autocadastro na tela de login</span>
                    </div>
                    <div class="text-xs text-slate-500 mt-1 leading-relaxed">
                      Permite que visitantes que receberem o link da galeria façam seu próprio cadastro (nome, e-mail e WhatsApp) na tela inicial.
                    </div>
                  </div>
                  <label class="inline-flex items-center gap-3 select-none">
                    <input id="ks-self-signup" type="checkbox" class="w-5 h-5 accent-amber-500 rounded cursor-pointer" />
                  </label>
                </div>

                <div class="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                  <button class="ks-btn ks-btn-primary" id="btn-save-selfsignup">
                    <i class="fas fa-save"></i> Salvar Opção de Autocadastro
                  </button>
                </div>
              </div>
            </div>

            <!-- Coluna Lateral (1 coluna): Dicas e Orientações -->
            <div class="lg:col-span-1 space-y-4">
              <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
                <div class="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <i class="fas fa-lightbulb text-amber-500"></i>
                  <span>Dicas Importantes</span>
                </div>
                <div class="mt-3 space-y-3 text-xs text-slate-600 leading-relaxed">
                  <div class="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <i class="fab fa-whatsapp text-emerald-600 text-base mt-0.5 shrink-0"></i>
                    <div>
                      <strong class="text-slate-800">Enviar pelo WhatsApp:</strong> Clique no botão verde de WhatsApp em cada cliente para abrir a mensagem com link e senha prontos.
                    </div>
                  </div>
                  <div class="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <i class="fas fa-eye text-amber-600 text-base mt-0.5 shrink-0"></i>
                    <div>
                      <strong class="text-slate-800">Ver Senha:</strong> Clique no ícone de olho para revelar a senha gerada para o cliente.
                    </div>
                  </div>
                  <div class="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <i class="fas fa-key text-slate-600 text-base mt-0.5 shrink-0"></i>
                    <div>
                      <strong class="text-slate-800">Alterar Senha:</strong> Use o botão de alterar ou menu de opções para redefinir a senha a qualquer momento.
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        <!-- Download -->
        <div class="ks-card p-5 hidden" data-pane="download">
          <div class="font-extrabold text-slate-900">Download</div>
          <div class="mt-4 space-y-4">
            <label class="flex items-center gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="checkbox" id="d-allow" />
              <div>
                <div class="font-extrabold">Permitir o download das fotos</div>
                <div class="text-sm ks-muted">Libera botão de download (previews com marca d’água).</div>
              </div>
            </label>
            <div class="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
              <div class="font-extrabold text-sm">Organização para o cliente</div>
              <label class="flex items-start gap-3">
                <input type="radio" name="ks_client_folder_layout" id="ks-dl-layout-folders" value="folders" class="mt-1" />
                <div>
                  <div class="font-semibold text-sm">Pastas</div>
                  <div class="text-xs ks-muted">Cliente navega pelas pastas antes de ver as fotos.</div>
                </div>
              </label>
              <label class="flex items-start gap-3">
                <input type="radio" name="ks_client_folder_layout" id="ks-dl-layout-flat" value="flat" class="mt-1" />
                <div>
                  <div class="font-semibold text-sm">Fotos soltas</div>
                  <div class="text-xs ks-muted">Sem lista de pastas — só a grelha (útil quando subiu só fotos).</div>
                </div>
              </label>
            </div>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="checkbox" id="ks-client-entry-splash" class="mt-1" />
              <div>
                <div class="font-extrabold">Capa ao abrir (modo público)</div>
                <div class="text-sm ks-muted">Mostra a imagem da <strong>capa do link</strong> em ecrã cheio antes da galeria (estilo app). Configure a capa na aba <strong>Capa do link</strong>.</div>
              </div>
            </label>
            <div class="mt-4">
              <button class="ks-btn ks-btn-primary" id="btn-save-download"><i class="fas fa-save"></i> Salvar</button>
            </div>
          </div>
        </div>

        <!-- Watermark -->
        <div class="ks-card p-5 hidden" data-pane="watermark">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div class="font-extrabold text-slate-900 text-lg">Marca d'água</div>
              <div class="text-xs text-slate-500 mt-0.5">Proteja suas fotos contra cópias e capturas de tela durante a seleção do cliente.</div>
            </div>
            <button type="button" id="btn-open-wm-generator" class="ks-btn bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition transform hover:-translate-y-0.5 border-0" style="background: linear-gradient(135deg, #f59e0b, #d97706) !important; color: #ffffff !important; border: none !important;">
              <i class="fas fa-wand-magic-sparkles text-amber-200"></i> Gerador Automático de Marca d'Água
            </button>
          </div>

          <!-- Banner Informativo do Gerador Inteligente -->
          <div class="rounded-2xl border-2 border-amber-300/80 bg-gradient-to-br from-amber-50/70 via-white to-amber-50/30 p-4 shadow-xs mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex items-start gap-3">
              <div class="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-600 flex items-center justify-center shrink-0 mt-0.5">
                <i class="fas fa-wand-magic-sparkles text-lg"></i>
              </div>
              <div>
                <div class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-extrabold uppercase tracking-wider mb-1">
                  NOVIDADE INTELIGENTE
                </div>
                <div class="font-extrabold text-slate-900 text-sm">Crie sua grade oficial com 1 clique</div>
                <div class="text-xs text-slate-600 mt-0.5">
                  Envie sua logo (em qualquer cor). O gerador converte para branco puro e monta as grades nos dois formatos (retrato e paisagem) sem distorcer.
                </div>
              </div>
            </div>
            <button type="button" id="btn-banner-open-generator" class="ks-btn text-xs font-bold py-2 px-4 rounded-xl shrink-0 cursor-pointer text-amber-800 bg-amber-100/80 hover:bg-amber-200 border-amber-300">
              <i class="fas fa-plus mr-1"></i> Criar Marca Agora
            </button>
          </div>

          <div class="mt-4 space-y-3">
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white">
              <input type="radio" name="wm_mode" value="none" class="mt-1" />
              <div>
                <div class="font-extrabold">Sem marca d’água</div>
                <div class="text-sm ks-muted">Desativa a marca d’água (não recomendado).</div>
              </div>
            </label>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white" id="wm-mode-ck-wrap">
              <input type="radio" name="wm_mode" value="tile_dense" class="mt-1" id="wm-mode-ck" />
              <div>
                <div class="font-extrabold">Marca d’água da Conecta King</div>
                <div class="text-sm ks-muted">Quando o cliente não envia marca própria, usa automaticamente a logomarca
                  oficial da Conecta King.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 p-4 rounded-xl border border-slate-200 bg-white"
              id="wm-mode-logo-wrap">
              <input type="radio" name="wm_mode" value="logo" class="mt-1" id="wm-mode-logo" />
              <div>
                <div class="font-extrabold">Sua marca d’água personalizada</div>
                <div class="text-sm ks-muted">Usa a marca d’água que você enviou (a miniatura aparece lá embaixo).</div>
              </div>
            </label>

            <div class="rounded-2xl border border-slate-200 bg-slate-50/80 p-5 text-slate-800 mt-4 shadow-sm">
              <div class="flex items-center justify-between gap-3">
                <div>
                  <div class="font-extrabold text-slate-900 text-base">Pré-visualização (tempo real)</div>
                  <div class="text-xs text-slate-500 mt-0.5">Mostra exatamente como seu cliente verá a marca d’água nas fotos.</div>
                </div>
                <div class="text-xs text-amber-700 font-extrabold bg-amber-100 border border-amber-200 px-3 py-1 rounded-full" id="wm-current"></div>
              </div>

              <div class="mt-3 text-xs text-slate-600 bg-white border border-slate-200 rounded-xl p-3 shadow-xs">
                <span>Ajuste o tamanho e a transparência da sua marca d'água em tempo real. Use <strong>Ajuste Fino & Posição</strong> para posicionar livremente ou esticar na proporção desejada.</span>
              </div>

              <div class="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
                <!-- Retrato -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div class="flex items-center justify-between">
                    <div class="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                      <i class="fas fa-mobile-screen text-amber-500"></i> Foto vertical (retrato)
                    </div>
                    <span class="text-[11px] font-bold text-slate-400">3:4</span>
                  </div>
                  <div class="ks-wm-frame ks-wm-preview-frame ks-wm-preview-frame--portrait mt-2.5 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                    <div class="ks-wm-ph text-slate-400" id="wm-ph-p">Adicione fotos para ver o preview</div>
                    <img id="wm-preview-portrait" class="hidden" alt="preview marca d’água retrato" />
                  </div>

                  <div class="mt-3 flex items-center justify-between gap-2">
                    <div class="text-xs font-extrabold text-slate-700">Tamanho no retrato</div>
                    <div class="text-xs text-amber-700 font-extrabold font-mono bg-amber-50 px-2 py-0.5 rounded border border-amber-200" id="wm-scale-p-val">120%</div>
                  </div>
                  <input id="wm-scale-p" class="ks-range mt-1.5" type="range" min="10" max="500" step="1" value="120" />
                  <input type="hidden" id="wm-rotate-p" value="0" />

                  <div class="mt-3 pt-3 border-t border-slate-100 space-y-3">
                    <details class="border border-slate-200 rounded-xl bg-slate-50/70 p-2.5 text-xs">
                      <summary class="font-bold text-slate-700 cursor-pointer select-none py-1 flex items-center justify-between">
                        <span><i class="fas fa-sliders text-amber-500 mr-1.5"></i> Ajuste Fino & Posição</span>
                        <i class="fas fa-chevron-down text-slate-400 text-[10px]"></i>
                      </summary>
                      <div class="mt-2.5 pt-2.5 border-t border-slate-200 space-y-3">
                        <div class="flex items-center justify-between gap-2">
                          <div class="text-[11px] font-extrabold text-slate-700">Ajuste fino (passo 3%)</div>
                          <div class="text-[10px] text-slate-500 font-mono" id="wm-logo-offset-val-p">X 0% · Y 0%</div>
                        </div>
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-left-p" title="Esquerda"><i class="fas fa-arrow-left"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-right-p" title="Direita"><i class="fas fa-arrow-right"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-up-p" title="Cima"><i class="fas fa-arrow-up"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-down-p" title="Baixo"><i class="fas fa-arrow-down"></i></button>
                        </div>
                        <div class="pt-2 border-t border-slate-200">
                          <div class="text-xs font-extrabold text-slate-800">Esticar (retrato)</div>
                          <div class="mt-2 flex items-center justify-between gap-2">
                            <div class="text-[11px] font-extrabold text-slate-700">Largura</div>
                            <div class="text-[10px] text-slate-500 font-extrabold" id="wm-stretch-w-val-p">100%</div>
                          </div>
                          <input id="wm-stretch-w-p" class="ks-range mt-1" type="range" min="50" max="400" step="1" value="100" />
                          <div class="mt-2 flex items-center justify-between gap-2">
                            <div class="text-[11px] font-extrabold text-slate-700">Altura</div>
                            <div class="text-[10px] text-slate-500 font-extrabold" id="wm-stretch-h-val-p">100%</div>
                          </div>
                          <input id="wm-stretch-h-p" class="ks-range mt-1" type="range" min="50" max="400" step="1" value="100" />
                        </div>
                      </div>
                    </details>
                  </div>
                </div>

                <!-- Paisagem -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div class="flex items-center justify-between">
                    <div class="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                      <i class="fas fa-tv text-amber-500"></i> Foto horizontal (paisagem)
                    </div>
                    <span class="text-[11px] font-bold text-slate-400">16:9</span>
                  </div>
                  <div class="ks-wm-frame ks-wm-preview-frame ks-wm-preview-frame--landscape mt-2.5 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                    <div class="ks-wm-ph text-slate-400" id="wm-ph-l">Adicione fotos para ver o preview</div>
                    <img id="wm-preview-landscape" class="hidden" alt="preview marca d’água paisagem" />
                  </div>

                  <div class="mt-3 flex items-center justify-between gap-2">
                    <div class="text-xs font-extrabold text-slate-700">Tamanho na paisagem</div>
                    <div class="text-xs text-amber-700 font-extrabold font-mono bg-amber-50 px-2 py-0.5 rounded border border-amber-200" id="wm-scale-l-val">120%</div>
                  </div>
                  <input id="wm-scale-l" class="ks-range mt-1.5" type="range" min="10" max="500" step="1" value="120" />
                  <input type="hidden" id="wm-rotate-l" value="0" />

                  <div class="mt-3 pt-3 border-t border-slate-100 space-y-3">
                    <details class="border border-slate-200 rounded-xl bg-slate-50/70 p-2.5 text-xs">
                      <summary class="font-bold text-slate-700 cursor-pointer select-none py-1 flex items-center justify-between">
                        <span><i class="fas fa-sliders text-amber-500 mr-1.5"></i> Ajuste Fino & Posição</span>
                        <i class="fas fa-chevron-down text-slate-400 text-[10px]"></i>
                      </summary>
                      <div class="mt-2.5 pt-2.5 border-t border-slate-200 space-y-3">
                        <div class="flex items-center justify-between gap-2">
                          <div class="text-[11px] font-extrabold text-slate-700">Ajuste fino (passo 3%)</div>
                          <div class="text-[10px] text-slate-500 font-mono" id="wm-logo-offset-val-l">X 0% · Y 0%</div>
                        </div>
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-left-l" title="Esquerda"><i class="fas fa-arrow-left"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-right-l" title="Direita"><i class="fas fa-arrow-right"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-up-l" title="Cima"><i class="fas fa-arrow-up"></i></button>
                          <button type="button" class="ks-btn text-[10px] cursor-pointer" id="btn-wm-offset-down-l" title="Baixo"><i class="fas fa-arrow-down"></i></button>
                        </div>
                        <div class="pt-2 border-t border-slate-200">
                          <div class="text-xs font-extrabold text-slate-800">Esticar (paisagem)</div>
                          <div class="mt-2 flex items-center justify-between gap-2">
                            <div class="text-[11px] font-extrabold text-slate-700">Largura</div>
                            <div class="text-[10px] text-slate-500 font-extrabold" id="wm-stretch-w-val-l">100%</div>
                          </div>
                          <input id="wm-stretch-w-l" class="ks-range mt-1" type="range" min="50" max="400" step="1" value="100" />
                          <div class="mt-2 flex items-center justify-between gap-2">
                            <div class="text-[11px] font-extrabold text-slate-700">Altura</div>
                            <div class="text-[10px] text-slate-500 font-extrabold" id="wm-stretch-h-val-l">100%</div>
                          </div>
                          <input id="wm-stretch-h-l" class="ks-range mt-1" type="range" min="50" max="400" step="1" value="100" />
                        </div>
                      </div>
                    </details>
                  </div>
                </div>
              </div>

              <div class="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <div class="flex items-center justify-between gap-2">
                  <div class="text-sm font-extrabold text-slate-900">Transparência (opacidade)</div>
                  <div class="text-xs text-amber-700 font-extrabold font-mono bg-amber-50 px-2 py-0.5 rounded border border-amber-200" id="wm-opacity-val">12%</div>
                </div>
                <input id="wm-opacity" class="ks-range mt-2" type="range" min="0" max="100" step="1" value="12" />
                <div class="text-xs text-slate-500 mt-2">0% = quase não aparece. 100% = bem visível.</div>
              </div>

            </div>

            <div class="rounded-2xl border border-slate-200 bg-white p-5 text-slate-800 shadow-sm mt-4">
              <div class="font-extrabold text-slate-900 text-base">Marca d’água atual</div>
              <div class="text-xs text-slate-500 mt-1">Mostra a marca d’água que está valendo (padrão Conecta King ou personalizada).</div>
              <div id="wm-file-defaults" class="mt-4 flex flex-wrap gap-4 items-start">
                <div class="text-xs text-slate-600 max-w-[240px]">
                  <div class="font-bold text-slate-800 mb-2" id="wm-file-ph">Marca Conecta King (fixa — retrato e paisagem)</div>
                  <div class="flex flex-wrap gap-3 items-end">
                    <div class="text-center">
                      <div class="text-[11px] font-bold text-slate-500 mb-1">Retrato</div>
                      <div class="ks-wm-frame mx-auto bg-slate-900 p-1" style="width:112px;aspect-ratio:3/4;max-height:180px">
                        <img id="wm-file-default-portrait" class="w-full h-full object-contain" alt="Marca Conecta King — retrato" src="/marca_dagua_kingselection_vertical.png" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/watermark/marca-dagua-vertical.png'" />
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-[11px] font-bold text-slate-500 mb-1">Paisagem</div>
                      <div class="ks-wm-frame mx-auto bg-slate-900 p-1" style="width:168px;aspect-ratio:16/9;max-height:110px">
                        <img id="wm-file-default-landscape" class="w-full h-full object-contain" alt="Marca Conecta King — paisagem" src="/marca_dagua_kingselection_horizontal.png" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/watermark/marca-dagua-horizontal.png'" />
                      </div>
                    </div>
                  </div>
                  <p class="mt-2 text-slate-500">São os mesmos arquivos oficiais da Conecta King usados nas fotos.</p>
                </div>
              </div>
              <div id="wm-file-custom-wrap" class="mt-4 hidden">
                <div class="text-xs text-slate-600">
                  <div class="font-bold text-slate-800 mb-2" id="wm-file-custom-label">Marca personalizada (enviada)</div>
                  <div class="flex flex-wrap gap-4 items-start">
                    <div>
                      <div class="text-[11px] font-bold text-slate-500 mb-1">Retrato (vertical)</div>
                      <div class="ks-wm-frame bg-slate-900 p-1" id="wm-file-frame-p" style="width:120px;aspect-ratio:3/4;max-height:160px">
                        <img id="wm-file-preview-p" class="hidden w-full h-full object-contain" alt="marca retrato" />
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] font-bold text-slate-500 mb-1">Paisagem (horizontal)</div>
                      <div class="ks-wm-frame bg-slate-900 p-1" id="wm-file-frame-l" style="width:168px;aspect-ratio:16/9;max-height:100px">
                        <img id="wm-file-preview-l" class="hidden w-full h-full object-contain" alt="marca paisagem" />
                      </div>
                    </div>
                  </div>
                  <p class="mt-2 text-slate-500">Dica: PNG com fundo transparente fica mais bonito.</p>
                </div>
              </div>
            </div>

            <div class="flex items-center gap-3 flex-wrap mt-5">
              <input type="file" id="wm-file-p" accept="image/png,image/jpeg,image/webp" class="hidden" />
              <input type="file" id="wm-file-l" accept="image/png,image/jpeg,image/webp" class="hidden" />
              <button type="button" class="ks-btn bg-white hover:bg-slate-50 text-slate-700 border-slate-300 font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm cursor-pointer" id="btn-upload-wm-p"><i class="fas fa-upload text-amber-500 mr-1.5"></i> Enviar retrato</button>
              <button type="button" class="ks-btn bg-white hover:bg-slate-50 text-slate-700 border-slate-300 font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm cursor-pointer" id="btn-upload-wm-l"><i class="fas fa-upload text-amber-500 mr-1.5"></i> Enviar paisagem</button>
              <button type="button" class="ks-btn bg-red-50 hover:bg-red-100 text-red-600 border-red-200 font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm cursor-pointer" id="btn-remove-wm-logo"><i class="fas fa-trash mr-1.5"></i> Remover marca d’água</button>
              <button type="button" class="ks-btn ks-btn-primary bg-amber-500 hover:bg-amber-600 text-white border-amber-600 font-bold text-xs py-2.5 px-6 rounded-xl shadow-md cursor-pointer ml-auto" id="btn-save-wm"><i class="fas fa-save mr-1.5"></i> Salvar</button>
            </div>
            <div class="text-xs ks-muted mt-2">Dica: envie um PNG com fundo transparente.</div>
          </div>
        </div>

        <!-- Facial Recognition -->
        <div class="ks-card p-5 hidden" data-pane="facial">
          <div class="font-extrabold text-slate-900">Reconhecimento Facial</div>
          <div class="mt-4 space-y-4">
            <div class="rounded-2xl border border-slate-200 bg-white p-5">
              <div class="font-extrabold text-slate-900">Configurações de IA</div>
              <div class="text-sm ks-muted mt-1">Controle como a inteligência artificial trabalha nesta galeria.</div>

              <div class="mt-4 flex items-center justify-between gap-4">
                <div>
                  <div class="font-extrabold">Habilitar reconhecimento facial</div>
                  <div class="text-sm ks-muted">Permite que clientes busquem suas fotos usando o rosto.</div>
                </div>
                <label class="inline-flex items-center gap-3 select-none">
                  <input type="checkbox" id="f-face-enabled" class="hidden peer" />
                  <div
                    class="w-12 h-6 bg-slate-200 rounded-full peer-checked:bg-amber-400 relative transition-all cursor-pointer after:content-[''] after:absolute after:top-1 after:left-1 after:bg-white after:w-4 after:h-4 after:rounded-full after:transition-all peer-checked:after:translate-x-6">
                  </div>
                </label>
              </div>

              <div class="mt-6 flex flex-wrap gap-2">
                <button class="ks-btn ks-btn-primary" id="btn-save-facial-config"><i class="fas fa-save"></i> Salvar
                  Configuração</button>
                <button class="ks-btn" id="btn-process-facial-all"><i class="fas fa-wand-magic-sparkles"></i> Processar
                  Todas as Fotos</button>
              </div>
            </div>

            <div class="rounded-2xl border border-slate-200 bg-white p-5">
              <div class="font-extrabold text-slate-900">Status do Processamento</div>
              <div class="mt-3 text-sm flex items-center justify-between">
                <div>Status: <span id="facial-status-label" class="font-bold">Aguardando...</span></div>
                <div id="facial-spinner" class="hidden"><i class="fas fa-spinner fa-spin text-amber-500"></i></div>
              </div>
              <div class="mt-4 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div id="facial-progress-bar" class="bg-amber-400 h-full w-0 transition-all duration-300"></div>
              </div>
              <div class="mt-2 text-xs ks-muted text-right" id="facial-progress-text">0/0 fotos processadas</div>
            </div>
          </div>
        </div>

        <!-- Resolução (preview/download cliente) -->
        <div class="ks-card p-5 hidden" data-pane="image-quality">
          <div class="font-extrabold text-slate-900">Resolução da foto (cliente)</div>
          <div class="mt-2 text-sm ks-muted max-w-3xl">
            Define o tamanho máximo do lado longo das imagens com marca d’água que o visitante vê e baixa na galeria.
            Padrão recomendado para economia de banda: <strong>fraca</strong>. Altere antes de divulgar o link.
          </div>
          <div class="mt-5 space-y-3 max-w-xl">
            <label class="flex items-start gap-3 cursor-pointer rounded-xl border border-slate-200 bg-white p-4 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/40">
              <input type="radio" name="ks-client-img-q" id="ks-imgq-low" value="low" class="mt-1" checked />
              <div>
                <div class="font-extrabold text-slate-900">Fraca (~1200 px)</div>
                <div class="text-sm ks-muted">Carrega rápido; qualidade JPEG moderada.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 cursor-pointer rounded-xl border border-slate-200 bg-white p-4 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/40">
              <input type="radio" name="ks-client-img-q" id="ks-imgq-hd" value="hd" class="mt-1" />
              <div>
                <div class="font-extrabold text-slate-900">HD (~2400 px)</div>
                <div class="text-sm ks-muted">Boa para telas grandes e impressão leve.</div>
              </div>
            </label>
            <label class="flex items-start gap-3 cursor-pointer rounded-xl border border-slate-200 bg-white p-4 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/40">
              <input type="radio" name="ks-client-img-q" id="ks-imgq-max" value="max" class="mt-1" />
              <div>
                <div class="font-extrabold text-slate-900">Máxima (~5000 px)</div>
                <div class="text-sm ks-muted">Arquivos maiores; mais banda e processamento no servidor.</div>
              </div>
            </label>
          </div>
          <div class="mt-6 flex flex-wrap gap-2">
            <button type="button" class="ks-btn ks-btn-primary" id="btn-save-image-quality"><i class="fas fa-save"></i> Salvar resolução</button>
          </div>
        </div>

        <!-- Photos -->
        <div class="ks-card p-5 hidden" data-pane="photos">
          <!-- Overlay de upload (cobre toda a área de Fotos) -->
          <div class="ks-upload-ov hidden" id="ks-upload-ov" aria-hidden="true">
            <div class="ks-upload-card" role="status" aria-live="polite">
              <div class="ks-ring" aria-hidden="true">
                <svg viewBox="0 0 100 100">
                  <circle class="trk" cx="50" cy="50" r="44"></circle>
                  <circle class="bar glow" id="ks-upload-bar" cx="50" cy="50" r="44"></circle>
                </svg>
              </div>
              <div class="min-w-0 flex-1">
                <div class="ttl" id="ks-upload-title">Enviando…</div>
                <div class="sub" id="ks-upload-file">Arquivo: -</div>
                <div class="meta" id="ks-upload-meta">0%</div>
                <div class="ks-upload-actions">
                  <button class="ks-btn" type="button" id="ks-upload-cancel">Cancelar</button>
                </div>
              </div>
            </div>
          </div>

          <div class="ks-photos-upload-sticky">
            <div class="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <div class="font-extrabold text-slate-900">Fotos</div>
                <div class="text-sm ks-muted">Adicionar e gerenciar fotos.</div>
              </div>
              <input type="file" id="p-file" accept="image/*" multiple class="hidden" />
              <input type="file" id="p-folder-file" multiple class="hidden" />
            </div>

            <!-- Upload (bolinha) — mantido no topo ao rolar a grelha -->
            <div class="mt-3">
              <div class="ks-drop" id="ks-drop">
                <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                <div class="min-w-0">
                  <div class="font-extrabold text-slate-900">Arraste e solte suas fotos aqui</div>
                  <div class="text-sm ks-muted mt-1">Você pode selecionar dezenas de fotos. Durante o envio aparece uma
                    bolinha com o progresso.</div>
                </div>
                <div class="flex items-center gap-2 flex-wrap justify-end">
                  <button class="ks-btn" type="button" id="ks-pick-folder" title="Importa uma pasta do computador com todas as subpastas (cria pastas automaticamente pelo caminho)"><i class="fas fa-folder-tree"></i> Pasta e subpastas</button>
                  <button class="ks-btn ks-btn-primary" type="button" id="ks-pick"><i class="fas fa-plus"></i> Adicionar
                    fotos</button>
                </div>
              </div>
              <div class="mt-3 text-xs ks-muted">Dica: se der erro, normalmente é permissão no Cloudflare ou limite
                temporário (aguarde alguns segundos).</div>

              <!-- Redutor Inteligente de Fotos no Upload -->
              <div class="mt-3.5 pt-3 border-t border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-2.5 bg-slate-50/80 -mx-4 -mb-4 px-4 py-3 rounded-b-xl">
                <div class="flex items-center gap-2 text-xs text-slate-700 font-bold">
                  <span class="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-600 flex items-center justify-center font-black">⚡</span>
                  <span>Otimização &amp; Redução Automática no Upload:</span>
                </div>
                <div class="flex items-center gap-1.5 flex-wrap text-xs" id="ks-upload-reducer-radios">
                  <label class="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:border-amber-400 font-semibold transition shadow-2xs">
                    <input type="radio" name="ks-photo-reducer" value="original" class="accent-amber-500 cursor-pointer">
                    <span>Original</span>
                  </label>
                  <label class="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-400 bg-amber-50 text-amber-950 font-extrabold transition shadow-2xs">
                    <input type="radio" name="ks-photo-reducer" value="7mb" checked class="accent-amber-500 cursor-pointer">
                    <span>⚡ Reduzir p/ ~7 MB <span class="text-[10px] text-amber-700 font-normal">(Recomendado)</span></span>
                  </label>
                  <label class="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:border-amber-400 font-semibold transition shadow-2xs">
                    <input type="radio" name="ks-photo-reducer" value="3mb" class="accent-amber-500 cursor-pointer">
                    <span>Reduzir p/ ~3 MB <span class="text-[10px] text-slate-500 font-normal">(Ultra Rápido)</span></span>
                  </label>
                  <label class="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:border-amber-400 font-semibold transition shadow-2xs">
                    <input type="radio" name="ks-photo-reducer" value="10mb" class="accent-amber-500 cursor-pointer">
                    <span>Até ~10 MB</span>
                  </label>
                </div>
              </div>

              <!-- Bolinha de progresso -->
              <div class="ks-bubble hidden" id="ks-bubble">
                <div class="ks-bubble-card" id="ks-bubble-card">
                  <div class="ks-ring" aria-hidden="true">
                    <svg viewBox="0 0 100 100">
                      <circle class="trk" cx="50" cy="50" r="44"></circle>
                      <circle class="bar glow" id="ks-bubble-bar" cx="50" cy="50" r="44"></circle>
                    </svg>
                  </div>
                  <div class="ks-bubble-txt">
                    <div class="ks-bubble-title" id="ks-bubble-title">Enviando…</div>
                    <div class="ks-bubble-file" id="ks-bubble-file">Arquivo: -</div>
                    <div class="ks-bubble-meta" id="ks-bubble-meta">0/0 • 0%</div>
                    <div class="ks-bubble-actions">
                      <button class="ks-btn" type="button" id="ks-bubble-cancel">Cancelar</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>

          <!-- barra de seleção (igual Alboom) -->
          <div class="mt-4 ks-selected-bar" id="p-selected-bar">
            <button class="ks-btn" id="p-select-all"><i class="fas fa-check-double"></i> Selecionar tudo</button>
            <button class="ks-btn" id="p-clear-sel"><i class="fas fa-xmark"></i> Limpar seleção</button>
            <div class="ks-mini"><b id="p-selected-count">0</b> foto(s) selecionada(s)</div>
            <div class="flex items-center gap-2">
              <button class="ks-btn" id="p-download-sel"><i class="fas fa-download"></i> Baixar selecionadas</button>
              <button class="ks-btn" id="p-delete-sel"><i class="fas fa-trash"></i> Excluir selecionadas</button>
            </div>
          </div>

          <div class="mt-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div class="lg:col-span-2 min-w-0">
              <div class="ks-card p-3">
                <div class="flex flex-col gap-2">
                  <button class="ks-btn" id="p-filter-all"><i class="far fa-folder-open"></i> Todas as fotos <span
                      class="ks-badge" id="p-count-all">0</span></button>
                  <button class="ks-btn" id="p-filter-fav"><i class="fas fa-star ks-star"></i> Minhas favoritas <span
                      class="ks-badge" id="p-count-fav">0</span></button>
                  <div class="mt-2">
                    <div class="ks-mini font-extrabold">Buscar por nome</div>
                    <input class="ks-input mt-2" id="p-search" placeholder="Buscar por nome do arquivo" />
                  </div>
                </div>
              </div>
            </div>
            <div class="lg:col-span-10 min-w-0">
              <div class="mt-0 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-3 w-full min-w-0" id="p-grid"></div>
              <div class="mt-4 flex items-center justify-between gap-3 flex-wrap" id="p-pager">
                <div class="text-xs ks-muted" id="p-page-label">Página 1/1</div>
                <div class="flex items-center gap-2">
                  <button class="ks-btn" type="button" id="p-page-prev"><i class="fas fa-chevron-left"></i>
                    Anterior</button>
                  <div class="flex items-center gap-1 flex-wrap" id="p-page-numbers"></div>
                  <button class="ks-btn" type="button" id="p-page-next">Próxima <i
                      class="fas fa-chevron-right"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <!-- Viewer (ampliar foto) -->
  <div id="p-viewer" class="fixed inset-0 hidden items-center justify-center p-4"
    style="background:rgba(0,0,0,.70);z-index:9999;touch-action:none">
    <div class="bg-white w-full max-w-5xl rounded-2xl overflow-hidden border border-slate-200 shadow-2xl">
      <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3 flex-wrap">
        <div class="min-w-0">
          <div class="font-extrabold truncate" id="p-viewer-title">Foto</div>
          <div class="text-xs ks-muted" id="p-viewer-meta">1/1</div>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
          <button class="ks-btn ks-selbtn" id="p-viewer-select" title="Selecionar foto" aria-label="Selecionar"><i
              class="fas fa-check" id="p-viewer-select-icon"></i></button>
          <button class="ks-btn" id="p-viewer-download"><i class="fas fa-download"></i> Baixar foto</button>
          <button class="ks-btn" id="p-viewer-close"><i class="fas fa-times"></i></button>
        </div>
      </div>
      <div class="relative bg-black flex items-center justify-center min-h-[200px]" id="p-viewer-area"
        style="touch-action:pan-y pinch-zoom">
        <button class="absolute left-3 top-1/2 -translate-y-1/2 ks-ico z-10" id="p-viewer-prev" title="Anterior"><i
            class="fas fa-chevron-left"></i></button>
        <button class="absolute right-3 top-1/2 -translate-y-1/2 ks-ico z-10" id="p-viewer-next" title="Próxima"><i
            class="fas fa-chevron-right"></i></button>
        <img id="p-viewer-img" src="" alt="foto"
          style="max-width:100%;max-height:72vh;width:auto;height:auto;object-fit:contain;display:block;touch-action:none"
          draggable="false" />
      </div>
      <div class="px-4 py-3 flex justify-center gap-2 flex-wrap hidden" id="p-viewer-dots" aria-hidden="true"></div>
    </div>
  </div>

  <!-- Modal: Dashboard vendas — detalhe recebido / falta / cortesia -->
  <div id="ks-sales-dash-detail-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);align-items:center;justify-content:center;" aria-hidden="true">
    <div class="w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between gap-3 shrink-0 border-b border-slate-100">
        <div class="font-extrabold text-slate-900 text-base" id="ks-sales-dash-detail-title">Detalhe</div>
        <button type="button" id="ks-sales-dash-detail-close" class="text-slate-400 hover:text-slate-700" aria-label="Fechar" style="background:none;border:none;cursor:pointer;font-size:18px"><i class="fas fa-times"></i></button>
      </div>
      <div class="p-5 overflow-y-auto flex-1 text-slate-800" id="ks-sales-dash-detail-body"></div>
      <div class="px-5 py-3 border-t border-slate-200 bg-slate-50 shrink-0">
        <div class="text-sm font-extrabold text-slate-800" id="ks-sales-dash-detail-total"></div>
      </div>
    </div>
  </div>

  <!-- Modal: Cliente (Adicionar/Editar) -->
  <div id="ks-client-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;align-items:center;justify-content:center;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);" aria-hidden="true">
    <div class="w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between gap-3 border-b border-slate-100">
        <div class="font-extrabold text-base text-slate-900" id="ks-client-modal-title">Adicionar cliente</div>
        <button type="button" id="ks-client-modal-close" class="text-slate-400 hover:text-slate-700"
          style="background:none;border:none;cursor:pointer;font-size:18px"><i class="fas fa-times"></i></button>
      </div>
      <div class="p-5">
        <div class="grid grid-cols-1 gap-4">
          <div class="ks-field">
            <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">Nome</label>
            <input id="ks-client-form-name" class="ks-input mt-2 w-full" placeholder="Nome do cliente" />
          </div>
          <div class="ks-field">
            <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">E-mail</label>
            <input id="ks-client-form-email" type="email" class="ks-input mt-2 w-full" placeholder="E-mail do cliente" />
          </div>
          <div class="ks-field">
            <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">Telefone (opcional)</label>
            <input id="ks-client-form-phone" class="ks-input mt-2 w-full" placeholder="+55 (11) 99999-9999" />
          </div>
          <div class="ks-field">
            <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">Senha</label>
            <div class="flex gap-2 mt-2">
              <input id="ks-client-form-pass" class="ks-input flex-1 font-mono" placeholder="Digite uma nova senha ou deixe vazio para manter" />
              <button type="button" class="ks-btn" id="ks-client-generate-pass" title="Gerar senha aleatória"><i
                  class="fas fa-wand-magic-sparkles"></i> Gerar</button>
            </div>
            <div class="text-xs text-slate-500 mt-1.5">Você pode digitar a senha que preferir ou clicar em Gerar.</div>
          </div>
          <div class="ks-field">
            <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">Nota (opcional)</label>
            <textarea id="ks-client-form-note" class="ks-input mt-2 w-full" style="min-height:90px;font-size:13px;"></textarea>
          </div>
        </div>
      </div>
      <div class="px-5 py-4 flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50">
        <button type="button" class="ks-btn" id="ks-client-cancel">Cancelar</button>
        <button type="button" class="ks-btn ks-btn-primary" id="ks-client-save"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
  </div>

  <!-- Modal: Alterar Senha do Cliente -->
  <div id="ks-client-pass-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;align-items:center;justify-content:center;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);" aria-hidden="true">
    <div class="w-full max-w-md rounded-2xl shadow-2xl overflow-hidden bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between gap-3 border-b border-slate-100">
        <div class="font-extrabold text-slate-900 text-base flex items-center gap-2"><i class="fas fa-key text-amber-500"></i> Alterar Senha do Cliente</div>
        <button type="button" id="ks-client-pass-close" class="text-slate-400 hover:text-slate-700"
          style="background:none;border:none;cursor:pointer;font-size:18px"><i class="fas fa-times"></i></button>
      </div>
      <div class="p-5">
        <div class="text-sm text-slate-700 mb-3" id="ks-client-pass-desc">Defina uma nova senha para o cliente:</div>
        <div class="ks-field">
          <label class="text-xs uppercase font-extrabold tracking-wider text-slate-500">Nova Senha</label>
          <div class="flex gap-2 mt-2">
            <input id="ks-client-pass-input" class="ks-input flex-1 font-mono text-base font-bold text-amber-600" placeholder="Digite a nova senha" autocomplete="off" />
            <button type="button" class="ks-btn" id="ks-client-pass-random" title="Gerar senha aleatória de 6 dígitos"><i class="fas fa-wand-magic-sparkles"></i> Gerar</button>
          </div>
          <div class="text-xs text-slate-500 mt-2">A nova senha passará a valer imediatamente no login da galeria.</div>
        </div>
      </div>
      <div class="px-5 py-4 flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50">
        <button type="button" class="ks-btn" id="ks-client-pass-cancel">Cancelar</button>
        <button type="button" class="ks-btn ks-btn-primary" id="ks-client-pass-save"><i class="fas fa-check"></i> Salvar Senha</button>
      </div>
    </div>
  </div>

  <!-- Modal: Compartilhar acesso do cliente -->
  <div id="ks-client-share-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;align-items:center;justify-content:center;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);" aria-hidden="true">
    <div class="w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between gap-3 border-b border-slate-100">
        <div class="font-extrabold text-base text-slate-900">Compartilhar acesso</div>
        <button type="button" id="ks-client-share-close" class="text-slate-400 hover:text-slate-700"
          style="background:none;border:none;cursor:pointer;font-size:18px"><i class="fas fa-times"></i></button>
      </div>
      <div class="p-5">
        <div class="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500 font-extrabold" style="letter-spacing:.18em;text-transform:uppercase">Dados de acesso do cliente</div>
          <div class="mt-3 text-sm space-y-2">
            <div><span class="text-slate-500">Link:</span> <span class="ks-link break-all font-mono text-xs text-amber-700 font-bold" id="ks-client-share-link">-</span></div>
            <div><span class="text-slate-500">E-mail:</span> <span id="ks-client-share-email" class="font-mono text-xs text-slate-800 font-semibold">-</span></div>
            <div><span class="text-slate-500">Senha:</span> <span class="font-mono text-base font-bold text-amber-600" id="ks-client-share-pass">••••••</span></div>
          </div>
          <button class="ks-btn ks-btn-primary mt-4 w-full" id="ks-client-share-copy"><i class="fas fa-copy"></i> Copiar Mensagem Completa</button>
        </div>

        <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button class="ks-btn" id="ks-client-share-whats"><i class="fab fa-whatsapp text-emerald-600"></i> Enviar por WhatsApp</button>
          <button class="ks-btn"
            onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('ks-client-share-link')?.textContent||'')"><i
              class="fas fa-link"></i> Copiar só o link</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: dados do cliente (atividades) — copiar nome, e-mail, telefone -->
  <div id="ks-act-contact-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);align-items:center;justify-content:center;" aria-hidden="true">
    <div class="w-full max-w-md rounded-2xl shadow-2xl overflow-hidden bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between gap-3 border-b border-slate-100">
        <div class="font-extrabold text-slate-900 text-base">Dados do cliente</div>
        <button type="button" id="ks-act-contact-close" class="text-slate-400 hover:text-slate-700" aria-label="Fechar" style="background:none;border:none;cursor:pointer;font-size:18px"><i
            class="fas fa-times"></i></button>
      </div>
      <div class="p-5 space-y-3 text-sm text-slate-800">
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-1">Nome</div>
          <div class="flex gap-2 items-center">
            <span id="ks-act-contact-nome" class="flex-1 min-w-0 break-words font-medium text-slate-900">—</span>
            <button type="button" class="ks-btn ks-btn-primary shrink-0 text-xs px-3 py-1.5" data-ks-act-copy="nome"><i class="fas fa-copy"></i></button>
          </div>
        </div>
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-1">E-mail</div>
          <div class="flex gap-2 items-center">
            <span id="ks-act-contact-email" class="flex-1 min-w-0 break-all font-mono text-xs text-slate-900 font-semibold">—</span>
            <button type="button" class="ks-btn ks-btn-primary shrink-0 text-xs px-3 py-1.5" data-ks-act-copy="email"><i class="fas fa-copy"></i></button>
          </div>
        </div>
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-1">Telefone</div>
          <div class="flex gap-2 items-center">
            <span id="ks-act-contact-phone" class="flex-1 min-w-0 break-all font-mono text-xs text-slate-900 font-semibold">—</span>
            <button type="button" class="ks-btn ks-btn-primary shrink-0 text-xs px-3 py-1.5" data-ks-act-copy="phone"><i class="fas fa-copy"></i></button>
          </div>
        </div>
        <button type="button" class="ks-btn w-full mt-2" id="ks-act-contact-copy-all"><i class="fas fa-copy"></i> Copiar tudo (texto)</button>
      </div>
    </div>
  </div>

  <!-- Export modal simples -->
  <div id="ks-export-modal" class="fixed inset-0 hidden items-center justify-center p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.6);z-index:999999;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);align-items:center;justify-content:center;">
    <div class="w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden bg-white text-slate-800 border border-slate-200">
      <div class="px-5 py-4 flex items-center justify-between border-b border-slate-100">
        <div class="font-extrabold text-slate-900 text-base">Exportar fotos</div>
        <button id="ks-export-close" class="text-slate-400 hover:text-slate-700" style="background:none;border:none;cursor:pointer;font-size:18px"><i class="fas fa-times"></i></button>
      </div>
      <div class="p-5">
        <div class="text-xs font-extrabold text-slate-500 uppercase tracking-[0.14em] mb-2">Seleção (lote)</div>
        <select id="ks-export-batch" class="ks-input mb-4" title="Exportar só fotos escolhidas nesta seleção (lote)">
          <option value="all">Todas as seleções</option>
        </select>
        <div class="text-xs font-extrabold text-slate-500 uppercase tracking-[0.14em] mb-2">O que incluir na lista</div>
        <div class="flex flex-col gap-2 text-sm text-slate-700">
          <label class="flex items-start gap-2 cursor-pointer">
            <input type="radio" name="ks-export-scope" id="ks-export-scope-all" value="all" checked class="mt-1" />
            <span>Todas as fotos selecionadas pelo cliente</span>
          </label>
          <label class="flex items-start gap-2 cursor-pointer">
            <input type="radio" name="ks-export-scope" id="ks-export-scope-filter" value="filter" class="mt-1" />
            <span>Só as que eu indicar abaixo (números ou código tipo <code class="text-xs bg-slate-100 px-1 rounded">ADR0003</code>)</span>
          </label>
        </div>
        <p id="ks-export-all-hint" class="text-xs text-slate-500 mt-2 leading-relaxed min-h-[1.25rem]"></p>
        <div id="ks-export-filter-block" class="hidden mt-3">
          <textarea id="ks-export-filter-input" class="ks-input" rows="3"
            placeholder="IDs do sistema (ex.: 1642) ou código no ficheiro (3, ADR0003) — vírgula ou linha"
            style="font-size:13px"></textarea>
          <div class="mt-2 flex flex-wrap gap-2 items-center">
            <button type="button" id="ks-export-filter-apply" class="ks-btn flex items-center gap-2">
              <i class="fas fa-search" aria-hidden="true"></i> Aplicar filtro
            </button>
            <span class="text-xs text-slate-500">Atualiza a lista para copiar (também atualiza ao digitar).</span>
          </div>
          <p id="ks-export-filter-hint" class="text-xs text-slate-500 mt-2 leading-relaxed"></p>
        </div>
        <div class="text-xs font-extrabold text-slate-500 uppercase tracking-[0.14em] mt-4 mb-2">Formato da cópia</div>
        <div class="flex gap-2 flex-wrap">
          <button type="button" class="ks-btn" data-exp="lightroom">Lightroom</button>
          <button type="button" class="ks-btn" data-exp="finder">Finder (Mac)</button>
          <button type="button" class="ks-btn" data-exp="windows">Windows</button>
        </div>
        <textarea id="ks-export-ta" class="ks-input ks-export-ta mt-4"
          style="min-height:160px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;font-size:12px"></textarea>
        <button class="ks-btn ks-btn-primary mt-4 w-full" id="ks-export-copy"><i class="fas fa-copy"></i>
          Copiar</button>
      </div>
    </div>
  </div>

  <!-- Modal: Ajustar e Importar Marca D'água Interativa -->
  <div id="ks-modal-wm-import" class="fixed inset-0 hidden items-center justify-center p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.65);z-index:999999;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);align-items:center;justify-content:center;" aria-hidden="true">
    <div class="w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col bg-white text-slate-800 border border-slate-200">
      <div class="px-6 py-4 flex items-center justify-between gap-3 shrink-0 border-b border-slate-100 bg-slate-50/60">
        <div>
          <div class="font-extrabold text-slate-900 text-base sm:text-lg flex items-center gap-2">
            <i class="fas fa-magic text-amber-500"></i> <span id="ks-wm-import-title">Ajustar Marca D'água antes de Enviar</span>
          </div>
          <div class="text-xs text-slate-500 mt-0.5" id="ks-wm-import-subtitle">
            Dimensões originais: <b id="ks-wm-import-dims" class="text-slate-800 font-mono">-</b> · Arquivo: <span id="ks-wm-import-filename" class="font-mono text-slate-700">-</span>
          </div>
        </div>
        <button type="button" id="ks-wm-import-close" class="text-slate-400 hover:text-slate-700 p-2" aria-label="Fechar"
          style="background:none;border:none;cursor:pointer;font-size:20px"><i class="fas fa-times"></i></button>
      </div>

      <div class="p-5 sm:p-6 overflow-y-auto flex-1 grid grid-cols-1 md:grid-cols-12 gap-6">
        <!-- Visualizador interativo em tempo real -->
        <div class="md:col-span-7 flex flex-col">
          <div class="text-xs font-bold text-slate-700 mb-2 flex items-center justify-between">
            <span>Prévia Interativa na Foto (<span id="ks-wm-import-aspect-label">Paisagem 16:9</span>)</span>
            <span class="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full font-semibold">Tempo Real</span>
          </div>
          <div class="relative w-full rounded-xl overflow-hidden border border-slate-300 bg-slate-950 flex items-center justify-center select-none" id="ks-wm-import-canvas-box" style="aspect-ratio: 16/9; max-height: 380px;">
            <!-- Foto de fundo (amostra da galeria) -->
            <img id="ks-wm-import-bg" src="" alt="Fundo" class="absolute inset-0 w-full h-full object-cover pointer-events-none opacity-90" />
            <!-- Marca d'água sobreposta que reage aos sliders -->
            <div id="ks-wm-import-overlay-wrap" class="absolute inset-0 flex items-center justify-center pointer-events-none" style="overflow:hidden;">
              <img id="ks-wm-import-overlay" src="" alt="Marca d'água" class="pointer-events-none" style="max-width:none; transition: none;" />
            </div>
          </div>
          <div class="mt-2 text-[11px] text-slate-500 text-center">
            Esta prévia mostra exatamente como a marca d'água será estampada sobre suas fotos desta orientação.
          </div>
        </div>

        <!-- Controles de ajuste -->
        <div class="md:col-span-5 flex flex-col justify-between space-y-4">
          <div class="space-y-3.5">
            <!-- Tamanho / Escala -->
            <div class="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-expand text-amber-500"></i> Tamanho (Escala)</span>
                <span id="ks-wm-import-scale-val" class="font-mono text-amber-700 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded">100%</span>
              </div>
              <input type="range" id="ks-wm-import-scale" min="10" max="400" step="1" value="100" class="ks-range mt-2" />
            </div>

            <!-- Transparência / Opacidade -->
            <div class="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-droplet text-amber-500"></i> Transparência</span>
                <span id="ks-wm-import-opacity-val" class="font-mono text-amber-700 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded">25%</span>
              </div>
              <input type="range" id="ks-wm-import-opacity" min="5" max="100" step="1" value="25" class="ks-range mt-2" />
            </div>

            <!-- Proporção & Esticar livre -->
            <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-arrows-alt text-amber-500"></i> Proporção Livre / Esticar</span>
                <label class="text-[11px] font-semibold text-slate-600 flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" id="ks-wm-import-lock-ratio" checked class="rounded border-slate-300 text-amber-600 focus:ring-amber-500" />
                  <span>Travar proporção</span>
                </label>
              </div>
              <div>
                <div class="flex items-center justify-between text-[11px] text-slate-600">
                  <span>Largura</span>
                  <span id="ks-wm-import-stretch-w-val" class="font-mono font-bold text-slate-700">100%</span>
                </div>
                <input type="range" id="ks-wm-import-stretch-w" min="40" max="300" step="1" value="100" class="ks-range mt-1" />
              </div>
              <div>
                <div class="flex items-center justify-between text-[11px] text-slate-600">
                  <span>Altura</span>
                  <span id="ks-wm-import-stretch-h-val" class="font-mono font-bold text-slate-700">100%</span>
                </div>
                <input type="range" id="ks-wm-import-stretch-h" min="40" max="300" step="1" value="100" class="ks-range mt-1" />
              </div>
            </div>

            <!-- Ajuste Fino de Posição -->
            <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-arrows-to-dot text-amber-500"></i> Ajuste Fino de Posição</span>
                <button type="button" id="ks-wm-import-reset-pos" class="text-[10px] text-amber-700 hover:text-amber-800 font-bold bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-0.5 rounded cursor-pointer">Centralizar</button>
              </div>
              <div class="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <div class="flex justify-between text-slate-600"><span>Horizontal (X)</span><span id="ks-wm-import-off-x-val" class="font-mono font-bold text-slate-700">0%</span></div>
                  <input type="range" id="ks-wm-import-off-x" min="-50" max="50" step="1" value="0" class="ks-range mt-1" />
                </div>
                <div>
                  <div class="flex justify-between text-slate-600"><span>Vertical (Y)</span><span id="ks-wm-import-off-y-val" class="font-mono font-bold text-slate-700">0%</span></div>
                  <input type="range" id="ks-wm-import-off-y" min="-50" max="50" step="1" value="0" class="ks-range mt-1" />
                </div>
              </div>
            </div>
          </div>

          <div class="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
            <button type="button" id="ks-wm-import-cancel" class="ks-btn text-xs px-4 py-2 font-bold cursor-pointer">Cancelar</button>
            <button type="button" id="ks-wm-import-apply" class="ks-btn ks-btn-primary text-xs px-5 py-2 font-extrabold cursor-pointer flex items-center gap-2">
              <i class="fas fa-check"></i> Salvar e Aplicar
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: Gerador Inteligente de Marca d'Água (Grade + Logo Branca) -->
  <div id="ks-modal-wm-generator" class="fixed inset-0 hidden items-center justify-center p-3 sm:p-4"
    style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,.7);z-index:999999;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);align-items:center;justify-content:center;" aria-hidden="true">
    <div class="w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden max-h-[94vh] flex flex-col bg-white text-slate-800 border border-slate-200">
      <!-- Topo Modal -->
      <div class="px-5 py-3.5 sm:px-6 sm:py-4 flex items-center justify-between gap-3 shrink-0 border-b border-slate-100 bg-gradient-to-r from-amber-50/70 via-white to-slate-50">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-600 flex items-center justify-center shrink-0">
            <i class="fas fa-wand-magic-sparkles text-lg"></i>
          </div>
          <div>
            <div class="font-extrabold text-slate-900 text-base sm:text-lg flex items-center gap-2">
              Gerador Automático de Marca d'Água
              <span class="text-[10px] uppercase font-black bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">Exclusivo</span>
            </div>
            <div class="text-xs text-slate-500 mt-0.5">
              Envie sua logo em qualquer cor: criamos as grades e a logo branca nos dois formatos (retrato e paisagem).
            </div>
          </div>
        </div>
        <button type="button" id="ks-wm-gen-close" class="text-slate-400 hover:text-slate-700 p-2 cursor-pointer" aria-label="Fechar"
          style="background:none;border:none;font-size:20px"><i class="fas fa-times"></i></button>
      </div>

      <!-- Corpo Modal: 2 Colunas -->
      <div class="p-5 sm:p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Coluna Esquerda: Controles -->
        <div class="lg:col-span-5 flex flex-col space-y-4">
          <!-- 1. Enviar Logo -->
          <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4">
            <div class="text-xs font-extrabold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <i class="fas fa-cloud-arrow-up text-amber-500"></i> 1. Selecione sua Logo
            </div>
            <input type="file" id="ks-wm-gen-file" accept="image/png,image/jpeg,image/webp" class="hidden" />
            <div id="ks-wm-gen-dropzone" class="border-2 border-dashed border-slate-300 hover:border-amber-400 rounded-xl p-4 text-center cursor-pointer bg-white transition hover:bg-amber-50/30">
              <div id="ks-wm-gen-no-file">
                <i class="fas fa-image text-3xl text-slate-400 mb-2"></i>
                <div class="text-xs font-extrabold text-slate-700">Clique ou arraste a imagem da sua logo</div>
                <div class="text-[11px] text-slate-500 mt-0.5">Qualquer cor (PNG transparente ou JPEG)</div>
              </div>
              <div id="ks-wm-gen-has-file" class="hidden flex items-center gap-3 text-left">
                <div class="w-12 h-12 rounded-lg bg-slate-900 border border-slate-200 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                  <img id="ks-wm-gen-thumb" src="" alt="Logo" class="w-full h-full object-contain" />
                </div>
                <div class="min-w-0 flex-1">
                  <div class="text-xs font-bold text-slate-800 truncate" id="ks-wm-gen-filename">logo.png</div>
                  <div class="text-[10px] text-slate-500" id="ks-wm-gen-dimensions">1000 × 500 px</div>
                  <button type="button" id="ks-wm-gen-change-btn" class="text-[10px] text-amber-700 hover:text-amber-800 font-extrabold underline mt-0.5 cursor-pointer">Trocar imagem</button>
                </div>
              </div>
            </div>
          </div>

          <!-- 2. Cor da Logo -->
          <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2.5">
            <div class="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <i class="fas fa-palette text-amber-500"></i> 2. Cor da Logo
            </div>
            <div class="grid grid-cols-2 gap-2 text-xs">
              <button type="button" data-wm-color="white" class="ks-wm-color-btn active flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-amber-400 bg-white text-slate-800 font-extrabold shadow-xs cursor-pointer">
                <span class="w-3.5 h-3.5 rounded-full bg-white border border-slate-300 shadow-xs"></span> Branco Puro
              </button>
              <button type="button" data-wm-color="gold" class="ks-wm-color-btn flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:border-slate-300 cursor-pointer">
                <span class="w-3.5 h-3.5 rounded-full bg-amber-500 shadow-xs"></span> Dourado King
              </button>
              <button type="button" data-wm-color="black" class="ks-wm-color-btn flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:border-slate-300 cursor-pointer">
                <span class="w-3.5 h-3.5 rounded-full bg-slate-900 shadow-xs"></span> Preto
              </button>
              <button type="button" data-wm-color="original" class="ks-wm-color-btn flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:border-slate-300 cursor-pointer">
                <i class="fas fa-brush text-slate-400 text-xs"></i> Original
              </button>
            </div>
            <p class="text-[11px] text-slate-500">
              * Branco puro é a cor ideal e recomendada para destacar em todas as fotos.
            </p>
          </div>

          <!-- 3. Distribuição das Logos & Grade Anti-Print -->
          <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div class="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <i class="fas fa-shield-halved text-amber-500"></i> 3. Distribuição das Logos & Grade
            </div>
            <div class="grid grid-cols-1 gap-2 text-xs">
              <button type="button" data-wm-grid="conecta_king" class="ks-wm-grid-btn active py-2.5 px-3 rounded-xl border border-amber-400 bg-white text-slate-800 font-extrabold shadow-xs text-left cursor-pointer flex items-center justify-between">
                <div>
                  <div class="font-extrabold text-slate-900 flex items-center gap-1.5"><i class="fas fa-crown text-amber-500"></i> Grade Conecta King (Rosto Livre)</div>
                  <div class="text-[11px] font-medium text-slate-500 mt-0.5">Logos entre as linhas da grade e centro livre para ver o rosto perfeitamente</div>
                </div>
                <i class="fas fa-check-circle text-amber-500 text-sm"></i>
              </button>
              <button type="button" data-wm-grid="all_cells" class="ks-wm-grid-btn py-2 px-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:border-slate-300 text-left cursor-pointer flex items-center justify-between">
                <div>
                  <div class="font-extrabold text-slate-800">Logos em Todas as Células</div>
                  <div class="text-[11px] font-medium text-slate-500 mt-0.5">A logo se repete em cada diamante ao redor do centro (proteção total)</div>
                </div>
              </button>
              <button type="button" data-wm-grid="corners_only" class="ks-wm-grid-btn py-2 px-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:border-slate-300 text-left cursor-pointer flex items-center justify-between">
                <div>
                  <div class="font-extrabold text-slate-800">Logos Discretas nas Bordas</div>
                  <div class="text-[11px] font-medium text-slate-500 mt-0.5">Linhas em toda a foto, mas logos presentes apenas nas bordas</div>
                </div>
              </button>
            </div>

            <!-- Slider Transparência das Linhas da Grade -->
            <div class="pt-2 border-t border-slate-200/80">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-border-all text-amber-500"></i> Transparência das Linhas da Grade</span>
                <span id="ks-wm-gen-transp-val" class="font-mono text-amber-800 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded font-bold text-xs">20%</span>
              </div>
              <input type="range" id="ks-wm-gen-transp" min="5" max="80" step="1" value="20" class="ks-range mt-1.5" />
              <div class="text-[10px] text-slate-500 mt-0.5">Controla a intensidade das linhas diagonais da grade.</div>
            </div>

            <!-- Slider Opacidade das Logos na Grade (Independente) -->
            <div class="pt-1.5">
              <div class="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span class="flex items-center gap-1.5"><i class="fas fa-droplet text-amber-500"></i> Opacidade da Logo</span>
                <span id="ks-wm-gen-logo-op-val" class="font-mono text-amber-800 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded font-bold text-xs">45%</span>
              </div>
              <input type="range" id="ks-wm-gen-logo-op" min="5" max="100" step="1" value="45" class="ks-range mt-1.5" />
              <div class="text-[10px] text-slate-500 mt-0.5">Deixe a logo mais suave ou mais nítida que as linhas conforme desejar.</div>
            </div>

            <!-- Slider Tamanho das Logos na Grade -->
            <div class="pt-1.5">
              <div class="flex items-center justify-between text-xs font-bold text-slate-700">
                <span class="flex items-center gap-1.5"><i class="fas fa-expand text-amber-500"></i> Tamanho das Logos na Grade</span>
                <span id="ks-wm-gen-scale-val" class="font-mono text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded text-[11px]">55%</span>
              </div>
              <input type="range" id="ks-wm-gen-scale" min="20" max="85" step="1" value="55" class="ks-range mt-1" />
            </div>

            <!-- Densidade dos Diamantes -->
            <div class="pt-1">
              <label class="block text-[11px] font-bold text-slate-700 mb-1">
                Densidade dos Diamantes da Grade:
              </label>
              <div class="grid grid-cols-3 gap-1.5 text-xs">
                <button type="button" data-wm-density="compact" class="ks-wm-density-btn py-1.5 px-2 rounded-lg border border-slate-200 bg-white text-slate-700 font-semibold text-center cursor-pointer">
                  Mais Logos
                </button>
                <button type="button" data-wm-density="normal" class="ks-wm-density-btn active py-1.5 px-2 rounded-lg border border-amber-400 bg-amber-50 text-amber-900 font-extrabold text-center cursor-pointer">
                  Padrão King
                </button>
                <button type="button" data-wm-density="spaced" class="ks-wm-density-btn py-1.5 px-2 rounded-lg border border-slate-200 bg-white text-slate-700 font-semibold text-center cursor-pointer">
                  Espaçado
                </button>
              </div>
            </div>

            <!-- Texto de Proteção / Nome do Fotógrafo -->
            <div class="pt-1">
              <label for="ks-wm-gen-text" class="block text-[11px] font-bold text-slate-700 mb-1">
                Texto / Nome do Fotógrafo nos Diamantes:
              </label>
              <input type="text" id="ks-wm-gen-text" placeholder="Ex.: Adriano King Fotografia • Proibida Reprodução"
                class="ks-input text-xs w-full py-2 px-3 rounded-xl border-slate-200 bg-white" />
              <div class="text-[10px] text-slate-500 mt-1">Intercalado na diagonal entre as logos, idêntico à marca d'água oficial.</div>
            </div>
          </div>
        </div>

        <!-- Coluna Direita: Pré-visualização Dupla em Tempo Real (Vertical + Quadrada / Paisagem) -->
        <div class="lg:col-span-7 flex flex-col space-y-4">
          <div class="flex items-center justify-between flex-wrap gap-2">
            <div class="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <i class="fas fa-eye text-amber-500"></i> Prévia em Tempo Real
            </div>
            <div class="flex items-center gap-1">
              <span class="text-[11px] text-slate-500 mr-1">Orientação secundária:</span>
              <button type="button" id="ks-wm-btn-mode-square" class="text-[11px] px-2.5 py-1 rounded-lg border border-amber-400 bg-amber-50 text-amber-900 font-extrabold cursor-pointer">
                Quadrada (1:1)
              </button>
              <button type="button" id="ks-wm-btn-mode-landscape" class="text-[11px] px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-slate-600 font-semibold hover:border-slate-300 cursor-pointer">
                Paisagem (16:9)
              </button>
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <!-- Prévia Retrato / Vertical (3:4) -->
            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3 flex flex-col shadow-xs">
              <div class="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                <span class="flex items-center gap-1"><i class="fas fa-mobile-screen text-amber-500"></i> Retrato (Vertical)</span>
                <span class="text-[10px] text-slate-400 font-mono">3:4</span>
              </div>
              <div class="relative w-full rounded-xl overflow-hidden border border-slate-300 bg-slate-950 flex items-center justify-center" style="aspect-ratio: 3/4;">
                <img id="ks-wm-gen-bg-p" src="" alt="Fundo" class="absolute inset-0 w-full h-full object-cover opacity-90" />
                <canvas id="ks-wm-gen-canvas-p" class="absolute inset-0 w-full h-full pointer-events-none"></canvas>
              </div>
              <div class="mt-2 text-[10px] text-slate-500 text-center font-medium">
                Várias logos e grade cobrindo a foto vertical inteira.
              </div>
            </div>

            <!-- Prévia Secundária: Quadrada (1:1) ou Paisagem (16:9) -->
            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3 flex flex-col shadow-xs">
              <div class="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                <span class="flex items-center gap-1">
                  <i class="fas fa-square text-amber-500" id="ks-wm-secondary-icon"></i>
                  <span id="ks-wm-secondary-title">Quadrada (1:1)</span>
                </span>
                <span class="text-[10px] text-slate-400 font-mono" id="ks-wm-secondary-ratio">1:1</span>
              </div>
              <div class="relative w-full rounded-xl overflow-hidden border border-slate-300 bg-slate-950 flex items-center justify-center" id="ks-wm-secondary-box" style="aspect-ratio: 1/1;">
                <img id="ks-wm-gen-bg-l" src="" alt="Fundo" class="absolute inset-0 w-full h-full object-cover opacity-90" />
                <canvas id="ks-wm-gen-canvas-l" class="absolute inset-0 w-full h-full pointer-events-none"></canvas>
              </div>
              <div class="mt-2 text-[10px] text-slate-500 text-center font-medium" id="ks-wm-secondary-desc">
                Grade com múltiplas logos perfeitamente distribuídas.
              </div>
            </div>
          </div>

          <div class="rounded-xl border border-amber-200/80 bg-amber-50/70 p-3.5 text-xs text-amber-950 flex items-start gap-2.5">
            <i class="fas fa-shield-halved text-amber-600 mt-0.5 text-sm shrink-0"></i>
            <div>
              <strong>Proteção Anti-Print Idêntica à Conecta King:</strong> As fotos verticais e quadradas/paisagens recebem a grade diamante com as múltiplas logos distribuídas e a transparência uniforme, protegendo o trabalho fotográfico com elegância sem cobrir o rosto dos clientes!
            </div>
          </div>
        </div>
      </div>

      <!-- Rodapé Modal -->
      <div class="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3 shrink-0">
        <button type="button" id="ks-wm-gen-cancel" class="ks-btn text-xs px-4 py-2 font-bold cursor-pointer">
          Cancelar
        </button>
        <button type="button" id="ks-wm-gen-apply" class="ks-btn ks-btn-primary text-xs px-6 py-2.5 font-extrabold cursor-pointer flex items-center gap-2 shadow-md" style="background: linear-gradient(135deg, #f59e0b, #d97706) !important; color: #ffffff !important; border: none !important;">
          <i class="fas fa-wand-magic-sparkles"></i> Gerar e Aplicar na Galeria
        </button>
      </div>
    </div>
  </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: fotos repetidas -->
  <div class="ks-dupe-ov hidden" id="ks-dupe-ov" aria-hidden="true">
    <div class="ks-dupe-card" role="dialog" aria-modal="true" aria-labelledby="ks-dupe-title">
      <div class="ks-dupe-head">
        <div class="ks-dupe-title" id="ks-dupe-title">Fotos repetidas detectadas</div>
        <button type="button" class="ks-btn" id="ks-dupe-close" title="Fechar"><i class="fas fa-times"></i></button>
      </div>
      <div class="ks-dupe-body">
        <div class="hint" id="ks-dupe-hint">Encontramos fotos com o mesmo código/nome já existente nesta galeria.</div>
        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          <div class="rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden">
            <div
              class="px-4 py-3 border-b border-slate-200 text-xs font-extrabold tracking-[0.18em] uppercase text-slate-700">
              Atual na galeria</div>
            <div class="p-3">
              <div class="rounded-xl overflow-hidden border border-slate-200 bg-slate-100" style="aspect-ratio: 4 / 3;">
                <img id="ks-dupe-img-old" alt="foto atual" decoding="async" fetchpriority="low"
                  style="width:100%;height:100%;object-fit:contain;display:block;background:#0f172a" />
              </div>
              <div class="mt-2 text-xs text-slate-700 font-mono truncate" id="ks-dupe-old-name">-</div>
            </div>
          </div>
          <div class="rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden">
            <div
              class="px-4 py-3 border-b border-slate-200 text-xs font-extrabold tracking-[0.18em] uppercase text-slate-700">
              Nova (que você selecionou)</div>
            <div class="p-3">
              <div class="rounded-xl overflow-hidden border border-slate-200 bg-slate-100" style="aspect-ratio: 4 / 3;">
                <img id="ks-dupe-img-new" alt="nova foto" decoding="async" fetchpriority="low"
                  style="width:100%;height:100%;object-fit:contain;display:block;background:#0f172a" />
              </div>
              <div class="mt-2 text-xs text-slate-700 font-mono truncate" id="ks-dupe-new-name">-</div>
            </div>
          </div>
        </div>

        <div class="mt-4">
          <div class="text-xs font-extrabold tracking-[0.18em] uppercase text-slate-500">Lista de repetidas</div>
          <div class="ks-dupe-list" id="ks-dupe-list"></div>
        </div>
      </div>
      <div class="ks-dupe-actions">
        <button type="button" class="ks-btn" id="ks-dupe-skip">Ignorar repetidas</button>
        <button type="button" class="ks-btn ks-btn-primary" id="ks-dupe-replace">Substituir existentes</button>
        <button type="button" class="ks-btn" id="ks-dupe-keep">Enviar mesmo assim</button>
      </div>
    </div>
  </div>

  <!-- Toast host -->
  <div class="ks-toast-host" id="ks-toast-host" aria-live="polite" aria-atomic="true"></div>

  <!-- Script Hambúrguer Seja Fit -->
  <script>
    (function () {
      function initHamburger() {
        const btn = document.getElementById('ks-btn-hamburger');
        const container = document.getElementById('ks-main-container');
        if (!btn || !container) return;

        // Recupera estado salvo (padrão: aberto)
        const isCollapsed = localStorage.getItem('ks_sidebar_collapsed') === 'true';
        if (isCollapsed) {
          container.classList.add('ks-sidebar-collapsed');
        }

        btn.addEventListener('click', function (e) {
          e.preventDefault();
          const collapsed = container.classList.toggle('ks-sidebar-collapsed');
          localStorage.setItem('ks_sidebar_collapsed', collapsed ? 'true' : 'false');
        });
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHamburger);
      } else {
        initHamburger();
      }

      // Inicialização do Avatar e Perfil do Usuário
      function initUserAvatar() {
        const avatarBtn = document.getElementById('ks-user-avatar-btn');
        const dropdown = document.getElementById('ks-user-dropdown');
        const logoutBtn = document.getElementById('ks-user-logout-btn');

        if (!avatarBtn || !dropdown) return;

        avatarBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const isHidden = dropdown.style.display === 'none' || !dropdown.style.display;
          dropdown.style.display = isHidden ? 'block' : 'none';
        });

        document.addEventListener('click', (e) => {
          if (!dropdown.contains(e.target) && !avatarBtn.contains(e.target)) {
            dropdown.style.display = 'none';
          }
        });

        logoutBtn?.addEventListener('click', () => {
          if (confirm('Deseja realmente sair?')) {
            localStorage.removeItem('conectaKingToken');
            localStorage.removeItem('token');
            localStorage.removeItem('conectaKingUser');
            window.location.href = '/login';
          }
        });

        try {
          const rawUser = localStorage.getItem('conectaKingUser') || localStorage.getItem('user');
          if (rawUser) {
            const user = JSON.parse(rawUser);
            const name = user.name || user.display_name || user.nome || 'Conecta King';
            const email = user.email || '';
            const photo = user.profile_image_url || user.photo || user.avatar || '';

            const nameEl = document.getElementById('ks-user-name-display');
            const dropNameEl = document.getElementById('ks-user-dropdown-name');
            const dropEmailEl = document.getElementById('ks-user-dropdown-email');
            const imgEl = document.getElementById('ks-user-avatar-img');
            const dropImgEl = document.getElementById('ks-user-dropdown-img');
            const initEl = document.getElementById('ks-user-avatar-initials');
            const dropInitEl = document.getElementById('ks-user-dropdown-initials');

            if (nameEl) nameEl.textContent = name;
            if (dropNameEl) dropNameEl.textContent = name;
            if (dropEmailEl && email) dropEmailEl.textContent = email;

            const initials = name.split(' ').map(n => n[0]).filter(Boolean).slice(0, 2).join('').toUpperCase() || 'CK';
            if (initEl) initEl.textContent = initials;
            if (dropInitEl) dropInitEl.textContent = initials;

            if (photo && photo !== 'null') {
              if (imgEl) {
                imgEl.src = photo;
                imgEl.style.display = 'block';
                if (initEl) initEl.style.display = 'none';
              }
              if (dropImgEl) {
                dropImgEl.src = photo;
                dropImgEl.style.display = 'block';
                if (dropInitEl) dropInitEl.style.display = 'none';
              }
            }
          }
        } catch (e) {
          console.warn('Erro ao carregar avatar do usuário:', e);
        }
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initUserAvatar);
      } else {
        initUserAvatar();
      }
    })();
  </script>

</body>

</html>
