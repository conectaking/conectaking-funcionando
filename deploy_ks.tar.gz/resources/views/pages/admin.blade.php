{{-- Painel ADM (Blade; assets em /admin/*.js|css) --}}
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Conecta King</title>
    <link rel="icon" type="image/png" href="https://i.ibb.co/60sW9k75/logo.png">
    <link rel="apple-touch-icon" href="https://i.ibb.co/60sW9k75/logo.png">
    @vite(['resources/css/fontawesome.css', 'resources/js/pages/admin.js'])
</head>
<body>
    <div class="admin-layout">
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="/dashboard" class="logo" title="Voltar ao painel">
                    <i class="fas fa-arrow-left"></i>
                    <span class="logo-text">Painel</span>
                </a>
                <span class="admin-top-badge"><i class="fas fa-shield-alt"></i> ADM</span>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-link active" data-target="overview-pane"><i class="fas fa-tachometer-alt"></i> <span>Visão Geral</span></a>
                <a href="#" class="nav-link" data-target="users-pane"><i class="fas fa-users"></i> <span>Gerenciar Usuários</span></a>
                <a href="#" class="nav-link" data-target="codes-pane"><i class="fas fa-key"></i> <span>Gerenciar Códigos</span></a>
                <a href="#" class="nav-link" data-target="branding-pane"><i class="fas fa-image"></i> <span>Logomarca padrão</span></a>
                <a href="#" class="nav-link" data-target="king-selection-pane"><i class="fas fa-crown" style="color: #f59e0b;"></i> <span>👑 King Selection</span></a>
                <a href="#" class="nav-link" data-target="r2-pane"><i class="fas fa-cloud"></i> <span>Armazenamento R2</span></a>
                <a href="/admin-devocionais-365" class="nav-link"><i class="fas fa-book-open"></i> <span>Bíblia &amp; Devocionais</span></a>
                <a href="/admin-devocionais-365#prosperidade" class="nav-link"><i class="fas fa-moon"></i> <span>Prosperidade antes de dormir</span></a>
            </nav>
            <div class="sidebar-footer">
            </div>
        </aside>

        <main class="main-content">
            <section id="overview-pane" class="content-pane active">
                <div class="overview-header-flex">
                    <h2>Visão Geral da Plataforma</h2>
                    <button id="refresh-data-btn" class="btn btn-secondary ck-btn-md">
                        <i class="fas fa-sync-alt"></i> Atualizar
                    </button>
                </div>
                <div class="ck-admin-2fa-card" id="admin-2fa-card">
                    <div class="ck-admin-2fa-card-text">
                        <div class="ck-admin-2fa-title-row">
                            <h3><i class="fas fa-shield-alt"></i> 2FA da Conta Admin</h3>
                            <span class="ck-admin-2fa-badge" id="admin-2fa-badge">…</span>
                        </div>
                        <p>Protege sua conta administrativa com autenticador. Desative temporariamente para manutenção e reative quando desejar — o autenticador continua o mesmo.</p>
                    </div>
                    <div class="ck-admin-2fa-card-actions">
                        <label class="ck-admin-2fa-switch" for="admin-2fa-toggle" title="Ativar ou desativar 2FA">
                            <input type="checkbox" id="admin-2fa-toggle" disabled>
                            <span class="ck-admin-2fa-slider"></span>
                        </label>
                        <span class="ck-admin-2fa-state" id="admin-2fa-state">…</span>
                    </div>
                </div>
                <!-- Métricas Principais -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <h4><i class="fas fa-users"></i> Total de Usuários</h4>
                        <p id="total-users">...</p>
                        <small class="stat-subtitle">Contas registradas</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-key"></i> Códigos Gerados</h4>
                        <p id="total-codes">...</p>
                        <small class="stat-subtitle">Total de códigos criados</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-check-circle"></i> Códigos Utilizados</h4>
                        <p id="claimed-codes">...</p>
                        <small class="stat-subtitle">Códigos já utilizados</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-eye"></i> Visualizações de Perfil</h4>
                        <p id="total-views">...</p>
                        <small class="stat-subtitle">Total de visualizações</small>
                    </div>
                     <div class="stat-card">
                        <h4><i class="fas fa-mouse-pointer"></i> Cliques nos Links</h4>
                        <p id="total-clicks">...</p>
                        <small class="stat-subtitle">Total de cliques</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-percentage"></i> Taxa de Conversão (CTR)</h4>
                        <p id="click-through-rate">...</p>
                        <small class="stat-subtitle">Cliques / Visualizações</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-chart-line"></i> Taxa de Uso de Códigos</h4>
                        <p id="code-usage-rate">...</p>
                        <small class="stat-subtitle">Utilizados / Gerados</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-chart-bar"></i> Média Visualizações/Usuário</h4>
                        <p id="avg-views-per-user">...</p>
                        <small class="stat-subtitle">Engajamento médio</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-bullseye"></i> Média Cliques/Usuário</h4>
                        <p id="avg-clicks-per-user">...</p>
                        <small class="stat-subtitle">Interação média</small>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-building"></i> Usuários Empresariais</h4>
                        <p id="total-enterprise-users">...</p>
                        <small class="stat-subtitle">Contas com modo empresarial</small>
                    </div>
                </div>

                <!-- Seção de Analytics Avançado -->
                <div class="ck-mt-40">
                    <h3 class="ck-mb-20-text">
                        <i class="fas fa-chart-area"></i> Analytics Avançado
                    </h3>
                    
                    <div class="advanced-stats-grid">
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-fire"></i> Usuários Ativos (últimos 7 dias)</h4>
                            <p id="active-users-7d">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-calendar-day"></i> Usuários Ativos (Hoje)</h4>
                            <p id="active-users-today">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-sign-in-alt"></i> Logins Hoje</h4>
                            <p id="logins-today">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-edit"></i> Usuários que Alteraram Algo Hoje</h4>
                            <p id="modified-today">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-user-check"></i> Usuários com Perfil Ativo</h4>
                            <p id="users-with-profile">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-link"></i> Total de Links Criados</h4>
                            <p id="total-links">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-exclamation-triangle"></i> Assinaturas Vencidas</h4>
                            <p id="expired-subscriptions">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-clock"></i> Assinaturas Vencendo em 7 dias</h4>
                            <p id="expiring-soon">Carregando...</p>
                        </div>
                        <div class="advanced-stat-card">
                            <h4><i class="fas fa-user-times"></i> Usuários Inativos Hoje</h4>
                            <p id="not-used-today">Carregando...</p>
                        </div>
                    </div>

                    <!-- Tabela de Usuários Ativos vs Vencidos -->
                    <div class="ck-ad-3c5a73" id="users-active-expired-table-container">
                        <!-- Conteúdo será inserido via JavaScript -->
                    </div>
                </div>

                <!-- Top Performers -->
                <div class="ck-mt-40">
                    <h3 class="ck-mb-20-text">
                        <i class="fas fa-trophy"></i> Top Performers
                    </h3>
                    <div class="top-performers-grid">
                        <div class="top-performers-card ck-ad-d5b433">
                            <h4><i class="fas fa-star"></i> Top 20 Perfis Mais Visualizados</h4>
                            <div id="top-viewed-profiles" class="top-list ck-ad-eb6e6d">
                                <p class="ck-ad-ea1137">Carregando...</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Lista Completa de Perfis -->
                <div class="ck-mt-40">
                    <h3 class="ck-mb-20-text">
                        <i class="fas fa-list"></i> Lista Completa de Perfis
                    </h3>
                    <div class="ck-ad-4a3180">
                        <input class="ck-ad-6f2c58" type="text" id="profile-search-input" placeholder="?? Pesquisar por nome ou email..." 
                              >
                    </div>
                    <div class="profiles-list-container">
                        <div id="all-profiles-list" class="profiles-list">
                            <p class="ck-ad-e4d4ad">Carregando perfis...</p>
                        </div>
                    </div>
                </div>
            </section>

            <section id="users-pane" class="content-pane">
                <h2>Gerenciar Usuários</h2>
                
                <!-- Cards de Estatísticas Rápidas -->
                <div class="stats-cards-grid ck-grid-stats">
                    <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-user-expiration-filter="all" role="button" tabindex="0" aria-label="Filtrar: todos os usuários">
                        <div class="ck-flex-between">
                            <span class="ck-label-dark">Total de Usuários</span>
                            <i class="fas fa-users ck-ad-20952f"></i>
                        </div>
                        <div class="ck-ad-f02af0" id="stat-total-users">0</div>
                    </div>
                    <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-user-expiration-filter="active" role="button" tabindex="0" aria-label="Filtrar: usuários ativos">
                        <div class="ck-flex-between">
                            <span class="ck-label-dark">Usuários Ativos</span>
                            <i class="fas fa-check-circle ck-ad-fb6a54"></i>
                        </div>
                        <div class="ck-ad-b9f919" id="stat-active-users">0</div>
                    </div>
                    <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-user-expiration-filter="expired" role="button" tabindex="0" aria-label="Filtrar: usuários vencidos">
                        <div class="ck-flex-between">
                            <span class="ck-label-dark">Usuários Vencidos</span>
                            <i class="fas fa-exclamation-triangle ck-ad-ba70cf"></i>
                        </div>
                        <div class="ck-ad-c9121a" id="stat-expired-users">0</div>
                    </div>
                    <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-user-expiration-filter="expiring_soon" role="button" tabindex="0" aria-label="Filtrar: expirando em 7 dias">
                        <div class="ck-flex-between">
                            <span class="ck-label-dark">Expirando em 7 dias</span>
                            <i class="fas fa-clock ck-ad-f46854"></i>
                        </div>
                        <div class="ck-ad-ea9aa7" id="stat-expiring-soon-users">0</div>
                    </div>
                </div>
                
                <!-- Filtros Avançados -->
                <div class="advanced-filters ck-card-pad-mb">
                    <div class="ck-flex-between-15">
                        <h3 class="ck-card-title">
                            <i class="fas fa-filter"></i> Filtros Avançados
                        </h3>
                        <button id="toggle-advanced-filters" class="btn btn-secondary ck-btn-sm">
                            <i class="fas fa-chevron-down"></i> Mostrar
                        </button>
                    </div>
                    <div id="advanced-filters-content">
                        <div>
                            <label class="ck-label-block">Tipo de Conta</label>
                            <select class="ck-input-admin" id="filter-account-type">
                                <option value="">Todos os tipos</option>
                                <option value="free">Free</option>
                                <option value="adm_principal">ADM Principal</option>
                                <option value="basic">King Start</option>
                                <option value="premium">King Prime</option>
                                <option value="king_base">King Essential</option>
                                <option value="king_finance">King Finance</option>
                                <option value="king_finance_plus">King Finance Plus</option>
                                <option value="king_premium_plus">King Premium Plus</option>
                                <option value="king_corporate">King Corporate</option>
                                <option value="team_member">Membro</option>
                            </select>
                        </div>
                        <div>
                            <label class="ck-label-block">Status Assinatura</label>
                            <select class="ck-input-admin" id="filter-subscription-status">
                                <option value="">Todos os status</option>
                                <option value="active">Ativo</option>
                                <option value="expired">Expirado</option>
                                <option value="free">Free</option>
                            </select>
                        </div>
                        <div>
                            <label class="ck-label-block">Status Admin</label>
                            <select class="ck-input-admin" id="filter-is-admin">
                                <option value="">Todos</option>
                                <option value="true">Sim</option>
                                <option value="false">Não</option>
                            </select>
                        </div>
                        <div>
                            <label class="ck-label-block">Data de Criação (De)</label>
                            <input class="ck-input-admin" type="date" id="filter-created-from">
                        </div>
                        <div>
                            <label class="ck-label-block">Data de Criação (Até)</label>
                            <input class="ck-input-admin" type="date" id="filter-created-to">
                        </div>
                        <div class="ck-flex-end-gap">
                            <button id="apply-advanced-filters" class="btn btn-primary ck-flex-1">
                                <i class="fas fa-check"></i> Aplicar Filtros
                            </button>
                            <button id="clear-advanced-filters" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Limpar
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Indicador de filtros ativos + Limpar tudo -->
                <div id="users-filters-active-bar" class="filters-active-bar ck-ad-46cc56">
                    <span class="ck-text-light-09" id="users-filters-active-text"></span>
                    <button type="button" id="users-clear-all-filters-btn" class="btn btn-secondary ck-btn-sm">
                        <i class="fas fa-times-circle"></i> Limpar todos os filtros
                    </button>
                </div>
                
                <div class="filter-actions ck-ad-eae8e0">
                    <div class="ck-ad-4990df">
                        <label for="user-search-input" class="sr-only">Pesquisar por nome ou e-mail</label>
                        <i class="fas fa-search ck-ad-6ae11d" aria-hidden="true"></i>
                        <input class="ck-ad-590349" type="text" id="user-search-input" placeholder="Pesquisar por nome ou e-mail (Enter para buscar)" 
                               aria-label="Pesquisar usuários por nome ou e-mail" autocomplete="off"
                              >
                    </div>
                    
                    <!-- Filtros de Vencimento para Usuários -->
                    <div class="expiration-filters" role="group" aria-label="Filtro por vencimento">
                        <button id="user-filter-all-btn" class="btn btn-secondary filter-btn active" data-filter="all" type="button" aria-pressed="true">Todos</button>
                        <button id="user-filter-expired-btn" class="btn btn-secondary filter-btn" data-filter="expired" type="button" aria-pressed="false"><i class="fas fa-exclamation-triangle" aria-hidden="true"></i> Vencidos</button>
                        <button id="user-filter-active-btn" class="btn btn-secondary filter-btn" data-filter="active" type="button" aria-pressed="false"><i class="fas fa-check-circle" aria-hidden="true"></i> Em Dias</button>
                        <button id="user-filter-expiring-soon-btn" class="btn btn-secondary filter-btn" data-filter="expiring_soon" type="button" aria-pressed="false"><i class="fas fa-clock" aria-hidden="true"></i> Expirando em 7 dias</button>
                    </div>
                    <!-- Filtro por inatividade (dias sem uso) -->
                    <div class="inactivity-filters" role="group" aria-label="Filtro por inatividade">
                        <span class="ck-ad-4c0525">Inativos:</span>
                        <button type="button" id="user-filter-inactive-30" class="btn btn-secondary filter-btn btn-sm" data-inactive-days="30">30 dias</button>
                        <button type="button" id="user-filter-inactive-60" class="btn btn-secondary filter-btn btn-sm" data-inactive-days="60">60 dias</button>
                        <button type="button" id="user-filter-inactive-90" class="btn btn-secondary filter-btn btn-sm" data-inactive-days="90">90 dias</button>
                        <button type="button" id="user-filter-inactive-180" class="btn btn-secondary filter-btn btn-sm" data-inactive-days="180">180 dias</button>
                    </div>
                </div>
                
                <!-- Seção de Exclusão Automática para Usuários -->
                <div class="auto-delete-section">
                    <button id="open-user-auto-delete-modal-btn" class="btn btn-secondary">
                        <i class="fas fa-cog"></i> Configurar Exclusão Automática
                    </button>
                    <button id="execute-user-auto-delete-btn" class="btn btn-warning">
                        <i class="fas fa-broom"></i> Executar Exclusão Agora
                    </button>
                </div>
                
                <div class="ck-ad-d61bb9">
                    <div class="ck-flex-wrap-12">
                        <div id="user-count" class="selected-count ck-m-0" aria-live="polite">0 usuário(s)</div>
                        <span class="ck-text-dark-09" id="users-page-range"></span>
                    </div>
                    
                    <!-- Colunas visíveis + Paginação + Exportar -->
                    <div class="ck-ad-dc40cc">
                        <div class="dropdown-columns-wrap">
                            <button type="button" id="users-columns-toggle" class="btn btn-secondary ck-btn-sm" aria-haspopup="true" aria-expanded="false" aria-label="Mostrar ou ocultar colunas">
                                <i class="fas fa-columns"></i> Colunas
                            </button>
                            <div id="users-columns-dropdown" class="dropdown-columns ck-hidden" role="menu" aria-label="Colunas visíveis"></div>
                        </div>
                        <label class="ck-ad-98b4d6">
                            <span>Itens por página:</span>
                            <select class="ck-input-sm" id="users-per-page" aria-label="Itens por página">
                                <option value="25">25</option>
                                <option value="50" selected>50</option>
                                <option value="100">100</option>
                                <option value="200">200</option>
                                <option value="all">Todos</option>
                            </select>
                        </label>
                        <button id="export-all-users-btn" class="btn btn-secondary ck-btn-md" aria-label="Exportar todos os usuários">
                            <i class="fas fa-file-export"></i> Exportar Todos
                        </button>
                    </div>
                </div>
                
                <!-- Ações em Massa para Usuários Selecionados -->
                <div id="user-bulk-actions" class="bulk-actions ck-ad-98eb5a" role="region" aria-label="Ações em massa">
                    <div class="ck-ad-c593ec">
                        <span class="ck-text-light-bold" id="user-selected-count">0 usuários selecionados</span>
                        <button id="delete-selected-users-btn" class="btn btn-danger" aria-label="Deletar usuários selecionados">
                            <i class="fas fa-trash"></i> Deletar Selecionados
                        </button>
                        <button id="export-selected-users-btn" class="btn btn-secondary" aria-label="Exportar selecionados em CSV">
                            <i class="fas fa-download"></i> Exportar (CSV)
                        </button>
                        <button id="export-selected-users-excel-btn" class="btn btn-secondary" aria-label="Exportar selecionados em Excel">
                            <i class="fas fa-file-excel"></i> Exportar (Excel)
                        </button>
                        <button id="copy-selected-users-btn" class="btn btn-secondary" aria-label="Copiar nome e e-mail dos selecionados">
                            <i class="fas fa-copy"></i> Copiar (nome + e-mail)
                        </button>
                        <button id="change-account-type-bulk-btn" class="btn btn-secondary" aria-label="Alterar tipo de conta em massa">
                            <i class="fas fa-edit"></i> Alterar Tipo em Massa
                        </button>
                        <button id="clear-selection-btn" class="btn btn-secondary" aria-label="Limpar seleção">
                            <i class="fas fa-times"></i> Limpar Seleção
                        </button>
                    </div>
                </div>
                
                <div id="users-table-loading" class="table-loading-overlay ck-hidden" aria-hidden="true">
                    <i class="fas fa-spinner fa-spin ck-ad-cac731"></i>
                    <span>Carregando...</span>
                </div>
                <div class="table-container" id="users-table-container">
                    <table id="users-table" role="grid" aria-label="Lista de usuários">
                        <thead>
                            <tr>
                                <th class="th-checkbox"><input type="checkbox" id="select-all-users" title="Selecionar todos desta página" aria-label="Selecionar todos os usuários desta página"></th>
                                <th class="th-num" data-col="num">#</th>
                                <th class="sortable th-name" data-key="name" data-col="name" title="Clique para ordenar por nome">Nome <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-email" data-key="email" data-col="email" title="Clique para ordenar por e-mail">Email <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-account-type" data-key="account_type" data-col="account_type" title="Clique para ordenar por tipo de conta">Tipo de Conta <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-subscription" data-key="subscription_status" data-col="subscription_status" title="Clique para ordenar por status">Status Assinatura <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-expires" data-key="expires_at" data-col="expires_at" title="Clique para ordenar por data de expiração">Expira em <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-days" data-key="days_left" data-col="days_left" title="Clique para ordenar por status de vencimento">Status Vencimento <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-parent" data-key="parent_email" data-col="parent_email" title="Clique para ordenar por conta principal">Conta Principal <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-admin" data-key="is_admin" data-col="is_admin" title="Clique para ordenar por status admin">Status Admin <span class="sort-indicator" aria-hidden="true"></span></th>
                                <th class="sortable th-created" data-key="created_at" data-col="created_at" title="Clique para ordenar por data de criação">Data de Criação <span class="sort-indicator" aria-hidden="true"></span></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div id="users-empty-state" class="table-empty-state ck-hidden">
                    <i class="fas fa-search" aria-hidden="true"></i>
                    <h4>Nenhum usuário encontrado</h4>
                    <p>Não há resultados para os filtros ou busca atuais. Tente outros termos ou limpe os filtros.</p>
                    <button type="button" id="users-empty-state-clear-btn" class="btn btn-primary"><i class="fas fa-times-circle"></i> Limpar filtros</button>
                </div>
                
                <!-- Paginação -->
                <nav id="users-pagination" class="pagination ck-flex-center-pad" aria-label="Paginação da lista de usuários">
                    <button id="users-prev-page" class="btn btn-secondary" disabled aria-label="Página anterior">
                        <i class="fas fa-chevron-left" aria-hidden="true"></i> Anterior
                    </button>
                    <span class="ck-text-light-bold" id="users-page-info" aria-live="polite">Página 1 de 1</span>
                    <button id="users-next-page" class="btn btn-secondary" disabled aria-label="Próxima página">
                        Próxima <i class="fas fa-chevron-right" aria-hidden="true"></i>
                    </button>
                </nav>
            </section>

        <section id="branding-pane" class="content-pane">
            <h2>Logomarca padrão</h2>
            <p class="branding-description ck-ad-4de9c2">
                Esta logo será exibida no rodapé do cartão de <strong>todas as contas que ainda não definiram a própria</strong>. 
                Contas em modo empresa que já alteraram a logo no painel delas não são afetadas - a alteração daqui não substitui a logo delas.
            </p>
            <div class="branding-form-card ck-ad-b4ae68">
                <input type="hidden" id="default-logo-url" value="">
                <div class="input-group ck-mb-16">
                    <label>Logo do rodapé</label>
                    <div id="default-logo-upload-area" class="image-upload-area ck-ad-a43cab">
                        <div id="default-logo-upload-placeholder">
                            <i class="fas fa-cloud-upload-alt ck-ad-04d2f2"></i>
                            <p class="ck-ad-5a376f">Clique para fazer upload da logo</p>
                            <p class="ck-ad-df15ca">PNG ou JPG, até 5MB. Deixe vazio para usar o logo Conecta King.</p>
                        </div>
                        <div class="ck-ad-64fcb8" id="default-logo-upload-preview">
                            <img class="ck-ad-b52b58" id="default-logo-preview-img" src="" alt="Preview da logo">
                            <button type="button" id="default-logo-remove-btn" class="btn btn-secondary ck-ad-f1fc6d">
                                <i class="fas fa-times"></i> Remover logo
                            </button>
                        </div>
                    </div>
                    <input class="ck-ad-7f910f" type="file" id="default-logo-file-input" accept="image/png,image/jpeg,image/jpg">
                </div>
                <div class="input-group ck-mb-16">
                    <label for="default-logo-size">Tamanho (px) - entre 20 e 420</label>
                    <input type="number" id="default-logo-size" min="20" max="420" value="60" class="modal-input-text ck-ad-b828cb">
                </div>
                <div class="input-group ck-mb-20">
                    <label for="default-logo-link">Link ao clicar na logo (opcional)</label>
                    <input type="url" id="default-logo-link" class="modal-input-text ck-ad-bd6aa3" placeholder="https://...">
                </div>
                <div class="ck-mb-20" id="default-logo-size-preview">
                    <span class="ck-text-dark-09">Como aparece no rodapé:</span>
                    <div class="ck-ad-4ed27f" id="default-logo-size-preview-img"></div>
                </div>
                <button type="button" id="save-default-branding-btn" class="btn btn-primary">
                    <i class="fas fa-save"></i> Salvar logomarca padrão
                </button>
                <span class="ck-ad-347424" id="default-branding-message"></span>
            </div>
        </section>

        <section id="r2-pane" class="content-pane">
            <div class="overview-header-flex">
                <div>
                    <h2><i class="fas fa-cloud"></i> Armazenamento Cloudflare R2</h2>
                    <p class="ck-text-dark-09" style="margin-top:6px;max-width:720px">
                        Painel exclusivo de administração. Compare todos os projetos do King Selection com os arquivos no bucket do Cloudflare R2, identifique projetos excluídos e remova fotos órfãs para liberar espaço.
                    </p>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <button type="button" class="btn btn-secondary ck-btn-md" id="ks-r2-refresh">
                        <i class="fas fa-sync-alt"></i> Atualizar inventário
                    </button>
                    <button type="button" class="btn btn-secondary ck-btn-md" id="btn-cleanup-r2-dry">
                        <i class="fas fa-search"></i> Verificar órfãos
                    </button>
                    <button type="button" class="btn btn-danger ck-btn-md" id="btn-cleanup-r2">
                        <i class="fas fa-broom"></i> Limpar R2 (só órfãos)
                    </button>
                </div>
            </div>

            <div class="stats-grid" style="margin-top:18px" id="ks-r2-summary">
                <div class="stat-card">
                    <span class="stat-label">Arquivos no R2</span>
                    <span class="stat-value" id="ks-r2-stat-total">—</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">Tamanho total</span>
                    <span class="stat-value" id="ks-r2-stat-size">—</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">Referenciados no BD</span>
                    <span class="stat-value" id="ks-r2-stat-ref">—</span>
                </div>
                <div class="stat-card" style="border-left:4px solid #f59e0b">
                    <span class="stat-label">Órfãos no R2</span>
                    <span class="stat-value" id="ks-r2-stat-orphans" style="color:#f59e0b">—</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">Projetos com fotos</span>
                    <span class="stat-value" id="ks-r2-stat-projects">—</span>
                </div>
                <div class="stat-card" style="border-left:4px solid #ef4444">
                    <span class="stat-label">Pastas de excluídos</span>
                    <span class="stat-value" id="ks-r2-stat-deleted" style="color:#ef4444">—</span>
                </div>
            </div>

            <p class="ck-hint" id="ks-r2-generated" style="margin-top:12px">
                Clique em «Atualizar inventário» para carregar pastas, datas e comparação com o banco de dados.
            </p>
            <div class="ck-hidden" id="ks-r2-loading" style="margin-top:10px;color:#f59e0b;font-weight:600">
                <i class="fas fa-spinner fa-spin"></i> Lendo arquivos no Cloudflare R2… pode levar alguns instantes.
            </div>

            <div style="margin-top:28px">
                <h3 style="font-weight:800;margin-bottom:6px">Projetos Ativos (King Selection × R2)</h3>
                <div class="table-container">
                    <table class="table" style="width:100%">
                        <thead>
                            <tr>
                                <th>Projeto</th>
                                <th>ID</th>
                                <th>Fotos no BD</th>
                                <th>Arquivos R2</th>
                                <th>Órfãos</th>
                                <th>Tamanho R2</th>
                                <th>Último upload</th>
                                <th>Pastas</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="ks-r2-projects-tbody">
                            <tr><td colspan="9" class="table-empty-state" style="padding:24px;text-align:center">Nenhum dado carregado. Clique em «Atualizar inventário».</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div style="margin-top:32px">
                <h3 style="font-weight:800;margin-bottom:6px;color:#ef4444">Pastas órfãs (Projetos já excluídos no King Selection)</h3>
                <p class="ck-hint" style="margin-bottom:8px">Pastas que ainda ocupam espaço no R2 mas cujo projeto já foi apagado do banco.</p>
                <div class="table-container">
                    <table class="table" style="width:100%">
                        <thead>
                            <tr>
                                <th>Pasta R2</th>
                                <th>Arquivos</th>
                                <th>Tamanho</th>
                                <th>Último upload</th>
                                <th>Subpastas</th>
                            </tr>
                        </thead>
                        <tbody id="ks-r2-orphan-folders-tbody">
                            <tr><td colspan="5" class="table-empty-state" style="padding:20px;text-align:center">—</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div style="margin-top:32px">
                <h3 style="font-weight:800;margin-bottom:6px">Amostra de Arquivos Órfãos</h3>
                <p class="ck-hint" style="margin-bottom:8px">Use «Limpar R2» para apagar todos os arquivos órfãos com segurança.</p>
                <div class="table-container" style="max-height:360px;overflow-y:auto">
                    <table class="table" style="width:100%">
                        <thead>
                            <tr>
                                <th>Arquivo</th>
                                <th>Pasta / projeto</th>
                                <th>Subpasta</th>
                                <th>Tamanho</th>
                                <th>Data no R2</th>
                            </tr>
                        </thead>
                        <tbody id="ks-r2-orphan-files-tbody">
                            <tr><td colspan="5" class="table-empty-state" style="padding:20px;text-align:center">—</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- King Selection Master Admin Pane -->
        <section id="king-selection-pane" class="content-pane">
            <div class="overview-header-flex">
                <div>
                    <h2><i class="fas fa-crown" style="color:#f59e0b"></i> King Selection — Gestão Master &amp; Faturamento R2</h2>
                    <p class="ck-text-dark-09" style="margin-top:6px;max-width:760px">
                        Acompanhe o consumo total em GB no Cloudflare R2, audite a fatura mensal em Dólar e Real (considerando os 10 GB grátis da Cloudflare), configure os planos dos fotógrafos (20 GB, 30 GB, 70 GB) e libere ou bloqueie acessos ao módulo.
                    </p>
                </div>
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
                    <div style="display:flex;align-items:center;gap:6px;background:rgba(0,0,0,0.04);padding:4px 10px;border-radius:8px;border:1px solid rgba(0,0,0,0.08);font-size:12px;">
                        <span>Dólar (USD): R$</span>
                        <input type="number" id="ks-master-usd-rate" value="5.70" step="0.05" style="width:65px;padding:3px 6px;border:1px solid #cbd5e1;border-radius:4px;font-weight:700;font-size:12px;">
                    </div>
                    <button type="button" class="btn btn-secondary ck-btn-md" id="ks-master-refresh-btn">
                        <i class="fas fa-sync-alt"></i> Atualizar Dados
                    </button>
                </div>
            </div>

            <!-- Cards de Métricas Econômicas & Fatura Cloudflare R2 -->
            <div class="stats-grid" style="margin-top:20px" id="ks-master-summary-grid">
                <div class="stat-card">
                    <span class="stat-label"><i class="fas fa-database text-amber-500"></i> Armazenamento R2 Utilizado</span>
                    <span class="stat-value" id="ks-master-stat-storage" style="font-size:22px">—</span>
                    <small class="ck-hint" id="ks-master-stat-substorage" style="margin-top:4px;display:block">0 fotos em 0 projetos</small>
                </div>
                <div class="stat-card" style="border-left:4px solid #f59e0b">
                    <span class="stat-label"><i class="fas fa-receipt" style="color:#f59e0b"></i> Fatura Cloudflare R2 (Mês)</span>
                    <span class="stat-value" id="ks-master-stat-bill" style="font-size:22px;color:#d97706">$0.00 / R$ 0,00</span>
                    <small class="ck-hint" id="ks-master-stat-subbill" style="margin-top:4px;display:block">10 GB grátis/mês inclusos</small>
                </div>
                <div class="stat-card" style="border-left:4px solid #3b82f6">
                    <span class="stat-label"><i class="fas fa-money-bill-wave" style="color:#3b82f6"></i> Faturamento Fotógrafos</span>
                    <span class="stat-value" id="ks-master-stat-revenue" style="font-size:22px;color:#2563eb">R$ 0,00</span>
                    <small class="ck-hint" id="ks-master-stat-subrevenue" style="margin-top:4px;display:block">0 fotógrafos contratantes</small>
                </div>
                <div class="stat-card" style="border-left:4px solid #10b981">
                    <span class="stat-label"><i class="fas fa-chart-line" style="color:#10b981"></i> Lucro Líquido Real</span>
                    <span class="stat-value" id="ks-master-stat-profit" style="font-size:22px;color:#059669">R$ 0,00</span>
                    <small class="ck-hint" id="ks-master-stat-subprofit" style="margin-top:4px;display:block">Margem após pagar o R2: ~98%</small>
                </div>
            </div>

            <!-- Tabela de Gestão de Fotógrafos -->
            <div style="margin-top:32px">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:14px">
                    <h3 style="margin:0;font-size:17px;font-weight:800;color:#0f172a">
                        <i class="fas fa-camera text-amber-500 mr-1.5"></i> Fotógrafos do King Selection
                    </h3>
                    <div style="display:flex;gap:10px;align-items:center">
                        <input type="text" id="ks-master-search-input" placeholder="Buscar por nome, email ou telefone..." style="padding:7px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;width:280px;">
                    </div>
                </div>

                <div class="table-responsive" style="border-radius:12px;border:1px solid #e2e8f0;background:#ffffff;box-shadow:0 1px 3px rgba(0,0,0,0.05)">
                    <table class="data-table" style="width:100%;margin:0;font-size:13px;">
                        <thead>
                            <tr style="background:#f8fafc;border-bottom:2px solid #e2e8f0;text-align:left">
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Fotógrafo / Contato</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Acesso KS</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Plano Ativo</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Armazenamento Usado</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Custo R2</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569">Lucro Gerado</th>
                                <th style="padding:12px 14px;font-weight:700;color:#475569;text-align:right">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="ks-master-photographers-tbody">
                            <tr>
                                <td colspan="7" style="padding:28px;text-align:center;color:#64748b">
                                    <i class="fas fa-spinner fa-spin mr-2"></i> Carregando fotógrafos do King Selection...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
            <h2>Gerenciar Códigos de Registro</h2>
            
            <!-- Cards de Estatísticas para Códigos -->
            <div class="stats-cards-grid ck-grid-stats">
                <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-code-quick-filter="all" role="button" tabindex="0" aria-label="Filtrar: todos os códigos">
                    <div class="ck-flex-between">
                        <span class="ck-label-dark">Total de Códigos</span>
                        <i class="fas fa-key ck-ad-20952f"></i>
                    </div>
                    <div class="ck-ad-f02af0" id="stat-total-codes">0</div>
                </div>
                <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-code-quick-filter="available" role="button" tabindex="0" aria-label="Filtrar: códigos disponíveis">
                    <div class="ck-flex-between">
                        <span class="ck-label-dark">Códigos Disponíveis</span>
                        <i class="fas fa-check-circle ck-ad-fb6a54"></i>
                    </div>
                    <div class="ck-ad-b9f919" id="stat-available-codes">0</div>
                </div>
                <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-code-quick-filter="claimed" role="button" tabindex="0" aria-label="Filtrar: códigos utilizados">
                    <div class="ck-flex-between">
                        <span class="ck-label-dark">Códigos Utilizados</span>
                        <i class="fas fa-check ck-ad-144315"></i>
                    </div>
                    <div class="ck-ad-3e388c" id="stat-used-codes">0</div>
                </div>
                <div class="stat-card-mini stat-card-clickable ck-card-pad-click" data-code-quick-filter="all" role="button" tabindex="0" aria-label="Filtrar: todos os códigos">
                    <div class="ck-flex-between">
                        <span class="ck-label-dark">Taxa de Uso</span>
                        <i class="fas fa-percentage ck-ad-f46854"></i>
                    </div>
                    <div class="ck-ad-ea9aa7" id="stat-usage-rate">0%</div>
                </div>
            </div>
            
            <!-- Seção de Geração de Códigos -->
            <div class="codes-actions">
                <div class="code-generation-section">
                    <button id="generate-code-btn" class="btn btn-secondary">
                        <i class="fas fa-cogs"></i> Gerar Código Automático
                    </button>
                    
                    <div class="batch-generation">
                        <span>Digite o prefixo (</span>
                        <input type="text" id="prefix-input" placeholder="KING-" maxlength="8">
                        <span>)</span>
                        <input type="number" id="batch-count" placeholder="10" min="1" max="100" value="10">
                        <button id="generate-batch-btn" class="btn btn-primary">
                            <i class="fas fa-layer-group"></i> Gerar em Lote
                        </button>
                    </div>
                    
                    <div class="manual-generation">
                        <input type="text" id="custom-code-input" placeholder="Digite o código personalizado" maxlength="12" required>
                        <button id="create-manual-code-btn" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Criar Código Manual
                        </button>
                    </div>
                </div>
                
                <!-- Filtros Avançados para Códigos -->
                <div class="advanced-filters ck-card-pad-mb">
                    <div class="ck-flex-between-15">
                        <h3 class="ck-card-title">
                            <i class="fas fa-filter"></i> Filtros Avançados
                        </h3>
                        <button id="toggle-advanced-filters-codes" class="btn btn-secondary ck-btn-sm">
                            <i class="fas fa-chevron-down"></i> Mostrar
                        </button>
                    </div>
                    <div id="advanced-filters-content-codes">
                        <div>
                            <label class="ck-label-block">Status</label>
                            <select class="ck-input-admin" id="filter-code-status">
                                <option value="">Todos</option>
                                <option value="available">Disponível</option>
                                <option value="used">Utilizado</option>
                            </select>
                        </div>
                        <div>
                            <label class="ck-label-block">Gerado por</label>
                            <input class="ck-input-admin" type="text" id="filter-code-generator" placeholder="Email do gerador">
                        </div>
                        <div>
                            <label class="ck-label-block">Data de Criação (De)</label>
                            <input class="ck-input-admin" type="date" id="filter-code-created-from">
                        </div>
                        <div>
                            <label class="ck-label-block">Data de Criação (Até)</label>
                            <input class="ck-input-admin" type="date" id="filter-code-created-to">
                        </div>
                        <div class="ck-flex-end-gap">
                            <button id="apply-advanced-filters-codes" class="btn btn-primary ck-flex-1">
                                <i class="fas fa-check"></i> Aplicar Filtros
                            </button>
                            <button id="clear-advanced-filters-codes" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Limpar
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Filtros rápidos: Cadastrados / Não cadastrados -->
                <div class="expiration-filters codes-quick-filters ck-mb-12" role="group" aria-label="Filtro por uso do código">
                    <span class="ck-label-dark">Exibir:</span>
                    <button type="button" id="code-filter-all-btn" class="btn btn-secondary filter-btn active" data-code-filter="all">
                        <i class="fas fa-list"></i> Todos
                    </button>
                    <button type="button" id="code-filter-claimed-btn" class="btn btn-secondary filter-btn" data-code-filter="claimed" title="Códigos já utilizados (cadastro com e-mail)">
                        <i class="fas fa-user-check"></i> Cadastrados (com e-mail)
                    </button>
                    <button type="button" id="code-filter-available-btn" class="btn btn-secondary filter-btn" data-code-filter="available" title="Códigos criados mas ainda não utilizados">
                        <i class="fas fa-key"></i> Não cadastrados (disponíveis)
                    </button>
                </div>
                
                <!-- Indicador de filtros ativos (códigos) -->
                <div id="codes-filters-active-bar" class="filters-active-bar ck-ad-46cc56">
                    <span class="ck-text-light-09" id="codes-filters-active-text"></span>
                    <button type="button" id="codes-clear-all-filters-btn" class="btn btn-secondary ck-btn-sm">
                        <i class="fas fa-times-circle"></i> Limpar todos os filtros
                    </button>
                </div>
                
                <!-- Seção de Filtros e Ações -->
                <div class="filter-actions ck-ad-aa2bc5">
                    <label for="filter-input" class="sr-only">Filtrar códigos por código, link ou e-mail</label>
                    <input type="text" id="filter-input" placeholder="Filtrar por código, link ou e-mail (Enter para buscar)" aria-label="Filtrar códigos" autocomplete="off">
                    
                    <button id="copy-filtered-links-btn" class="btn btn-secondary" aria-label="Copiar links dos códigos filtrados">
                        <i class="fas fa-copy"></i> Copiar links filtrados
                    </button>
                    <button id="export-all-codes-btn" class="btn btn-secondary" aria-label="Exportar todos os códigos">
                        <i class="fas fa-file-export"></i> Exportar Todos
                    </button>
                    <div class="ck-flex-wrap-12">
                        <div id="codes-count" class="selected-count ck-m-0" aria-live="polite">0 códigos</div>
                        <span class="ck-text-dark-09" id="codes-page-range"></span>
                    </div>
                    <div class="dropdown-columns-wrap">
                        <button type="button" id="codes-columns-toggle" class="btn btn-secondary ck-btn-sm" aria-haspopup="true" aria-expanded="false" aria-label="Mostrar ou ocultar colunas">
                            <i class="fas fa-columns"></i> Colunas
                        </button>
                        <div id="codes-columns-dropdown" class="dropdown-columns ck-hidden" role="menu" aria-label="Colunas visíveis"></div>
                    </div>
                    <label class="ck-ad-98b4d6">
                        <span>Itens por página:</span>
                        <select class="ck-input-sm" id="codes-per-page" aria-label="Itens por página">
                            <option value="25">25</option>
                            <option value="50" selected>50</option>
                            <option value="100">100</option>
                            <option value="200">200</option>
                            <option value="all">Todos</option>
                        </select>
                    </label>
                    <button id="copy-selected-btn" class="btn btn-secondary" aria-label="Copiar códigos selecionados">
                        <i class="fas fa-check"></i> Copiar códigos selecionados
                    </button>
                    <button id="delete-selected-btn" class="btn btn-danger" aria-label="Deletar códigos selecionados">
                        <i class="fas fa-trash"></i> Deletar selecionados
                    </button>
                    <button type="button" onclick="selectNext10()" class="btn btn-secondary" aria-label="Selecionar mais 10">
                        <i class="fas fa-plus"></i> Selecionar +10
                    </button>
                    <div id="selected-count" class="selected-count" aria-live="polite">0 selecionados</div>
                </div>
            </div>
            
            <!-- Legenda de cores (vencimento) -->
            <div class="codes-legend ck-ad-96d6b6">
                <span><span class="legend-dot ck-ad-8c165e"></span> Em dia / Sem expiração</span>
                <span><span class="legend-dot ck-ad-ca3e48"></span> Vence em até 30 dias</span>
                <span><span class="legend-dot ck-ad-50a69f"></span> Vencido</span>
            </div>
            
            <!-- Loading e Tabela de Códigos -->
            <div id="codes-table-loading" class="table-loading-overlay ck-hidden" aria-hidden="true">
                <i class="fas fa-spinner fa-spin ck-ad-cac731"></i>
                <span>Carregando...</span>
            </div>
            <div class="table-container" id="codes-table-container">
                <table id="codes-table" role="grid" aria-label="Lista de códigos de registro">
                    <thead>
                        <tr>
                            <th class="th-checkbox"><input type="checkbox" id="select-all-codes" title="Selecionar todos desta página" aria-label="Selecionar todos os códigos desta página"></th>
                            <th data-col="num">#</th>
                            <th data-col="code">Código</th>
                            <th data-col="link">Link</th>
                            <th data-col="status">Status</th>
                            <th data-col="expiration_status">Status Vencimento</th>
                            <th data-col="expires_at">Expira em</th>
                            <th data-col="claimed_by">Utilizado por</th>
                            <th data-col="claimed_at">Data de Utilização</th>
                            <th data-col="generated_by">Gerado por</th>
                            <th data-col="created_at">Data de Criação</th>
                            <th data-col="time_since">Tempo desde Criação</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div id="codes-empty-state" class="table-empty-state ck-hidden">
                <i class="fas fa-search" aria-hidden="true"></i>
                <h4>Nenhum código encontrado</h4>
                <p>Não há resultados para os filtros ou busca atuais. Tente outros termos ou limpe os filtros.</p>
                <button type="button" id="codes-empty-state-clear-btn" class="btn btn-primary"><i class="fas fa-times-circle"></i> Limpar filtros</button>
            </div>
            
            <!-- Paginação para Códigos -->
            <nav id="codes-pagination" class="pagination ck-flex-center-pad" aria-label="Paginação da lista de códigos">
                <button id="codes-prev-page" class="btn btn-secondary" disabled aria-label="Página anterior">
                    <i class="fas fa-chevron-left" aria-hidden="true"></i> Anterior
                </button>
                <span class="ck-text-light-bold" id="codes-page-info" aria-live="polite">Página 1 de 1</span>
                <button id="codes-next-page" class="btn btn-secondary" disabled aria-label="Próxima página">
                    Próxima <i class="fas fa-chevron-right" aria-hidden="true"></i>
                </button>
            </nav>
        </section>
        </main>
    </div>
    <!-- Modal de Detalhes de Analytics do Perfil -->
    <div id="profile-analytics-modal" class="modal-overlay">
        <div class="modal-content ck-ad-f4096e">
            <div class="modal-header ck-ad-c7d95c">
                <h4 id="profile-analytics-title">Detalhes de Analytics</h4>
                <div class="ck-ad-410624">
                    <select class="ck-ad-fb33f9" id="analytics-period-selector">
                        <option value="7">últimos 7 dias</option>
                        <option value="30" selected>últimos 30 dias</option>
                        <option value="90">últimos 90 dias</option>
                        <option value="365">último ano</option>
                    </select>
                    <button id="close-profile-analytics-btn" class="close-btn">&times;</button>
                </div>
            </div>
            <div class="modal-body">
                <div id="profile-analytics-content">
                    <p class="ck-text-dark-center">Carregando detalhes...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Dashboard do Usuário (Admin - visão completa por cliente) -->
    <div id="admin-user-dashboard-modal" class="modal-overlay">
        <div class="modal-content ck-ad-fedcc7">
            <div class="modal-header ck-ad-64c3f7">
                <h4 id="admin-user-dashboard-title">Dashboard do usuário</h4>
                <button id="close-admin-user-dashboard-btn" class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
                <div id="admin-user-dashboard-content">
                    <p class="ck-text-dark-center">Carregando...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Configuração de Exclusão Automática -->
    <div id="auto-delete-modal" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header">
                <h4>Configurar Exclusão Automática de Usuários</h4>
                <button id="close-auto-delete-modal-btn" class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
                <p class="ck-ad-3a88d7">
                    Configure a exclusão automática de usuários vencidos. Os usuários serão excluídos após X dias da data de expiração da assinatura.
                </p>
                <div id="auto-delete-configs-list"></div>
                <div class="input-group ck-ad-5fa693">
                    <label for="new-auto-delete-days">Dias após expiração para excluir:</label>
                    <input type="number" id="new-auto-delete-days" min="1" placeholder="60" class="modal-input-text">
                </div>
                <div class="input-group">
                    <label>
                        <input type="checkbox" id="new-auto-delete-active"> Ativar exclusão automática
                    </label>
                </div>
                <button id="save-auto-delete-config-btn" class="btn btn-primary ck-ad-b62ee5">
                    <i class="fas fa-save"></i> Salvar Configuração
                </button>
            </div>
        </div>
    </div>

    <div id="user-modal" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header">
                <h4 id="modal-title">Gerenciar Usuário</h4>
                <button id="close-modal-btn" class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
    <form id="user-form">
        <input type="hidden" id="modal-user-id">

        <div class="input-group">
            <label for="modal-user-email">E-mail do Usuário</label>
            <input type="email" id="modal-user-email" class="modal-input-text" required>
        </div>

        <div class="input-group">
            <label for="modal-account-type">Plano da Conta</label>
            <select id="modal-account-type">
                <option value="adm_principal">ADM Principal (todos os módulos)</option>
                <option value="basic">King Start (R$ 700)</option>
                <option value="premium">King Prime (R$ 1.000)</option>
                <option value="king_base">King Base (R$ 1.500)</option>
                <option value="king_finance">King Finance (R$ 1.700)</option>
                <option value="king_finance_plus">King Finance Plus (R$ 2.000)</option>
                <option value="king_premium_plus">King Premium Plus (R$ 2.200)</option>
                <option value="king_corporate">King Corporate (R$ 2.300)</option>
                <option value="team_member">Membro de Equipe</option>
            </select>
        </div>

        <div class="input-group ck-hidden" id="max-invites-group">
            <label for="modal-max-invites">Máximo de Convites</label>
            <input type="number" id="modal-max-invites" class="modal-input-text" min="0">
        </div>

        <div class="input-group">
            <label for="modal-subscription-status">Status da Assinatura</label>
            <select id="modal-subscription-status">
                <option value="">Nenhum</option>
                <option value="active">Ativo</option>
                <option value="expired">Expirado</option>
            </select>
        </div>

        <div class="input-group">
            <label for="modal-expires-at">Data de Expiração</label>
            <input type="date" id="modal-expires-at" class="modal-input-text">
        </div>

        <div class="input-group">
            <label for="modal-profile-slug">Slug público (Informações)</label>
            <input type="text" id="modal-profile-slug" class="modal-input-text ck-ad-beb4cc" readonly tabindex="-1">
            <small class="ck-hint">Só leitura — o cliente altera isto no painel (Informações). Ex.: adrianokingg</small>
        </div>

        <div class="input-group">
            <label for="modal-activation-code">Código de ativação / pulseira (camuflado)</label>
            <input type="text" id="modal-activation-code" class="modal-input-text" maxlength="32" placeholder="Ex: ADRIANO-KING" autocomplete="off">
            <small class="ck-hint">Vai na tag NFC. Redireciona para o slug público acima (não o substitui).</small>
        </div>

        <div class="input-group">
            <label for="modal-is-admin">Permissão de Administrador</label>
            <select id="modal-is-admin">
                <option value="true">Sim</option>
                <option value="false" selected>Não</option>
            </select>
        </div>
    </form>
</div>
<div class="modal-footer">
    <button id="delete-user-btn" class="btn btn-danger">Deletar Usuário</button>
    <button id="save-user-btn" class="btn btn-primary">Salvar Alterações</button>
</div>
        </div>
    </div>
    <script src="/config.js?v=2026-09-09-vite1"></script>
</body>
</html>